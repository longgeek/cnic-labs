group :fog do
 gem 'fog', '>= 1.10'
end
