# stub
module Puppet::Util::NetworkDevice::Transport
end