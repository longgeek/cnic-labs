module Puppet::Util::Windows
  require 'puppet/util/windows/error'
  require 'puppet/util/windows/security'
end
