group :mysql do
  gem 'mysql'
end
