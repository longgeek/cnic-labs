group :sqlite do
  gem 'sqlite3'
end
