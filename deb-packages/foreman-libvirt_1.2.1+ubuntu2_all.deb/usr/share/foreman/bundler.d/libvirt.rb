group :libvirt do
  gem "ruby-libvirt", :require => 'libvirt'
end
