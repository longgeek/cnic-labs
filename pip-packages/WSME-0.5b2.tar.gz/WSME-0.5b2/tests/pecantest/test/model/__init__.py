def init_model():
    pass
