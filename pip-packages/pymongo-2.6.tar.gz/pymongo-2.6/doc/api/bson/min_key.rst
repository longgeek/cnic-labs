:mod:`min_key` -- Representation for the MongoDB internal MinKey type
=====================================================================
.. versionadded:: 1.7

.. automodule:: bson.min_key
   :synopsis: Representation for the MongoDB internal MinKey type
   :members:
