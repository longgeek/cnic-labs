.. currentmodule:: kombu.transport.sqlalchemy.models

.. automodule:: kombu.transport.sqlalchemy.models

    .. contents::
        :local:

    Models
    ------

    .. autoclass:: Queue
        :members:
        :undoc-members:

    .. autoclass:: Message
        :members:
        :undoc-members:
