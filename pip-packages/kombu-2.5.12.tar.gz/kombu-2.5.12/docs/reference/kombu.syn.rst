==========================================================
 Async Utilities - kombu.syn
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.syn

.. automodule:: kombu.syn

    .. autofunction:: detect_environment
