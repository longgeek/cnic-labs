#: E901
}
#: E901
= [x
#: E901 E101 W191
while True:
    try:
	    pass
	except:
		print 'Whoops'
