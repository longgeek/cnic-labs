#: E701
if a: a = False
#: E702
a = False; b = True
