================================
Tutorial 3: Working with IP sets
================================

.. include:: ../../netaddr/tests/2.x/ip/sets.txt
