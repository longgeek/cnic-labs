"""a docstring"""

from __future__ import generators

__revision__ = 1
