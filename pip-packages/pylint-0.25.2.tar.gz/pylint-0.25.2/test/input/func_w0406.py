"""test module importing itself
"""
__revision__ = 0

import func_w0406

if __revision__:
    print func_w0406

