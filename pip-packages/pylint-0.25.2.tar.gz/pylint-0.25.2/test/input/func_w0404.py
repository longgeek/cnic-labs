"""pylint ticket #60828"""

__revision__ = 0

def reimport():
    """docstring"""
    import os
