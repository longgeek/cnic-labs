# pylint: errors-only
"""errors-only is not usable as an inline option"""
__revision__ = None
