# following PEP 386
__version__ = "1.0.2"
