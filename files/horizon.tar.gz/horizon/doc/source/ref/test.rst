========================
Horizon TestCase Classes
========================

.. module:: horizon.test

Horizon provides several useful base classes for testing both views and
API functions.

.. autoclass:: TestCase
    :members:

.. autoclass:: APITestCase
    :members:

.. autoclass:: BaseAdminViewTests
    :members:
