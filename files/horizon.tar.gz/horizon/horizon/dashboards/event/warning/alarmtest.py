#!/usr/bin/env python
from alarminterhandle import adminuse
from alarminterhandle import useruse
#from alarmtablehandle import userget
#from alarmtablehandle import useradd

#str=useruse('1c716a027bfc4c7ca561d39bc096b7')
#str=userget('1c716a027bfc4c7ca561d39bc096b78c')
#str=adminuse()
#useradd('admin','memo','0.7','1c716a027bfc4c7ca561d39bc096b78c')
str=useruse('529ca90f33664c80b4531909172338',1,20)
print str
