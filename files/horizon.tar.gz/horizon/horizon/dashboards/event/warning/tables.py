import logging

from django.template import defaultfilters
from django.utils.translation import ugettext_lazy as _

from horizon import tables
from django.core.cache import cache



LOG = logging.getLogger(__name__)

ENABLE = 0
DISABLE = 1

class WarningFilterAction(tables.FilterAction):
    def filter(self, table, warnings, filter_string):
        """ Really naive case-insensitive search. """
        # FIXME(gabriel): This should be smarter. Written for demo purposes.
        q = filter_string.lower()

        def comp(warning):
            if any([q in (warning.disname or "").lower(),
                    q in (warning.type or "").lower(),
                    q in (warning.curSetting or "").lower(),
                    q in (warning.curStatus or "").lower(),
                    q in (warning.warningtime or "").lower()]):
                return True
            return False

        return filter(comp, warings)

class WarningsTable(tables.DataTable):

    disname = tables.Column('disname', verbose_name=_('Instance Name'))
    type = tables.Column('type', verbose_name=_('Warning Type'), filters=[defaultfilters.urlize], attrs={'width':'15%'})
    curSetting = tables.Column('curSetting', verbose_name=_('Current Setting'), attrs={'width':'15%'})
    curStatus = tables.Column('curStatus', verbose_name=_('Current Status'), attrs={'width':'15%'})
    warningtime = tables.Column('warningTime', verbose_name=_('Warning Time'), attrs={'width':'15%'})

    class Meta:
        name = "warning"
        pagination_param="page_index"
        verbose_name = _("Warning")
        table_actions = (WarningFilterAction,)
        multi_select = False
