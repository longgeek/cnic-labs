# vim: tabstop=4 shiftwidth=4 softtabstop=4

# Copyright 2012 United States Government as represented by the
# Administrator of the National Aeronautics and Space Administration.
# All Rights Reserved.
#
# Copyright 2012 Nebula, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import operator
import logging
import json
import math

from django.utils.decorators import method_decorator
from django.utils.translation import ugettext_lazy as _

from horizon import api
from horizon import exceptions
from horizon import tables
from .tables import WarningsTable
from alarminterhandle import useruse, adminuse, allcount
from django.conf import settings

class WarningModel():
    id = 1
    insname = ''
    disname = ''
    type = ''
    curSetting = ''
    curStatus = ''
    warningTime = ''
    def __init__(self, id, disname, insname, type, curSetting, curStatus, warningTime):
        self.id = id
        self.disname = disname
        self.insname = insname
        self.type = type
        self.curSetting = curSetting
        self.curStatus = curStatus
        self.warningTime = warningTime

class IndexView(tables.DataTableView):
    table_class = WarningsTable
    template_name = 'event/warning/index.html'

    def get_data(self): 
        user_roles = [role['name'] for role in self.request.user.roles]
        if 'admin' in user_roles:
            self.table.total_items = allcount('admin')
        else:
            self.table.total_items = allcount(self.request.user.id)
        warnings = []
        filter_warnings = []
        self.page_index = self.request.GET.get(WarningsTable._meta.pagination_param, "1")
        type_change = {'cpu' : _('CPU'), 'memo' : _('Memory'), 'disk' : _('Hard Disk')}
        try:
            allList = []
            if 'admin' in user_roles:
                allList = json.loads(adminuse(int(self.page_index), self.table.page_size))
            else:
                allList = json.loads(useruse(self.request.user.id, int(self.page_index), self.table.page_size))
		print self.request.user.id
            for tmpDict in allList:
                tmpWarning = WarningModel(id=tmpDict['id'],disname=tmpDict['disname'],insname=tmpDict['insname'], type=type_change[tmpDict['type']], curSetting=str(tmpDict['ratio']*100)+'%', curStatus=str(tmpDict['nowratio']*100)+'%', warningTime=tmpDict['warntime'])
                warnings.append(tmpWarning)
        except:
            exceptions.handle(self.request,
                              _('Unable to retrieve warning list.'))
        return warnings
