#!/usr/bin/env python

'''
Created on 2013-1-30

@author: Administrator
'''

import MySQLdb
import pdb
import simplejson

def adminuse(pagenum, pagesize):
    try:
        connection=MySQLdb.connect(user="root",passwd="csdb123cnic",host="mysql_server",db="monitor")
    except:
        raise Exception(_('Unable to connect to db server.'))
#        print "could not connect to db server."
#        exit(0)
    alarmlist=[]
    cursor=connection.cursor()
    offsets=pagesize*(pagenum-1)
    sqlstr=''
    sqlstr='select id,instancename,type,state,display_name,time,nowratio,ratio from alarmlogtable where state=\'on\' order by id desc limit '+str(offsets)+','+str(pagesize)
    print sqlstr
    cursor.execute(sqlstr)
    for row in cursor.fetchall():
        instance={}
        instance['id']=row[0]
        instance['insname']=row[1]
        instance['type']=row[2]
        instance['state']=row[3]
        instance['disname']=row[4]
        instance['warntime']=row[5]
        instance['nowratio']=row[6]
        instance['ratio']=row[7]
        alarmlist.append(instance)
    cursor.close()
    connection.commit()
    connection.close()
    return simplejson.dumps(alarmlist)

def adminuse_bak(indexx):
    try:
    	connection=MySQLdb.connect(user="root",passwd="csdb123cnic",host="mysql_server",db="monitor")
    except:
        raise Exception(_('Unable to connect to db server.'))
#    	print "could not connect to db server."
#    	exit(0)
    alarmlist=[]
    cursor=connection.cursor()
    sqlstr=''
    if indexx == 'index':
    	sqlstr='select id,instancename,type,state,display_name,time,nowratio,ratio from alarmlogtable where state=\'on\' order by id desc limit 5'
    else:
	sqlstr='select id,instancename,type,state,display_name,time,nowratio,ratio from alarmlogtable where state=\'on\' order by id desc'
    print sqlstr
    cursor.execute(sqlstr)
    for row in cursor.fetchall():
        instance={}
        instance['id']=row[0]
        instance['insname']=row[1]
        instance['type']=row[2]
        instance['state']=row[3]
        instance['disname']=row[4]
        instance['warntime']=row[5]
        instance['nowratio']=row[6]
	instance['ratio']=row[7]
        alarmlist.append(instance)
    cursor.close()
    connection.commit()
    connection.close()
    return simplejson.dumps(alarmlist)

def allcount(userid):
    try:
        connection=MySQLdb.connect(user="root",passwd="csdb123cnic",host="mysql_server",db="monitor")
    except:
        raise Exception(_('Unable to connect to db server.'))
#        print "could not connect to db server."
#        exit(0)
    sqlstr=''
    if userid == 'admin':
	sqlstr='select count(*) from alarmlogtable'
    else:
    	sqlstr='select count(*) from alarmlogtable where userid =\''+userid+'\''
    cursor=connection.cursor()
    print sqlstr
    cursor.execute(sqlstr)
    row=cursor.fetchone()
    return row[0]

def useruse(userid,pagenum,pagesize):
    try:
        connection=MySQLdb.connect(user="root",passwd="csdb123cnic",host="mysql_server",db="monitor")
    except:
        raise Exception(_('Unable to connect to db server.'))
#        print "could not connect to db server."
#        exit(0)
    alarmlist=[]
    cursor=connection.cursor()
    offsets=pagenum*(pagesize-1)
    sqlstr=''
    sqlstr='select id,instancename,type,state,display_name,time,nowratio,ratio from alarmlogtable where state=\'on\' and userid=\''+userid+'\' order by id desc limit '+str(offsets)+','+str(pagesize)
    print sqlstr
    cursor.execute(sqlstr)
    for row in cursor.fetchall():
        instance={}
        instance['id']=row[0]
        instance['insname']=row[1]
        instance['type']=row[2]
        instance['state']=row[3]
        instance['disname']=row[4]
        instance['warntime']=row[5]
        instance['nowratio']=row[6]
        instance['ratio']=row[7]
        alarmlist.append(instance)
    cursor.close()
    connection.commit()
    connection.close()
    return simplejson.dumps(alarmlist)

def useruse_bak(userid,indexx):
    try:
        connection=MySQLdb.connect(user="root",passwd="csdb123cnic",host="mysql_server",db="monitor")
    except:
        raise Exception(_('Unable to connect to db server.'))
#        print "could not connect to db server."
#        exit(0)
    alarmlist=[]
    cursor=connection.cursor()
    sqlstr=''
    if indexx == 'index':
    	sqlstr='select id,instancename,type,state,display_name,time,nowratio,ratio from alarmlogtable where state=\'on\' and userid=\''+userid+'\' order by id desc limit 5'
    else:
	sqlstr='select id,instancename,type,state,display_name,time,nowratio,ratio from alarmlogtable where state=\'on\' and userid=\''+userid+'\' order by id desc'
    print sqlstr
    cursor.execute(sqlstr)
    for row in cursor.fetchall():
        instance={}
        instance['id']=row[0]
        instance['insname']=row[1]
        instance['type']=row[2]
        instance['state']=row[3]
        instance['disname']=row[4]
        instance['warntime']=row[5]
        instance['nowratio']=row[6]
	instance['ratio']=row[7]
        alarmlist.append(instance)
    cursor.close()
    connection.commit()
    connection.close()
    return simplejson.dumps(alarmlist)


