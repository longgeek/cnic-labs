# vim: tabstop=4 shiftwidth=4 softtabstop=4

# Copyright 2012 United States Government as represented by the
# Administrator of the National Aeronautics and Space Administration.
# All Rights Reserved.
#
# Copyright 2012 Nebula, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import logging

from django.utils.translation import ugettext as _
from django.conf import settings

from horizon import tables
from .tables import OperationTable
from horizon.models import *

LOG = logging.getLogger(__name__)


class IndexView(tables.DataTableView):
    table_class = OperationTable
    template_name = 'event/logs/index.html'

    def get_data(self):
        query_condition = {}
        for (key, value) in self.table.query_condition.items(): 
            query_condition[key if key in ('result' ,'role') else key + '__contains'] = value
        operation_logs = Operations.objects.filter(**query_condition).order_by('-time')
        self.table.total_items = operation_logs.count()
        page_size = getattr(settings, 'API_RESULT_PAGE_SIZE', 10)
        page_index = self.request.GET.get(OperationTable._meta.pagination_param, "1")
        return operation_logs[((int(page_index)-1)*int(page_size)):int(page_size)*int(page_index)]
#        ctxt = nova_context.get_admin_context()
#        FLAGS = nova_flags.FLAGS
#        nova_flags.parse_args([])
#        operation_logs = nova_db.operation_log_get_all(ctxt)

