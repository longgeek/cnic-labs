import logging

from django.utils.translation import ugettext_lazy as _

from horizon import tables


LOG = logging.getLogger(__name__)


class QuotaFilterAction(tables.FilterAction):
    def filter(self, table, tenants, filter_string):
        q = filter_string.lower()

        def comp(tenant):
            if q in tenant.name.lower():
                return True
            return False

        return filter(comp, tenants)


def get_result(operation):
    return _('Successful') if operation.result else _('Failed')

def get_role(operation):
    return _(operation.role)

def transform_result(table, value):
    return 1 if value[0]=='True' else 0

class OperationTable(tables.DataTable):
    ROLE_CHOICES = [("",""),
        ("admin", _("admin")),
        ("ResellerAdmin",_("ResellerAdmin")),
        ("Member", _("Member"))]
    RESULT_CHOICES = [("",""),
        ('True', _("Successful")),
        ('False',_("Failed"))]
    client_ip= tables.Column("client_ip", verbose_name=_('Client IP'), attrs={'width':'10%'},is_query=True)
    role = tables.Column(get_role, verbose_name=_('Roles'), attrs={'width':'8%'}, is_query=True
                         , query_choices=ROLE_CHOICES)
    tenant = tables.Column('tenant', verbose_name=_('Tenant'), is_query=True)
    user = tables.Column('user', verbose_name=_('User'), is_query=True)
    time = tables.Column('time', verbose_name=_('time'), attrs={'width':'15%'}, is_query=True)
    operation = tables.Column('operation', verbose_name=_('operation'), is_query=True)
    result= tables.Column(get_result, verbose_name=_('Operation Result'), attrs={'width':'8%'}, is_query=True
                          , query_choices=RESULT_CHOICES,query_transform=transform_result)
    detail= tables.Column('detail', verbose_name=_('Operation Detail'), is_query=True)
    # note= tables.Column('note', verbose_name=_('note'), attrs={'width':'10%'})

    class Meta:
        pagination_param="page_index"
        name = "quotas"
        verbose_name = _("Operation Log")
        table_actions = (QuotaFilterAction,)
        multi_select = False
