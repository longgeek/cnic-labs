import logging

from django.contrib.sessions.models import Session
from django.template import defaultfilters
from django.utils.translation import ugettext_lazy as _

from horizon import api
from horizon import messages
from horizon import tables
from novaclient import exceptions as nova_exceptions
#from horizon.dashboards.resource.report.views import IndexOverview, Downloadview
from django.core.cache import cache
import time



LOG = logging.getLogger(__name__)

ENABLE = 0
DISABLE = 1
all_roles = {'enduser': 1, 'Member': 2, 'ResellerAdmin': 3, 'admin': 4}

class CreateUserLink(tables.LinkAction):
    permissions = ("openstack.roles.admin", "openstack.roles.reselleradmin")
    name = "create"
    verbose_name = _("Create User")
    url = "horizon:user:users:create"
    classes = ("ajax-modal", "btn-create")
    icon_path = "/static/dashboard/image/xinjian.png"

    def allowed(self, request, user):
        if api.keystone_can_edit_user():
            return True
        return False


class EditUserLink(tables.LinkAction):
    name = "edit"
    verbose_name = _("Edit")
    url = "horizon:user:users:update"
    classes = ("ajax-modal", "btn-edit")
    icon_path = "/static/dashboard/image/002.png"

    def allowed(self, request, user):
        curr_role = request.user.roles[0]['name']
        if user.role_name and all_roles[curr_role] >= all_roles[user.role_name]:
            return True


def clean_user_session(user_id):
    all_sessions = Session.objects.all()
    for user_session in all_sessions:
        session_data = user_session.get_decoded()
        if 'token' in session_data and 'user' in session_data['token'] and user_id == session_data['token']['user']['id']:
            user_session.delete()
            break

class ToggleEnabled(tables.BatchAction):
    name = "enable"
    action_present = (_("Enable"), _("Disable"))
    action_past = (_("Enabled"), _("Disabled"))
    data_type_singular = _("User")
    data_type_plural = _("Users")
    classes = ("btn-enable",)
    icon_path = "/static/dashboard/image/tingyong.png"

    def allowed(self, request, user=None):
        self.enabled = True
        if not user:
            return self.enabled
        self.enabled = user.enabled
        if self.enabled:
            self.current_present_action = DISABLE
        else:
            self.current_present_action = ENABLE
        curr_role = request.user.roles[0]['name']
        if not api.keystone_can_edit_user() or (user and user.id == request.user.id) or not user.role_name or all_roles[curr_role] < all_roles[user.role_name]:
            return False
        return True

    def update(self, request, user=None):
        super(ToggleEnabled, self).update(request, user)
        if user and user.id == request.user.id:
            self.attrs["disabled"] = "disabled"

    def action(self, request, obj_id):
        if obj_id == request.user.id:
            messages.info(request, _('You cannot disable the user you are '
                                     'currently logged in as.'))
            return
        if self.enabled:
            api.keystone.user_update_enabled(request, obj_id, False)
            self.current_past_action = DISABLE
            clean_user_session(obj_id)
        else:
            api.keystone.user_update_enabled(request, obj_id, True)
            self.current_past_action = ENABLE


class DeleteUsersAction(tables.DeleteAction):
    data_type_singular = _("User")
    data_type_plural = _("Users")
    permissions = ("openstack.roles.admin", "openstack.roles.reselleradmin")
    icon_path = "/static/dashboard/image/shanchu.png"

    def allowed(self, request, datum):
        curr_role = request.user.roles[0]['name']
        if not api.keystone_can_edit_user() or (datum and datum.id == request.user.id ) or (datum and not datum.role_name) or (datum and getattr(datum, 'role_name') and all_roles[curr_role] < all_roles[datum.role_name]):
            return False
        return True

    def delete(self, request, obj_id):
        instances = api.server_list_paginate(request, all_tenants=True, page_index=0, page_size=api.server_list_count(request, all_tenants=True))
        for instance in instances[0]:
            if instance.user_id == obj_id:
                raise nova_exceptions.ClientException(0,message=_("Unable to delete user owns the server."))
        api.keystone.user_delete(request, obj_id)
        clean_user_session(obj_id)

class UserFilterAction(tables.FilterAction):
    def filter(self, table, users, filter_string=""):
        self.filter_string = filter_string
        """ Really naive case-insensitive search. """
        # FIXME(gabriel): This should be smarter. Written for demo purposes.
        q = filter_string.lower()

        def comp(user):
            if any([q in (user.name or "").lower(),
                    q in (user.email or "").lower()]):
                return True
            return False

        return filter(comp, users)

def is_online(user):
    last_seen = cache.get('seen_%s' % user.name)
    return _('True') if (time.time()-600) < last_seen else _('False')

#add by shengeng
def is_enabled(user):
    return _('True') if user.enabled else _('False')

def get_role_name(user):
    role_name = getattr(user,'role_name','')
    return _(role_name) if role_name else '';

class UsersTable(tables.DataTable):
    STATUS_CHOICES = (
        ('true', True),
        ('false', False)
    )
    #STATUS_DISPLAYS = (
    #    ('true', _('True')),
    #    ('false', _('False'))
    #)
    name = tables.Column('name', verbose_name=_('User Name'))
    email = tables.Column('email', verbose_name=_('Email'),
                          filters=[defaultfilters.urlize], attrs={'width':'15%'})
    # Default tenant is not returned from Keystone currently.
    #default_tenant = tables.Column('default_tenant',
    #                               verbose_name=_('Default Project'))
    id = tables.Column('id', verbose_name=_('User ID'), attrs={'width':'25%'})
    online=tables.Column(is_online, verbose_name=_('Online'), attrs={'width':'10%'})
    enabled = tables.Column(is_enabled, verbose_name=_('Enabled'),
                            #status=True,
                            #status_choices=STATUS_CHOICES,
			    #display_choices=STATUS_DISPLAYS,
                            empty_value=False, attrs={'width':'10%'})
    user_group_name = tables.Column("group_name", verbose_name=_("Project"))
    role_name = tables.Column(get_role_name, verbose_name=_("Role"))

    class Meta:
        name = "users"
        verbose_name = _("Users")
        row_actions = (EditUserLink, ToggleEnabled, DeleteUsersAction)
        table_actions = (UserFilterAction, CreateUserLink, DeleteUsersAction)
