# vim: tabstop=4 shiftwidth=4 softtabstop=4
from django.core.urlresolvers import reverse, reverse_lazy
from django.utils.decorators import method_decorator
from django.utils.translation import ugettext_lazy as _
from django.views.decorators.debug import sensitive_post_parameters
from django.conf import settings

from horizon import api
from horizon import exceptions
from horizon import forms
from horizon import tables
from .forms import CreateUserForm, UpdateUserForm
from .tables import UsersTable


class IndexView(tables.DataTableView):
    table_class = UsersTable
    template_name = 'user/users/index.html'

    def get_context_data(self, **kwargs):
        context = super(IndexView, self).get_context_data(**kwargs)
        try:
            curr_user = api.keystone.user_get(self.request, self.request.user.id)
            context['user_name'] = curr_user.name
            context['user_email'] = curr_user.email
            context['user_id'] = curr_user.id
            context['user_enable'] = curr_user.enabled
        except:
            exceptions.handle(self.request, _('Unable to retrieve current user.'))
        return context

    def get_data(self):
        page_index = self.request.GET.get(UsersTable._meta.pagination_param, "1")
        users = []
        filter_users = []
        try:
            curr_role = self.request.user.roles[0]['name']
            curr_user = api.keystone.user_get(self.request, self.request.user.id)
            curr_tenantid = curr_user.tenantId
            if curr_role == 'ResellerAdmin':
                users = api.keystone.user_list(self.request, tenant_id=curr_tenantid)
            else:
                users = api.keystone.user_list(self.request)
            #filter built-in users-- added by weiyuanke123@gmail.com
            filter_users = filter(lambda x:x.name not in ['cinder', 'swift', 'glance', 'nova'], users)
            group_name_dic = {tenant.id:tenant.name for tenant in api.keystone.tenant_list(self.request, admin=True) if tenant.name not in ['service']}
            for user in filter_users:
                user.group_name = group_name_dic.get(user.tenantId,"") if user.tenantId else ""
                if user.id and user.tenantId:
                    roles = api.keystone.roles_for_user(self.request, user.id, user.tenantId)
                    user.role_name = '' if not roles else roles[0].name
                else:
                    user.role_name = ''
        except:
            exceptions.handle(self.request,
                              _('Unable to retrieve user list.'))
        self.table.total_items = len(filter_users)
        page_size = getattr(settings, 'API_RESULT_PAGE_SIZE', 10)
        return filter_users[((int(page_index)-1)*int(page_size)):int(page_size)*int(page_index)]



class UpdateView(forms.ModalFormView):
    form_class = UpdateUserForm
    template_name = 'user/users/update.html'
    success_url = reverse_lazy('horizon:user:users:index')

    @method_decorator(sensitive_post_parameters('password',
                                                'confirm_password'))
    def dispatch(self, *args, **kwargs):
        return super(UpdateView, self).dispatch(*args, **kwargs)

    def get_object(self):
        if not hasattr(self, "_object"):
            try:
                self._object = api.user_get(self.request, self.kwargs['user_id'], admin=True)
            except:
                redirect = reverse("horizon:user:users:index")
                exceptions.handle(self.request,
                                  _('Unable to update user.'),
                                  redirect=redirect)
        return self._object

    def get_context_data(self, **kwargs):
        context = super(UpdateView, self).get_context_data(**kwargs)
        context['user'] = self.get_object()
        return context

    def get_initial(self):
        user = self.get_object()
        return {'id': user.id,
                'name': user.name,
                'tenant_id': getattr(user, 'tenantId', None),
                'email': user.email,
                'role_id':getattr(user, 'role_id', None)}


class CreateView(forms.ModalFormView):
    form_class = CreateUserForm
    template_name = 'user/users/create.html'
    success_url = reverse_lazy('horizon:user:users:index')

    @method_decorator(sensitive_post_parameters('password',
                                                'confirm_password'))
    def dispatch(self, *args, **kwargs):
        return super(CreateView, self).dispatch(*args, **kwargs)

    '''
    def get_form_kwargs(self):
        kwargs = super(CreateView, self).get_form_kwargs()
        try:
            roles = api.keystone.role_list(self.request)
        except:
            redirect = reverse("horizon:user:users:index")
            exceptions.handle(self.request,
                              _("Unable to retrieve user roles."),
                              redirect=redirect)
        roles.sort(key=operator.attrgetter("id"))
        kwargs['roles'] = roles
        return kwargs
    '''
    def get_initial(self):
        default_role = api.keystone.get_default_role(self.request)
        return {'role_id': getattr(default_role, "id", None)}


