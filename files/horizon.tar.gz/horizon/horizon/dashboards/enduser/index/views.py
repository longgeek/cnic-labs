from django.shortcuts import render_to_response
from django.views import generic
from django.core.urlresolvers import reverse, reverse_lazy
from django.utils.decorators import method_decorator
from django.utils.translation import ugettext_lazy as _
from django.views.decorators.debug import sensitive_post_parameters
from django.conf import settings

from horizon import api
from horizon import grid
from horizon import forms
from .forms import PrecreateInstanceForm

class IndexView(generic.TemplateView):
    template_name = 'enduser/index/index.html'


    def __init__(self, *args, **kwargs):
        super(IndexView, self).__init__(*args, **kwargs)

    def get_context_data(self, **kwargs):
        dataGrid = grid.DataGrid(self.request, datalist=self.get_data())
        context = {'grid' : dataGrid}
        return context

    def get_data(self):
        try:
            instances = api.server_list(self.request, all_tenants=False)
        except:
            instances = []
        return instances

class PrecreateInstanceView(forms.ModalFormView):
    form_class = PrecreateInstanceForm
    success_url = 'enduser/index/index.html'
    template_name = 'enduser/index/precreate.html'
    ajax_template_name = 'enduser/index/_precreate.html'


    def dispatch(self, *args, **kwargs):
        return super(PrecreateInstanceView, self).dispatch(*args, **kwargs)

    '''
    def get_initial(self):
        return {'name': "fujiangnan"}
    '''

class TestView(generic.TemplateView):
    template_name = 'enduser/index/130718index.html'