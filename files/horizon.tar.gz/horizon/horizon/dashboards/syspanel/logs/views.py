import logging

from django.utils.translation import ugettext as _

from horizon import api
from horizon import exceptions
from horizon import tables
from .tables import QuotasTable
from nova import context as nova_context
from cinder import context as cinder_context
from glance import context as glance_context
import cinder.flags as cinder_flags
import nova.flags as nova_flags
from nova import db as nova_db
from cinder import db as cinder_db
from glance.db.sqlalchemy import *
from glance.db.sqlalchemy.api import operation_log_get_all as g_operation_log_get_all
import operator

LOG = logging.getLogger(__name__)


class IndexView(tables.DataTableView):
    table_class = QuotasTable
    template_name = 'syspanel/quotas/index.html'
         
    def get_data(self):
        n_ctxt = nova_context.get_admin_context()
        c_ctxt = cinder_context.get_admin_context()
        g_ctxt = glance_context.get_admin_context()

        FLAGS = nova_flags.FLAGS
        nova_flags.parse_args([]) 
    
        c_FLAGS = cinder_flags.FLAGS
        cinder_flags.parse_args([])
                
        g_operation_logs = g_operation_log_get_all(g_ctxt)
        n_operation_logs = nova_db.operation_log_get_all(n_ctxt)
        c_operation_logs = cinder_db.operation_log_get_all(c_ctxt)
        
        operation_logs = n_operation_logs + c_operation_logs + g_operation_logs
        operation_logs.sort(key=operator.attrgetter('created_at'))
        return operation_logs
