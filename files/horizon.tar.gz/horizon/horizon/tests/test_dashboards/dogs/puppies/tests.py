from horizon import test


class PuppiesTests(test.TestCase):
    # Unit tests for puppies.
    def test_me(self):
        self.assertTrue(1 + 1 == 2)
