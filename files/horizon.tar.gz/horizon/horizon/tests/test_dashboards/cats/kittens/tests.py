from horizon import test


class KittensTests(test.TestCase):
    # Unit tests for kittens.
    def test_me(self):
        self.assertTrue(1 + 1 == 2)
