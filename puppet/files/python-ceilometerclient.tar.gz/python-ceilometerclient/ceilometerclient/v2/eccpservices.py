


from ceilometerclient.common import base
from ceilometerclient.v2 import options
import logging
import datetime

LOG = logging.getLogger(__name__)

class EccpService(base.Resource):
    def __repr__(self):
        return "<EccpService %s>" % self._info


class EccpServiceManager(base.Manager):
    resource_class = EccpService
    
    @staticmethod
    def _path(counter_name=None):
        return '/v2/services/%s' % counter_name if counter_name else '/v2/services'

    def list(self, meter_name=None, q=None):
        path = self._path(counter_name=meter_name)
        return self._list(options.build_url(path, q))

    # Added by shaojing, Dec 2
    # List the latest service status
    def list_service_status(self, service_name=None, q=None, params=None):
        path = self._path(counter_name=service_name)
        path = options.build_url(path, q, params)
        return self._list(path)
    # Added by shaojing, Dec 2
