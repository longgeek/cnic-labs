from ceilometerclient.common import base
from ceilometerclient.v2 import options
import logging
import datetime

LOG = logging.getLogger(__name__)

class Gluster(base.Resource):
    def __repr__(self):
        return "<Gluster %s>" % self._info


class GlusterManager(base.Manager):
    resource_class = Gluster
    
    @staticmethod
    def _path(sub_url=None):
        return '/v2/glusters/%s' % sub_url if sub_url else '/v2/glusters'

    def list(self,  q=None, params=None):
        path = self._path()
        return self._list(options.build_url(path, q, params))

    def get_latest(self,  q=None):
        path = self._path(sub_url='get_latest')
        path = options.build_url(path, q)
        return self._list(path)
