



from ceilometerclient.common import base
from ceilometerclient.v2 import options
import logging
import datetime

LOG = logging.getLogger(__name__)

class EccpServer(base.Resource):
    def __repr__(self):
        return "<EccpServer %s>" % self._info


class EccpServerManager(base.Manager):
    resource_class = EccpServer
    
    def list(self, q=None, params=None):
        result = self._get_all(options.build_url(
            '/v2/servers/eccp_server/get_all_server', q, params))

        for item in result:
            temp = item['items']
            for k,v in temp.iteritems():
                temp[k] = eval(v)

        return result

    def list_avg(self, q=None, params=None):
        result = self._get_all(options.build_url(
            '/v2/servers/eccp_server/get_avg_statistics', q, params))
        #Added by shaojing, Nov 17
        for item in result:
            temp = item['items']
            for k,v in temp.iteritems():
                temp[k] = eval(v)
        #Added by shaojing, Nov 17
       
        return result

    def list_avg_total(self, q=None, params=None):
        result = self._get_all(options.build_url(
            '/v2/servers/eccp_server/get_avg_stat_total', q, params))
        return result

