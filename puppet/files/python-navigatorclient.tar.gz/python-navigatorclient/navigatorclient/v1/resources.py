# Copyright 2012 OpenStack LLC.
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import copy
import errno
import json
import os
import urllib

from navigatorclient.common import base
from navigatorclient.common import utils


class ResourceAllocated(base.Resource):
    def __repr__(self):
        return "<ResourceAllocated %s>" % self._info

    def data(self, **kwargs):
        return self.manager.data(self, **kwargs)
    
class ResourceAvailable(base.Resource):
    def __repr__(self):
        return "<ResourceAvailable %s>" % self._info

    def data(self, **kwargs):
        return self.manager.data(self, **kwargs)


class ResourceManager(base.Manager):
    
    resource_class = ResourceAllocated

    def release_resource_by_instance(self, instance_uuid, **kwargs):
        url = '/resource/instance/%s' % instance_uuid
        result = self._delete(url)
        return result
    
    def release_resource_by_id(self, id, **kwargs):
        url = '/resource/%s' % id
        result = self._delete(url)
        return result
    
    def list_resource_by_instance(self, instance_uuid, **kwargs):
        url = '/resource/instance/%s' % instance_uuid
        self.resource_class = ResourceAllocated
        result = self._list(url, "resources")
        return result
    
    def list_resource_available(self, **kwargs):
        url = '/resource_available'
        self.resource_class = ResourceAvailable
        result = self._list(url, "resources")
        return result
    
    def list_resource_available_local(self, **kwargs):
        url = '/resource_available/host/localhost'
        self.resource_class = ResourceAvailable
        result = self._list(url, "resources")
        return result
    
    def list_resource_available_by_host(self, host, **kwargs):
        url = '/resource_available/host/%host' % host
        self.resource_class = ResourceAvailable
        result = self._list(url, "resources")
        return result
    
    def allocated_resource(self, instance_uuid, des_address, des_port, count = 1):

        fields = {}
        fields['instance_uuid'] = instance_uuid
        fields['des_address'] = des_address
        fields['des_port'] = des_port
        fields['count'] = count
        
        
        result = self._post('/resource', fields)
        return result
    
    def debug(self, **kwargs):

        params = {}

        filters = kwargs.get('filters', {})
        properties = filters.pop('properties', {})
        for key, value in properties.items():
            params['property-%s' % key] = value
        params.update(filters)


        url = '/debug?%s' % urllib.urlencode(params)
 
        result = self._get_field(url, "result")
        return result