import sys
import os
import logging
from django import forms
from django.conf import settings
from django.contrib.auth import authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.utils.translation import ugettext as _
from django.views.decorators.debug import sensitive_variables
from django.forms import ValidationError
from django.core import validators as dj_validators

from .exceptions import KeystoneAuthException
sys.path.insert(0, os.path.join(os.path.dirname(os.path.realpath(__file__)), '../django_simple_captcha-0.3.0-py2.7.egg'))
from captcha.fields import CaptchaField, CaptchaTextInput
from horizon.utils import validators
from horizon import forms as hforms
from horizon import api
from horizon import exceptions
from horizon import messages


LOG = logging.getLogger(__name__)


class Login(AuthenticationForm):
    region = forms.ChoiceField(label=_("Region"), required=False)
    username = forms.CharField(label=_("User Name"),
                               widget=forms.TextInput(attrs={"placeholder" : _("User Name"), 
                                                             "class" : "span12", 
                                                             "data-ze-icon" : "icon-user",
                                                             "data-rel":"tooltip",
                                                             "data-original-title":_('Please fill in your user name')}))
    password = forms.CharField(label=_("Password"),
                               widget=forms.PasswordInput(render_value=False, attrs={"placeholder" : _("Password"), 
                                                                                     "class" : "span12",
                                                                                     "data-ze-icon" : "icon-lock",
                                                                                     "data-rel":"tooltip",
                                                                                     "data-original-title":_('Please fill in your password')}))
    captcha = CaptchaField(label=_("Captcha"), widget= CaptchaTextInput(attrs={"placeholder" : _("Captcha"), 
                                                                               "class" : "span6"},
                                                                        output_format=u'%(hidden_field)s %(text_field)s %(image)s'))
    tenant = forms.CharField(required=False, widget=forms.HiddenInput())

    def __init__(self, *args, **kwargs):
        super(Login, self).__init__(*args, **kwargs)
        self.fields['region'].choices = self.get_region_choices()
        if len(self.fields['region'].choices) == 1:
            self.fields['region'].initial = self.fields['region'].choices[0][0]
            self.fields['region'].widget = forms.widgets.HiddenInput()

    @staticmethod
    def get_region_choices():
        default_region = (settings.OPENSTACK_KEYSTONE_URL, "Default Region")
        return getattr(settings, 'AVAILABLE_REGIONS', [default_region])

    @sensitive_variables()
    def clean(self):
        username = self.cleaned_data.get('username')
        password = self.cleaned_data.get('password')
        region = self.cleaned_data.get('region')
        tenant = self.cleaned_data.get('tenant')

        if not tenant:
            tenant = None

        if not (username and password):
            # Don't authenticate, just let the other validators handle it.
            return self.cleaned_data

        try:
            self.user_cache = authenticate(request=self.request,
                                           username=username,
                                           password=password,
                                           tenant=tenant,
                                           auth_url=region)
            if self.user_cache.tenant_name == 'service':
                raise forms.ValidationError(_('Invalid user name or password.'))
        except KeystoneAuthException as exc:
            self.request.session.flush()
            raise forms.ValidationError(exc)
        try:
            self.check_for_test_cookie()
        except Exception as e:
            self.request.session.flush()
        return self.cleaned_data


class RegisterUserForm(hforms.SelfHandlingForm):
    name = hforms.SlugField(label=_("User Name"),
                            max_length="25",
                            widget=forms.TextInput(attrs={"placeholder" : _("User Name"),
                                                          "class" : "span12",
                                                          "data-ze-icon" : "icon-user",
                                                          "data-rel":"tooltip",
                                                          "data-original-title":_('Less than 25 chars, the value  may only contain letters, numbers, underscores and hyphens.')}))
    password = hforms.RegexField(
            max_length="16",
            label=_("Password"),
            widget=hforms.PasswordInput(render_value=False, 
                                        attrs={"placeholder" : _("Password"),
                                               "class" : "span12",
                                               "data-ze-icon" : "icon-lock",
                                               "data-rel":"tooltip",
                                               "data-original-title":_('Less than 16 chars and letters are case sensitive')}),
            regex=validators.password_validator(),
            error_messages={'invalid': validators.password_validator_msg()})
    confirm_password = hforms.CharField(
            label=_("Confirm Password"),
            required=False,
            widget=hforms.PasswordInput(render_value=False, 
                                        attrs={"placeholder" : _("Confirm Password"),
                                               "class" : "span12",
                                               "data-ze-icon" : "icon-retweet",
                                               "data-rel":"tooltip",
                                               "data-original-title":_("Please confirm password")}))
    email = hforms.EmailField(label=_("Email"),
                              widget=forms.TextInput(attrs={"placeholder" : _("Email"),
                                                            "class" : "span12",
                                                            "data-ze-icon" : "icon-envelope",
                                                            "data-rel":"tooltip",
                                                            "data-original-title":_('Please fill in your email address.')}))
#    tenant_id = hforms.ChoiceField(label=_("Project"),
#            widget=forms.Select(attrs={"class" : "span12"}))
#    role_id = hforms.ChoiceField(label=_("Role"),
#            widget=forms.Select(attrs={"class" : "span12"}))
    captcha = CaptchaField(label=_("Captcha"), 
                           widget= CaptchaTextInput(attrs={"placeholder" : _("Captcha"), 
                                                           "class" : "span6"},
                                                    output_format=u'%(hidden_field)s %(text_field)s %(image)s'))

#    def __init__(self, request, *args, **kwargs):
#        super(RegisterUserForm, self).__init__(request, *args, **kwargs)
#        tenant_choices = [('', _("Please select user group")), ('0', _("Default Tenant"))]
#        tenant_id_choice = [request.POST.get('tenant_id',None), None]
#        for tenant in api.anonymous_tenant_list(request, admin=True):
#            if tenant.enabled and tenant.name != 'service':
#                tenant_choices.append((tenant.id, tenant.name))
#                if tenant_id_choice[0] and tenant_id_choice[0] == tenant.id: tenant_id_choice[1] = tenant.name
#        if tenant_id_choice[0] and not tenant_id_choice[1]: tenant_choices.append((tenant_id_choice[0], None))
#        self.fields['tenant_id'].choices = tenant_choices
#        role_choices = [('', _("Please select role"))]
#        role_choices.extend([(role.id, _(role.name)) for role in api.anonymous_role_list(request) if role.name != 'admin'])
#        self.fields['role_id'].choices = role_choices

    def __init__(self, request, *args, **kwargs):
        super(RegisterUserForm, self).__init__(request, *args, **kwargs)

    def clean(self):
        '''Check to make sure password fields match.'''
        data = super(hforms.Form, self).clean()
        if 'password' in data:
            if data['password'] != data.get('confirm_password', None):
                raise ValidationError(_('Passwords do not match.'))
        if data.get('name', None):
            ids = [user.id for user in api.anonymous_user_list(self.request) if user.name.strip().lower() == data['name'].strip().lower()]
            if ids:
                if not 'id' in data:
                    raise ValidationError(_("Duplicate User Name."))
                elif not data['id'] in ids:
                    raise ValidationError(_("Duplicate User Name."))
        return data
    #modified by haochennan
    def handle(self, request, data):
        try:
            LOG.info('Creating user with name "%s"' % data['name'])
            default_tenant = api.anonymous_tenant_create(request,
                                 tenant_name=data['name'],
                                 description='',
                                 enabled=True)
            new_user = api.anonymous_user_create(request,
                                 data['name'],
                                 data['email'],
                                 data['password'],
                                 default_tenant.id,
                                 True)
            messages.success(request,
                                 _('User "%s" was successfully created.')
                                 % data['name'])
            role_id = [role.id for role in api.anonymous_role_list(request) if role.name == 'Member'][0] 
            try:
                api.anonymous_add_tenant_user_role(request,
                                 default_tenant.id,
                                 new_user.id,
                                 role_id)
            except:
                exceptions.handle(request,
                                  _('Unable to add user'
                                    'to primary project.'))
            return new_user
        except:
            exceptions.handle(request, _('Unable to create user.'))

"""
    def handle(self, request, data):
        try:
            LOG.info('Creating user with name "%s"' % data['name'])
            if data['tenant_id'] == '':
                default_tenant = api.anonymous_tenant_create(request,
                                                             tenant_name=data['name'],
                                                             description='',
                                                             enabled=True)
                new_user = api.anonymous_user_create(request,
                               data['name'],
                               data['email'],
                               data['password'],
                               default_tenant.id,
                               True)
                messages.success(request,
                                 _('User "%s" was successfully created.')
                                 % data['name'])
                role_id = [role.id for role in api.anonymous_role_list(request) if role.name == 'Member'][0] 
                try:
                    api.anonymous_add_tenant_user_role(request,
                                                       default_tenant.id,
                                                       new_user.id,
                                                       role_id)
                except:
                    exceptions.handle(request,
                                      _('Unable to add user'
                                        'to primary project.'))
            else:
                new_user = api.anonymous_user_create(request,
                               data['name'],
                               data['email'],
                               data['password'],
                               data['tenant_id'],
                               True)
                messages.success(request,
                                 _('User "%s" was successfully created.')
                                 % data['name'])
                if data['role_id']:
                    try:
                        api.anonymous_add_tenant_user_role(request,
                                                           data['tenant_id'],
                                                           new_user.id,
                                                           data['role_id'])
                    except:
                        exceptions.handle(request,
                                          _('Unable to add user'
                                            'to primary project.'))
            return new_user
        except:
            exceptions.handle(request, _('Unable to create user.'))
"""
