If you would like to contribute to Savanna, please, take a look at the following page:

https://savanna.readthedocs.org/en/latest/devref/how_to_participate.html

Once those steps have been completed, changes to Savanna should be submitted for review via the Gerrit tool, following the workflow documented at:

http://wiki.openstack.org/GerritWorkflow

Pull requests submitted through GitHub will be ignored.

Bugs should be filed on Launchpad, not GitHub:

https://bugs.launchpad.net/savanna
