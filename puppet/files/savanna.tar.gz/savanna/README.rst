Savanna project
===============

Savanna at wiki.openstack.org: https://wiki.openstack.org/wiki/Savanna

Launchpad project: https://launchpad.net/savanna

Savanna docs site: https://savanna.readthedocs.org/en/latest/index.html

Roadmap: https://wiki.openstack.org/wiki/Savanna/Roadmap

Quickstart guide: https://savanna.readthedocs.org/en/latest/devref/quickstart.html

How to participate: https://savanna.readthedocs.org/en/latest/devref/how_to_participate.html


License
-------
Copyright (c) 2013 Mirantis Inc.

Apache License Version 2.0 http://www.apache.org/licenses/LICENSE-2.0
