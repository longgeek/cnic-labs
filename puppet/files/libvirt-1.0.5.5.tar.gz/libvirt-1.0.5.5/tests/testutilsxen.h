
#include "capabilities.h"

virCapsPtr testXenCapsInit(void);
