
#include "capabilities.h"

virCapsPtr testLXCCapsInit(void);
