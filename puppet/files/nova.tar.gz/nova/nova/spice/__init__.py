#!/usr/bin/env python
from nova.openstack.common import cfg
        
spice_opts = [
    cfg.StrOpt('html5proxy_base_url',
               default='http://127.0.0.1:6080/spice_auto.html',
               help='location of spice html5 console proxy, in the form '
                    '"http://127.0.0.1:6080/spice_auto.html"'),
    cfg.StrOpt('server_listen',
               default='0.0.0.0',
               help='IP address on which instance spice server should listen'),
    cfg.StrOpt('server_proxyclient_address',
               default='127.0.0.1',
               help='the address to which proxy clients '
                    '(like nova-spicehtml5proxy) should connect'),
    cfg.BoolOpt('enabled',
                default=True,
                help='enable spice related features'),
    cfg.BoolOpt('agent_enabled',
                default=True,
                help='enable spice guest agent support'),
    cfg.StrOpt('keymap',
               default='en-us',
               help='keymap for spice'),
    ]       
        
CONF = cfg.CONF
CONF.register_opts(spice_opts, group="spice")

