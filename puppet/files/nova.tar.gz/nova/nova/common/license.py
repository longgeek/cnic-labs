from nova.openstack.common import log as logging
from nova import utils
LOG = logging.getLogger(__name__)

def license_expire_operation():
    #LOG.error(_('license expire operation'))
    utils.execute("shutdown", "-h", "now", run_as_root=True)

def license_error_operation():
    #LOG.error(_('license error operation'))
    utils.execute("shutdown", "-h", "now", run_as_root=True)

# license check, added by YANGYUAN
def check_license():
    from M2Crypto import RSA, BIO
    import base64
    import datetime
    try:
        key_public_string  = """
-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDAyanpXmp6Lyu0uibBGxJcDI+I
yGLG1XeT0zme7qfQxSfmlpB8YA83oPr63VYX87CbYsdyKzArg8h0OJ1eHpxFU8E6
DIh8lnIj+ALMmu+UMeQM012+bYk+ULevNbVWdM9WiPYWHg6XL3U7ZtshbeL7pFA/
a3BIHR8FnfLzymIU6QIDAQAB
-----END PUBLIC KEY-----
""" 
        bio = BIO.MemoryBuffer(key_public_string)
        key = RSA.load_pub_key_bio(bio)
        
        file_license = open('/opt/stack/eccp.license', 'r')
        license = file_license.read()
        encrypted = base64.b64decode(license)
        decrypted = key.public_decrypt(encrypted, RSA.pkcs1_padding)
        datetime_expire = datetime.datetime.strptime(decrypted, "%Y-%m-%d")
        
        if datetime.datetime.now() < datetime_expire:
            timeleft = datetime_expire - datetime.datetime.now()
            LOG.warning(_('license expire time: %s, time left: %s' % (datetime_expire, str(timeleft))))
            return True
        else :
            LOG.error(_('license expired, expire time: %s'), datetime_expire)
            license_expire_operation()
            return False
    except:
        LOG.error(_('license check error'))
        license_error_operation()
        return False