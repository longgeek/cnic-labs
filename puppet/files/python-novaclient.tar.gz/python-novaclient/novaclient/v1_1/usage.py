"""
Usage interface.
"""

from novaclient import base


class Usage(base.Resource):
    """
    Usage contains infomartion about a tenants physical resource usage
    """
    def __repr__(self):
        return "<ComputeUsage>"


class UsageManager(base.ManagerWithFind):
    """
    Manage :class:`Usage` resources.
    """
    resource_class = Usage

    def list(self, start, end, tenant_id=None, detailed=False, **kwargs):
        """
        Get usage for all tenants

        :param start: :class:`datetime.datetime` Start date
        :param end: :class:`datetime.datetime` End date
        :param detailed: Whether to include information about each
                         instance whose usage is part of the report
        :rtype: list of :class:`Usage`.
        """
        limit = kwargs.get('limit')
        page_index = kwargs.get('page_index')

        if not tenant_id is None:
            url = "/os-simple-tenant-usage?tenant_id=%s&start=%s&end=%s&detailed=%s&limit=%s&page_index=%s" % (tenant_id, start.isoformat(), end.isoformat(), int(bool(detailed)), limit, page_index)
        else:
            url = "/os-simple-tenant-usage?start=%s&end=%s&detailed=%s&limit=%s&page_index=%s" % (start.isoformat(), end.isoformat(), int(bool(detailed)), limit, page_index)

        return self._list(url,"tenant_usages")

    def list_by_user(self, start, end, detailed=False, tenant_id=None):
        return self._list(
                    "/os-simple-user-usage?start=%s&end=%s&detailed=%s" %
                    (start.isoformat(), end.isoformat(), int(bool(detailed))),
                    "user_usages")

    #modified by weiyuanke@cnic.cn
    def get(self, tenant_id, start, end, show_terminated=False,  **kwargs):
        """
        Get usage for a specific tenant.

        :param tenant_id: Tenant ID to fetch usage for
        :param start: :class:`datetime.datetime` Start date
        :param end: :class:`datetime.datetime` End date
        :param limit:
        :param page_index:
        :rtype: :class:`Usage`
        """
        limit = kwargs.get('limit')
        page_index = kwargs.get('page_index')
        tenant_usage = self._get("/os-simple-tenant-usage/%s?start=%s&end=%s&limit=%s&page_index=%s" %
                         (tenant_id, start.isoformat(), end.isoformat(), limit, page_index),
                         "tenant_usage")
        return tenant_usage

    #added by weiyuanke@cnic.cn
    def count(self, tenant_id, start, end, detailed=False, **kwargs):
        """
        Get usage for a specific tenant.

        :param tenant_id: Tenant ID to fetch usage for
        :param start: :class:`datetime.datetime` Start date
        :param end: :class:`datetime.datetime` End date
        :param limit:
        :param page_index:
        :rtype: :class:`Usage`
        """
        #result = self._get("/os-simple-tenant-usage/%s?start=%s&end=%s" %
        #                 (tenant_id, start.isoformat(), end.isoformat()),
        #                 "tenant_usage")
       
        if not tenant_id is None:
            url = "/os-simple-tenant-usage?tenant_id=%s&start=%s&end=%s&detailed=%s" % (tenant_id, start.isoformat(), end.isoformat(), int(bool(detailed)))
        else:
            url = "/os-simple-tenant-usage?start=%s&end=%s&detailed=%s" % (start.isoformat(), end.isoformat(), int(bool(detailed)))

        usage_list = self._list(url,"tenant_usages")
        return usage_list
