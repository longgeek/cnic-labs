import unittest2


class TestCase(unittest2.TestCase):
    pass
