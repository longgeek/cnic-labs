<?php

/* Pass in by reference! */
function graph_mem_report ( &$rrdtool_graph ) {

    global $context,
           $hostname,
           $mem_shared_color,
           $mem_cached_color,
           $mem_buffered_color,
           $mem_swapped_color,
           $mem_used_color,
           $cpu_num_color,
           $range,
           $rrd_dir,
           $size,
           $strip_domainname;

    if ($strip_domainname) {
       $hostname = strip_domainname($hostname);
    }

    $title = '内存';
    if ($context != 'host') {
       $rrdtool_graph['title'] = $title;
    } else {
       $rrdtool_graph['title'] = "$hostname $title last $range";
    }
    $rrdtool_graph['lower-limit']    = '0';
    $rrdtool_graph['vertical-label'] = '字节';
    $rrdtool_graph['extras']         = '--rigid --base 1024';

    $series = "DEF:'mem_total'='${rrd_dir}/mem_total.rrd':'sum':AVERAGE "
        ."CDEF:'bmem_total'=mem_total,1024,* "
        ."DEF:'mem_shared'='${rrd_dir}/mem_shared.rrd':'sum':AVERAGE "
        ."CDEF:'bmem_shared'=mem_shared,1024,* "
        ."DEF:'mem_free'='${rrd_dir}/mem_free.rrd':'sum':AVERAGE "
        ."CDEF:'bmem_free'=mem_free,1024,* "
        ."DEF:'mem_cached'='${rrd_dir}/mem_cached.rrd':'sum':AVERAGE "
        ."CDEF:'bmem_cached'=mem_cached,1024,* "
        ."DEF:'mem_buffers'='${rrd_dir}/mem_buffers.rrd':'sum':AVERAGE "
        ."CDEF:'bmem_buffers'=mem_buffers,1024,* "
        ."CDEF:'bmem_used'='bmem_total','bmem_shared',-,'bmem_free',-,'bmem_cached',-,'bmem_buffers',- "
        ."AREA:'bmem_used'#$mem_used_color:'使用内存' "
        ."STACK:'bmem_shared'#$mem_shared_color:'共享内存' "
        ."STACK:'bmem_cached'#$mem_cached_color:'缓存内存' "
        ."STACK:'bmem_buffers'#$mem_buffered_color:'缓冲内存' ";

    if (file_exists("$rrd_dir/swap_total.rrd")) {
        $series .= "DEF:'swap_total'='${rrd_dir}/swap_total.rrd':'sum':AVERAGE "
            ."DEF:'swap_free'='${rrd_dir}/swap_free.rrd':'sum':AVERAGE "
            ."CDEF:'bmem_swapped'='swap_total','swap_free',-,1024,* "
            ."STACK:'bmem_swapped'#$mem_swapped_color:'交换内存' ";
    }

    $series .= "LINE2:'bmem_total'#$cpu_num_color:'总核心内存' ";

    $rrdtool_graph['series'] = $series;

    return $rrdtool_graph;

}

?>
