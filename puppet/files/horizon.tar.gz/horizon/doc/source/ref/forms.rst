=============
Horizon Forms
=============

Horizon ships with a number of generic form classes.

Generic Forms
=============

.. automodule:: horizon.forms
    :members:
