from horizon import test


class TigersTests(test.TestCase):
    # Unit tests for tigers.
    def test_me(self):
        self.assertTrue(1 + 1 == 2)
