#decorator by weiyuanke123@gmail.com
from django.core.handlers import wsgi
from horizon.models import *
import datetime
from django.utils.translation import ugettext_lazy as _

def log_op(arg):
    def _origin(func):
        def origin(*args, **kargs):
            if isinstance(args[0], wsgi.WSGIRequest) and args[0].user.is_authenticated():
                client_ip = args[0].META['REMOTE_ADDR']
                roles = [role['name'] for role in args[0].user.roles]
                role = 'None' if not roles else roles[0]
                user = args[0].user.token.user['name']
                tenant = args[0].user.token.tenant['name']
                optime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                op = arg
                note="None"
                user_id = args[0].user.id
                tenant_id = args[0].user.tenant_id
                try:
                    func_result = func(*args, **kargs)
                    opobj = Operations(client_ip=client_ip, role=role, tenant=tenant, user=user, time=optime, operation=op, 
                                       result=True, detail='', note=note, user_id=user_id, tenant_id=tenant_id)    
                    opobj.save()
                except Exception, e:
                    opobj = Operations(client_ip=client_ip, role=role, tenant=tenant, user=user, time=optime, operation=op, 
                                       result=False, detail=_(e.message), note=note, user_id=user_id, tenant_id=tenant_id)    
                    opobj.save()
                    raise e
            return func_result
        return origin
    return _origin
