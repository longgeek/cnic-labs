# vim: tabstop=4 shiftwidth=4 softtabstop=4
#
# Copyright 2012 Nebula, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
from django.core.handlers import wsgi
from memcacheclient import MemcacheClient
import functools
import hashlib

LOCK_KEY = 'lock'
LOCK_TIME = 60
CACHE_TIME = 60

CACHE_LOCK = MemcacheClient()

class lock_cache(object):
    def __init__(self, func):
        self.func = func
    
    def __call__(self, *args, **kwargs):
        CACHE_LOCK.set(LOCK_KEY, True, LOCK_TIME)
        return self.func(*args, **kwargs) 

class memoized(object):
    '''Decorator. Caches a function's return value each time it is called.
    If called later with the same arguments, the cached value is returned
    (not reevaluated).
    '''
    def __init__(self, func):
        self.func = func
        self.cache = MemcacheClient()

    #added by xjzhu@cnic.cn
    def __call__(self, *args, **kwargs):
    
        key_list = []

        #put func name to key list
        key_list.append(self.func.func_name)

        #put args to key list
        for arg in args:
            if isinstance(arg, wsgi.WSGIRequest):
                key_list.append(arg.path)
                key_list.append(arg.user.username)
                key_list.append(arg.user.token.id)
                key_list.append(arg.user.tenant_id)
            else:
                key_list.append(arg)

        #put kwargs to key list
        key_kwargs = sorted(kwargs.items())
        key_list.append(key_kwargs)

        #use md5 of key list as cache key
        key = hashlib.md5(str(key_list)).hexdigest()

        is_locked = CACHE_LOCK.get(LOCK_KEY)
        if not is_locked is None and is_locked is True:
            value = self.func(*args, **kwargs)
            self.cache.set(key, value, CACHE_TIME)
            return value
        else:
            value = self.cache.get(key)
            if not value is None:
                return value
            else:
                value = self.func(*args, **kwargs)       
                self.cache.set(key, value, CACHE_TIME)
                return value

    def __repr__(self):
        '''Return the function's docstring.'''
        return self.func.__doc__

    def __get__(self, obj, objtype):
        '''Support instance methods.'''
        return functools.partial(self.__call__, obj)

    
