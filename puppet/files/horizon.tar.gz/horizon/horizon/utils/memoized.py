# vim: tabstop=4 shiftwidth=4 softtabstop=4
#
# Copyright 2012 Nebula, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
from django.core.handlers import wsgi
import functools
import timeutils
import hashlib

NEXT_ACTION = [] 

def reflected(*args):
    def _origin(func):
        def origin(*args, **kwargs):
            return func(*args, **kwargs)
        return origin

    for next_action in args:
        NEXT_ACTION.append(next_action)
    return _origin
    

class memoized(object):
    '''Decorator. Caches a function's return value each time it is called.
    If called later with the same arguments, the cached value is returned
    (not reevaluated).
    '''
    def __init__(self, func):
        self.func = func
        self.cache = MemcacheClient()
        #self.dict_cache = {}
        #self.django_cache = cache

    #def __call__(self, *args):
    #    try:
    #        return self.cache[args]
    #    except KeyError:
    #        value = self.func(*args)
    #        self.cache[args] = value
    #        return value
    #    except TypeError:
    #        # uncachable -- for instance, passing a list as an argument.
    #        # Better to not cache than to blow up entirely.
    #        return self.func(*args)

    #added by xjzhu@cnic.cn
    def __call__(self, *args, **kwargs):
     
        key_list = []

        key_list.append(self.func.func_name)
        #put args to key list
        for arg in args:
            if isinstance(arg, wsgi.WSGIRequest):
                key_list.append(arg.path)
                key_list.append(arg.user.username)
                key_list.append(arg.user.token.id)
                key_list.append(arg.user.tenant_id)
            else:
                key_list.append(arg)

        #put kwargs to key list
        key_kwargs = sorted(kwargs.items())
        key_list.append(key_kwargs)

        key = hashlib.md5(str(key_list)).hexdigest()

        if self.func.func_name in NEXT_ACTION:
            NEXT_ACTION.remove(self.func.func_name)
            value = self.func(*args, **kwargs)
            self.cache.set(key, value, 60)
            return value

        value = self.cache.get(key)
        if not value is None:
            return value
        value = self.func(*args, **kwargs)       
        self.cache.set(key, value, 300)
        return value

    def __repr__(self):
        '''Return the function's docstring.'''
        return self.func.__doc__

    def __get__(self, obj, objtype):
        '''Support instance methods.'''
        return functools.partial(self.__call__, obj)

class MemcacheClient(object):
    """Replicates a tiny subset of memcached client interface."""

    def __init__(self, *args, **kwargs):
        """Ignores the passed in args."""
        self.cache = {}

    def get(self, key):
        """Retrieves the value for a key or None.

        this expunges expired keys during each get"""

        for k in self.cache.keys():
            (timeout, _value) = self.cache[k]
            if timeout and timeutils.utcnow_ts() >= timeout:
                del self.cache[k]

        return self.cache.get(key, (0, None))[1]

    def set(self, key, value, time=0, min_compress_len=0):
        """Sets the value for a key."""
        timeout = 0
        if time != 0:
            timeout = timeutils.utcnow_ts() + time
        self.cache[key] = (timeout, value)
        return True

    def add(self, key, value, time=0, min_compress_len=0):
        """Sets the value for a key if it doesn't exist."""
        if not self.get(key) is None:
            return False
        return self.set(key, value, time, min_compress_len)

    def incr(self, key, delta=1):
        """Increments the value for a key."""
        value = self.get(key)
        if value is None:
            return None
        new_value = int(value) + delta
        self.cache[key] = (self.cache[key][0], str(new_value))
        return new_value
    
