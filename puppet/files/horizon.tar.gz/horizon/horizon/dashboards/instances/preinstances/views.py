# vim: tabstop=4 shiftwidth=4 softtabstop=4
from django.core.urlresolvers import reverse, reverse_lazy
from django.utils.translation import ugettext_lazy as _
from django.conf import settings

from horizon import api
from horizon import exceptions
from horizon import forms
from horizon import tables

from .forms import RejectForm
from .tables import PreinstancesTable


class IndexView(tables.DataTableView):
    table_class = PreinstancesTable
    template_name = 'instances/preinstances/index.html'

    def get_data(self):
        page_index = int(self.request.GET.get(PreinstancesTable.Meta.pagination_param, "1"))
        page_size = int(getattr(settings, 'API_RESULT_PAGE_SIZE', 10))
        self.table.total_items = api.nova.server_register_list_count(self.request, search_opts = {'project_id' : self.request.user.tenant_id})

        self.user_dict = {}
        users = api.keystone.user_list(self.request)
        for user in users:
            self.user_dict[user.id] = user.name
        self.tenant_dict = {}
        tenants = api.keystone.tenant_list(self.request)
        for tenant in tenants:
            self.tenant_dict[tenant.id] = tenant.name

        ins = api.nova.server_register_list(self.request, search_opts = {'project_id' : self.request.user.tenant_id})

        for prein in ins:
            prein.user_name = self.user_dict.get(prein.user_id, '')
            prein.tenant_name = self.tenant_dict.get(prein.project_id, '')
        return ins

class RejectView(forms.ModalFormView):
    form_class = RejectForm
    template_name = 'instances/preinstances/reject.html'
    context_object_name = 'preinstance'
    success_url = reverse_lazy('horizon:instances:preinstances:index')

    def get_object(self):
        if not hasattr(self, "_object"):
            try:
                
                # jnfu
                obj_id = int(self.kwargs['preid'])
                prelist = [temp for temp in api.nova.server_register_list(self.request) if obj_id == temp.id]
                self._object = prelist[0]
            except:
                redirect = reverse("horizon:instances:preinstances:index")
                exceptions.handle(self.request, _('%s does not exist') % _('Instance application'), redirect=redirect)
        return self._object

    def get_context_data(self, **kwargs):
        context = super(RejectView, self).get_context_data(**kwargs)
        context['preid'] = self.kwargs['preid']
        return context

    def get_initial(self):
        return {'id': self.kwargs['preid'],
                'detail': getattr(self.get_object(), 'detail', '')}