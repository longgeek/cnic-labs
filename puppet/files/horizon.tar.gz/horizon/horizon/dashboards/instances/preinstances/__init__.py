class PREINSTANCE_STATUS():
    APPLY = 'Apply'
    REJECT = 'Reject'
    APPROVED = 'Approved'
    DELETED = 'Deleted'