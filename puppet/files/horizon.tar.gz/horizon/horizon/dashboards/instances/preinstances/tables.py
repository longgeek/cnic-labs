import logging
import datetime

from django.utils.translation import ugettext_lazy as _
from django.utils.text import normalize_newlines

from horizon import api
from horizon import tables
from horizon import exceptions
from . import PREINSTANCE_STATUS

LOG = logging.getLogger(__name__)

class RejectLink(tables.LinkAction):
    name = "reject"
    verbose_name = _("Reject Apply")
    url = "horizon:instances:preinstances:reject"
    classes = ("ajax-modal", "btn-edit")
    icon_path = "/static/dashboard/image/002.png"

    def allowed(self, request, preinstance):
        if preinstance:
            return preinstance.status != PREINSTANCE_STATUS.DELETED and preinstance.status != PREINSTANCE_STATUS.APPROVED
        return True

class ApproveAction(tables.BatchAction):
    name = "approve"
    action_present = _("Approve")
    action_past = _("Approved")
    classes = ('btn-danger', 'btn-approve')
    data_type_singular = _("Preinstances")
    data_type_plural = _("Preinstances")
    permissions = ("openstack.roles.admin", "openstack.roles.reselleradmin")
    icon_path = "/static/dashboard/image/001.png"

    def allowed(self, request, preinstance):
        if preinstance:
            return preinstance.status != PREINSTANCE_STATUS.DELETED and preinstance.status != PREINSTANCE_STATUS.APPROVED
        return True
 
    def action(self, request, obj_id):
        try:
            preinstance = api.server_register_get(request, obj_id)
            custom_script = "#!/bin/bash\nuseradd -m " + preinstance.username + "\n"
            custom_script = custom_script + "passwd "+ preinstance.username +" << EOF\n" + preinstance.password +"\n"+ preinstance.password +"\nEOF\n"
            custom_script = custom_script + "passwd root << EOF\n"+ preinstance.password +"\n"+ preinstance.password +"\nEOF\n"
            instance = api.nova.server_create(request,
                                              preinstance.display_name,
                                              preinstance.image_id if preinstance.source_type=="image" else preinstance.snapshot_id,
                                              preinstance.flavor_id,
                                              '',
                                              normalize_newlines(custom_script),
                                              preinstance.password,
                                              ['default'],
                                              None,
                                              nics=None,
                                              instance_count=1)
            api.nova.server_change_ownership(request, instance.id, preinstance.project_id, preinstance.user_id)
            api.nova.server_register_update_status(request, preinstance.id, PREINSTANCE_STATUS.APPROVED)
            return True
        except Exception:
            exceptions.handle(request, _('%s does not exist') % _('Instance application'))
            return False

def get_status(preinstance):
    return _(preinstance.status);

def get_created_at(preinstance):
    return datetime.datetime.strptime(preinstance.created_at, "%Y-%m-%dT%H:%M:%S.%f").strftime("%Y-%m-%d %H:%M:%S")

def transform_insert_time(table, value):
    try:
        return datetime.datetime.strptime(value[0], "%Y-%m-%d %H:%M:%S").isoformat()
    except Exception:
        return None

def transform_username(table, value):
    users = api.keystone.user_list_by_page(table.request, search_opts ={'name' : value[0]}, page_index = 1, page_size=10)
    for user in users:
        if user.name == value[0]:
            return {'user_id' : user.id}
    return {'user_id' : value[0]}

def transform_usergroupname(table, value):
    tenants = api.keystone.tenant_list_by_page(table.request, search_opts ={'name' : value[0]}, page_index = 1, page_size=10)
    for tenant in tenants:
        if tenant.name == value[0]:
            return {'project_id' : tenant.id}
    return {'project_id' : value[0]}

class PreinstancesTable(tables.DataTable):
    STATUS_CHOICES = (
        ('true', True),
        ('false', False)
    )
    STATUS_QUERY_CHOICES = [
        ("",""),
        ("Apply", _("Apply")),
        ("Reject",_("Reject")),
        ("Approved", _("Approved"))
    ]
    display_name = tables.Column('display_name', verbose_name=_('Name'), attrs={'width':'15%'}, is_query=True)
    status = tables.Column(get_status, verbose_name=_('Status'), attrs={'width':'6%'}, is_query=True, query_choices=STATUS_QUERY_CHOICES)
    detail = tables.Column('detail', verbose_name=_('Detail'), is_query=True)
    insert_time = tables.Column(get_created_at, verbose_name=_('Insert Time'), attrs={'width':'10%'}, is_query=True, query_transform=transform_insert_time)
    user_id = tables.Column('user_name', verbose_name=_('User Name'), attrs={'width':'10%'}, is_query=True, query_transform=transform_username)
    project_id = tables.Column('tenant_name', verbose_name=_('Tenant'), attrs={'width':'10%'}, is_query=True, query_transform=transform_usergroupname)

    def get_object_id(self, datum):
        return str(datum.id)

    class Meta:
        name = "preinstances"
        verbose_name = _("Preinstances")
        pagination_param = "page_index"
        row_actions = (ApproveAction, RejectLink)
        table_actions = (ApproveAction, tables.FilterAction)
