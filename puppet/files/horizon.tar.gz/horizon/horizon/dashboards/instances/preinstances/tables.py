import logging

from django.utils.translation import ugettext_lazy as _
from django.utils.text import normalize_newlines

from horizon import api
from horizon import tables
from horizon import exceptions
from . import PREINSTANCE_STATUS

LOG = logging.getLogger(__name__)

class RejectLink(tables.LinkAction):
    name = "reject"
    verbose_name = _("Reject Apply")
    url = "horizon:instances:preinstances:reject"
    classes = ("ajax-modal", "btn-edit")
    icon_path = "/static/dashboard/image/002.png"

    def allowed(self, request, preinstance):
        return preinstance.status != PREINSTANCE_STATUS.DELETED and preinstance.status != PREINSTANCE_STATUS.APPROVED

class ApproveAction(tables.BatchAction):
    name = "approve"
    action_present = _("Approve")
    action_past = _("Approved")
    classes = ('btn-danger', 'btn-approve')
    data_type_singular = _("Preinstances")
    data_type_plural = _("Preinstances")
    permissions = ("openstack.roles.admin", "openstack.roles.reselleradmin")
    icon_path = "/static/dashboard/image/001.png"

    def allowed(self, request, preinstance):
        return preinstance.status != PREINSTANCE_STATUS.DELETED and preinstance.status != PREINSTANCE_STATUS.APPROVED
 
    def action(self, request, obj_id):
        try:
            # jnfu
            obj_id = int(obj_id)
            prelist = [temp for temp in api.nova.server_register_list(request) if obj_id == temp.id]
            preinstance = prelist[0]
            custom_script = "#!/bin/bash\nuseradd -m " + preinstance.username + "\n"
            custom_script = custom_script + "passwd "+ preinstance.username +" << EOF\n" + preinstance.password +"\n"+ preinstance.password +"\nEOF\n"
            custom_script = custom_script + "passwd root << EOF\n"+ preinstance.password +"\n"+ preinstance.password +"\nEOF\n"
            instance = api.nova.server_create(request,
                                              preinstance.display_name,
                                              preinstance.image_id if preinstance.source_type=="image" else preinstance.snapshot_id,
                                              preinstance.flavor_id,
                                              '',
                                              normalize_newlines(custom_script),
                                              preinstance.password,
                                              ['default'],
                                              None,
                                              nics=None,
                                              instance_count=1)
            api.nova.server_change_ownership(request, instance.id, preinstance.project_id, preinstance.user_id)
            api.nova.server_register_update_status(request, preinstance.id, PREINSTANCE_STATUS.APPROVED)
            return True
        except Exception:
            exceptions.handle(request, _('%s does not exist') % _('Instance application'))
            return False

def get_status(preinstance):
    return _(preinstance.status);

import datetime
def get_created_at(preinstance):
    return datetime.datetime.strptime(preinstance.created_at, "%Y-%m-%dT%H:%M:%S.%f").strftime("%Y-%m-%d %H:%M:%S")

class PreinstancesTable(tables.DataTable):
    STATUS_CHOICES = (
        ('true', True),
        ('false', False)
    )
    name = tables.Column('name', verbose_name=_('Name'), attrs={'width':'15%'})
    status = tables.Column(get_status, verbose_name=_('Status'), attrs={'width':'5%'})
    detail = tables.Column('detail', verbose_name=_('Detail'))
    insert_time = tables.Column(get_created_at, verbose_name=_('Insert Time'), attrs={'width':'10%'})
    user_id = tables.Column('user_name', verbose_name=_('User Name'), attrs={'width':'10%'})
    tenant_id = tables.Column('tenant_name', verbose_name=_('Tenant'), attrs={'width':'10%'})

    def get_object_id(self, datum):
        return str(datum.id)

    class Meta:
        name = "preinstances"
        verbose_name = _("Preinstances")
        pagination_param = "page_index"
        row_actions = (ApproveAction, RejectLink)
        table_actions = (ApproveAction,)
