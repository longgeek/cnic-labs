# vim: tabstop=4 shiftwidth=4 softtabstop=4

# Copyright 2012 United States Government as represented by the
# Administrator of the National Aeronautics and Space Administration.
# All Rights Reserved.
#
# Copyright 2012 Nebula, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import logging
import requests 
import ConfigParser


from django.core.urlresolvers import reverse
from django.utils.translation import ugettext_lazy as _
from django import shortcuts

from horizon import api
from horizon import exceptions
from horizon import forms
from horizon import messages
from horizon.utils.validators import validate_port_range
from horizon.utils import fields


LOG = logging.getLogger(__name__)


class UpdateInstance(forms.SelfHandlingForm):
    tenant_id = forms.CharField(widget=forms.HiddenInput)
    instance = forms.CharField(widget=forms.HiddenInput)
    name = forms.CharField(required=True, label=_("Name"))

    def handle(self, request, data):
        try:
            server = api.server_update(request, data['instance'], data['name'])
            messages.success(request,
                             _('Instance "%s" updated.') % data['name'])
            return server
        except:
            redirect = reverse("horizon:instances:instances:index")
            exceptions.handle(request,
                              _('Unable to update instance.'),
                              redirect=redirect)


class MappingPort(forms.SelfHandlingForm):
    tenant_id = forms.CharField(widget=forms.HiddenInput)
    instance = forms.CharField(widget=forms.HiddenInput)
    destinationip = forms.CharField(required=True, label=_("Destination IP"), widget=forms.TextInput(attrs={'readonly':'readonly'}))
    destinationport = forms.CharField(required=True, label=_("Destination Port"))

    def handle(self, request, data):
        try:
            cf = ConfigParser.ConfigParser()
            #cf.read('/opt/stack/iptables-add-select-delete/ipportanddatabase.conf')
            cf.read('../iptables-add-select-delete/ipportanddatabase.conf')
            ip= cf.get("item", "ip")
            port= cf.get("item", "port")
            url='http://'+ip+':'+port+'/'+'addport?a='
            url+=ip+'&b='+data['destinationip']+'&c='+data['destinationport']
            response = requests.get(url)
            if 'right' in response.content:
                msg = 'Port %s of %s was successfully mapping.'
                messages.success(request, _(msg) % (data['destinationip'],data['destinationport']))
            else:
                msg = 'Fail:Port %s of %s is already used.'
                messages.success(request, _(msg) % (data['destinationip'],data['destinationport']))
            return response.content
        except:
            pass
