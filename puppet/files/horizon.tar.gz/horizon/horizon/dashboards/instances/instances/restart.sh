#!/bin/bash

#service  apache2 restart
 service  apache2 stop 
 service  apache2 start

