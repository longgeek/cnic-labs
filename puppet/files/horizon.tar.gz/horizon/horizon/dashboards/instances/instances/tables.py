# vim: tabstop=4 shiftwidth=4 softtabstop=4

# Copyright 2012 Nebula, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import logging
import json
import ConfigParser
import requests
from django import template
from django.core import urlresolvers
from django.template.defaultfilters import title
from django.utils.http import urlencode
from django.utils.translation import ugettext_lazy as _
from django.utils.safestring import mark_safe
import os

from horizon import api
from horizon import tables
from horizon import exceptions
from horizon.templatetags import sizeformat
from horizon.utils.filters import replace_underscores

from horizon.dashboards.instances.floating_ips\
        .floating_ips.workflows import IPAssociationWorkflow
from .tabs import InstanceDetailTabs, LogTab, VNCTab


LOG = logging.getLogger(__name__)

ACTIVE_STATES = ("ACTIVE",)

POWER_STATES = {
    0: "NO STATE",
    1: "RUNNING",
    2: "BLOCKED",
    3: "PAUSED",
    4: "SHUTDOWN",
    5: "SHUTOFF",
    6: "CRASHED",
    7: "SUSPENDED",
    8: "FAILED",
    9: "BUILDING",
}

PAUSE = 0
UNPAUSE = 1
SUSPEND = 0
RESUME = 1


def _is_deleting(instance):
    task_state = getattr(instance, "OS-EXT-STS:task_state", None)
    if not task_state:
        return False
    return task_state.lower() == "deleting"

def _is_suspending(instance):
    task_state = getattr(instance, "OS-EXT-STS:task_state", None)
    if not task_state:
        return False
    return task_state.lower() == "suspending"


class TerminateInstance(tables.BatchAction):
    name = "terminate"
    action_present = _("Terminate")
    action_past = _("Scheduled termination of")
    data_type_singular = _("Instance")
    data_type_plural = _("Instances")
    classes = ('btn-danger', 'btn-terminate')
    icon_path = "/static/dashboard/image/shanchu.png"

#    def allowed(self, request, instance=None):
    def allowed(self, request, instance=None):
        if instance:
            # FIXME(gabriel): This is true in Essex, but in FOLSOM an instance
            # can be terminated in any state. We should improve this error
            # handling when LP bug 1037241 is implemented.
            return instance.status not in ("PAUSED", "SUSPENDED")
        return True
    
    def to_delete(self, request, instance):
        if 'private' in instance.addresses:
            try:
                cf = ConfigParser.ConfigParser()
                cf.read('../iptables-add-select-delete/ipportanddatabase.conf')
                ip = cf.get("item", "ip")
                port = cf.get("item", "port")
                del_ip = instance.addresses['private'][1]['addr']
                url='http://'+ip+':'+port+'/'+'deleteall?a='+del_ip
                response = requests.get(url)
                return response.content
            except:
                pass
        else:
            pass

    def action(self, request, obj_id):
        instance = api.server_get(request, obj_id)
        if instance:
            api.server_delete(request, obj_id)
            self.to_delete(request, instance)

#class EjectCdrom(tables.BatchAction):
#    name = "ejectcdrom"
#    action_present = _("Eject")
#    action_past = _("Eject")
#    data_type_singular = _("CDROM")
#    data_type_plural = _("CDROM")
#    classes = ('btn-danger', 'btn-terminate')
#    icon_path = "/static/dashboard/image/shanchu.png"
#
#    def allowed(self, request, instance=None):
#        return ((instance.status in ACTIVE_STATES) and instance.cdrom_active)
#
#    def action(self, request, obj_id):
#        api.nova.image_detach(request, obj_id)

class RebootInstance(tables.BatchAction):
    name = "reboot"
    action_present = _("Reboot")
    action_past = _("Rebooted")
    data_type_singular = _("Instance")
    data_type_plural = _("Instances")
    classes = ('btn-danger', 'btn-reboot')
    icon_path = "/static/dashboard/image/chongqi-01.png"

    def allowed(self, request, instance=None):
        return ((instance.status in ACTIVE_STATES
                 or instance.status == 'SHUTOFF')
                and not _is_deleting(instance))

    def action(self, request, obj_id):
        api.server_reboot(request, obj_id)


class TogglePause(tables.BatchAction):
    name = "pause"
    action_present = (_("Pause"), _("Unpause"))
    action_past = (_("Paused"), _("Unpaused"))
    data_type_singular = _("Instance")
    data_type_plural = _("Instances")
    classes = ("btn-pause",)
    icon_path = "/static/dashboard/image/zting-01.png"

    def allowed(self, request, instance=None):
        self.paused = False
        if not instance:
            return self.paused
        self.paused = instance.status == "PAUSED"
        if self.paused:
            self.current_present_action = UNPAUSE
        else:
            self.current_present_action = PAUSE
        return ((instance.status in ACTIVE_STATES or self.paused)
                and not _is_deleting(instance))

    def action(self, request, obj_id):
        if self.paused:
            api.server_unpause(request, obj_id)
            self.current_past_action = UNPAUSE
        else:
            api.server_pause(request, obj_id)
            self.current_past_action = PAUSE


class ToggleSuspend(tables.BatchAction):
    name = "suspend"
    action_present = (_("Suspend"), _("Resume"))
    action_past = (_("Suspended"), _("Resumed"))
    data_type_singular = _("Instance")
    data_type_plural = _("Instances")
    classes = ("btn-suspend",)
    icon_path = "/static/dashboard/image/gauqi.png"

    def allowed(self, request, instance=None):
        self.suspended = False
        if not instance:
            self.suspended
        self.suspended = instance.status == "SUSPENDED"
        if self.suspended:
            self.current_present_action = RESUME
        else:
            self.current_present_action = SUSPEND
        return ((instance.status in ACTIVE_STATES or self.suspended)
                and not _is_deleting(instance))

    def action(self, request, obj_id):
        if self.suspended:
            api.server_resume(request, obj_id)
            self.current_past_action = RESUME
        else:
            api.server_suspend(request, obj_id)
            self.current_past_action = SUSPEND


class LaunchLink(tables.LinkAction):
    name = "launch"
    verbose_name = _("Launch Instance")
    url = "horizon:instances:instances:launch"
    classes = ("btn-launch", "ajax-modal")
    icon_path = "/static/dashboard/image/xinjian.png"


class EditInstance(tables.LinkAction):
    name = "edit"
    verbose_name = _("Edit Instance")
    url = "horizon:instances:instances:update"
    classes = ("ajax-modal", "btn-edit")
    icon_path = "/static/dashboard/image/4-01.png"

    def allowed(self, request, instance):
        return not _is_deleting(instance)

class EditIns_Port(tables.LinkAction):
    name = "edit_port"
    verbose_name = _("Edit Port")
    url = "horizon:instances:instances:edit_port"
    classes = ("ajax-modal", "btn-edit")
    icon_path = "/static/dashboard/image/9-01.png"

    def allowed(self, request, instance):
        return instance.status in ACTIVE_STATES and (len(instance.addresses['private']) > 1) and not _is_deleting(instance)

class ConfirmResize(tables.LinkAction):
    name = 'confirm_resize'
    verbose_name = _("Confirm Resize")
    url = "horizon:instances:instances:confirmresize"
    classes = ('ajax-modal',"btn-associate")
    icon_path = "/static/dashboard/image/001.png"

    def allowed(self, request, instance=None):
        return instance.status in ('VERIFY_RESIZE',)

    def get_link_url(self, datum):
        params = urlencode({"instance_id": self.table.get_object_id(datum)})
        return "?".join([super(ConfirmResize, self).get_link_url(datum), params])


#add by shengeng
class RevertResize(tables.LinkAction):
    name = 'revert_resize'
    verbose_name = _("Revert Resize")
    url = "horizon:instances:instances:revertresize"
    classes = ('ajax-modal', "btn-associate")
    icon_path = "/static/dashboard/image/tingyong.png"

    def allowed(self, request, instance=None):
        return instance.status in ('VERIFY_RESIZE',)

    def get_link_url(self, datum):
        params = urlencode({"instance_id": self.table.get_object_id(datum)})
        return "?".join([super(RevertResize, self).get_link_url(datum), params])


class Resize(tables.LinkAction):
    name = "resize"
    verbose_name = _("Resize Instance")
    url = "horizon:instances:instances:resize"
    classes = ("ajax-modal", "btn-associate")
    icon_path = "/static/dashboard/image/9-01.png"


    def allowed(self, request, instance=None):
        return instance.status in ACTIVE_STATES and not _is_deleting(instance)

    def get_link_url(self, datum):
        params = urlencode({"instance_id": self.table.get_object_id(datum), "flavor_id" : datum.full_flavor.id})
        return "?".join([super(Resize, self).get_link_url(datum), params])
        #base_url = urlresolvers.reverse(self.url)
    #    next = urlresolvers.reverse("horizon:instances:instances:index")
        #params = {"instance_id": self.table.get_object_id(datum)}#,
                  #IPAssociationWorkflow.redirect_param_name: next}
        #params = urlencode(params)
    #    return self.url#"?".join([base_url, params])


class CreateSnapshot(tables.LinkAction):
    name = "snapshot"
    verbose_name = _("Create Snapshot")
    url = "horizon:instances:snapshots:snapshots:create"
    classes = ("ajax-modal", "btn-camera")
    icon_path = "/static/dashboard/image/02-01.png"

    def allowed(self, request, instance=None):
        return instance.status in ACTIVE_STATES and not _is_deleting(instance)


class ConsoleLink(tables.LinkAction):
    name = "console"
    verbose_name = _("VNC Console")
    url = "horizon:instances:instances:detail"
    classes = ("btn-console",)
    icon_path = "/static/dashboard/image/01-01.png"
    is_pop = True

#modify by haochennan
    def allowed(self, request, instance=None):
        return instance.status in ACTIVE_STATES and not (_is_deleting(instance) or _is_suspending(instance)) or instance.status in ('RESIZE', 'VERIFY_RESIZE')
#        return instance.status in ACTIVE_STATES and not _is_Suspending(instance) or instance.status in ('RESIZE', 'VERIFY_RESIZE')
    def get_link_url(self, datum):
        base_url = super(ConsoleLink, self).get_link_url(datum)
        return base_url + "vnc"

"""
    def get_link_url(self, datum):
        try:
            console = api.nova.server_vnc_console(datum.request, self.table.get_object_id(datum))
            self.base_url = "%s&title=%s(%s)" % (console.url, self.table.columns['name'].get_raw_data(datum),
                                                self.table.get_object_id(datum))
        except:
            self.base_url = "#"
        return self.base_url
        #return self.base_url
#        return mark_safe(url)
"""

class LogLink(tables.LinkAction):
    name = "log"
    verbose_name = _("View Log")
    url = "horizon:instances:instances:detail"
    classes = ("btn-log",)
    icon_path = "/static/dashboard/image/10-01.png"

    def allowed(self, request, instance=None):
        return instance.status in ACTIVE_STATES and not _is_deleting(instance)

    def get_link_url(self, datum):
        base_url = super(LogLink, self).get_link_url(datum)
        tab_query_string = LogTab(InstanceDetailTabs).get_query_string()
        return "?".join([base_url, tab_query_string])


class AssociateIP(tables.LinkAction):
    name = "associate"
    verbose_name = _("Associate Floating IP")
    url = "horizon:instances:floating_ips:floating_ips:associate"
    classes = ("ajax-modal", "btn-associate")
    icon_path = "/static/dashboard/image/banding.png"

    def allowed(self, request, instance):
        return not _is_deleting(instance)

    def get_link_url(self, datum):
        base_url = urlresolvers.reverse(self.url)
        next = urlresolvers.reverse("horizon:instances:instances:index")
        params = {"instance_id": self.table.get_object_id(datum),
                  IPAssociationWorkflow.redirect_param_name: next}
        params = urlencode(params)
        return "?".join([base_url, params])


class UpdateRow(tables.Row):
    ajax = True

    def get_data(self, request, instance_id):
        instance = api.server_get(request, instance_id)
        instance.full_flavor = api.flavor_get(request, instance.flavor["id"])
        return instance

class DeletePort(tables.DeleteAction):
    data_type_singular = _("Port")
    data_type_plural = _("Port")
    icon_path = "/static/dashboard/image/shanchu.png"

    def delete(self, request, instance):
        try:
            cf = ConfigParser.ConfigParser()
            cf.read('../iptables-add-select-delete/ipportanddatabase.conf')
            ip= cf.get("item", "ip")
            port= cf.get("item", "port")
            port_list = instance.split("_")
            url='http://'+ip+':'+port+'/'+'delete?a='+port_list[0]+'&b='+port_list[1]
            response = requests.get(url)
            return response.content
        except:
            redirect = urlresolvers.reverse("horizon:instances:instances:index")
            exceptions.handle(request,
                              _('Unable to update instance.'),
                              redirect=redirect)

    def get_success_url(self, request):
        return urlresolvers.reverse("horizon:instances:instances:index")

def get_ips(instance):
    template_name = 'instances/instances/_instance_ips.html'
    context = {"instance": instance}
    return template.loader.render_to_string(template_name, context)


def get_usage(instance):
    if instance.status in ACTIVE_STATES:
        ret = "<div class='rsusage' value='" + instance.id + "' >"+ "<table class='rsusageTbl' width='100%' height='100%' border='0' cellpadding='0' cellspacing='0' ><tr><td width='5%'><B>CPU: </B></td><td width='90%'>--</td><td width='5%'></td></tr><tr><td><B>RAM: </B></td><td>--</td><td></td></tr></table></div>"
    else:
        ret = "<div class='rsusage9' >"+ "<table class='rsusageTbl' width='100%' height='100%' border='0' cellpadding='0' cellspacing='0' ><tr><td width='5%'><B>CPU: </B></td><td width='90%'>--</td><td width='5%'></td></tr><tr><td><B>RAM: </B></td><td>--</td><td></td></tr></table></div>"
    return mark_safe(ret)


#def get_iname(instance):
#    return instance.image_name


def get_size(instance):
    if hasattr(instance, "full_flavor"):
        size_string = _("%(name)s<br>%(RAM)s RAM<br>%(VCPU)s VCPU"
                        "<br>%(disk)s Disk")
        vals = {'name': instance.full_flavor.name,
                'RAM': sizeformat.mbformat(instance.full_flavor.ram),
                'VCPU': instance.full_flavor.vcpus,
                'disk': sizeformat.diskgbformat(instance.full_flavor.disk)}
        return mark_safe(size_string % vals)
    return _("Not available")


def get_keyname(instance):
    if hasattr(instance, "key_name"):
        keyname = instance.key_name
        return keyname
    return _("Not available")


#def get_power_state(instance):
#    return POWER_STATES.get(getattr(instance, "OS-EXT-STS:power_state", 0), '')


#def get_user_name(instance):
#    user = api.user_get(instance.request, user_id = instance.user_id)
#    return  "" if not user else user.name

#by weiyuanke
def _build_dict(filter_string):
    result = {}
    for con in filter_string.split("&&"):
        scon = con.split(":")
        result[scon[0]]=scon[1]
    return result

#by weiyuanke
class InstanceFilterAction(tables.FilterAction):
    def filter(self, table, tenants, filter_string):
#	search_opts = {}
#        search_opts['host'] = filter_string
#        try:
#            instances = api.server_list(self.request, search_opts, all_tenants=True)
#        except:
#            instances = []
#            self._more = False
#            exceptions.handle(self.request, _('Unable to retrieve instances.'))
        q = filter_string.lower()

        def comp(tenant):
            if q in tenant.name.lower():
                return True
            return False

        return filter(comp, tenants)

#add by haochennan
def transform_username(table, value):
    users = api.keystone.user_list(table.request)
    for user in users:
        if user.name == value[0]:
            return {'user_id' : user.id}
    return {'user_id' : value}


def query_imagename_choices(table):
    try:
        all_images = api.glance.image_list_detailed(table.request)
        images = [im for im in all_images[0]
                  if im.container_format not in ['aki', 'ari'] and
                  im.properties.get("image_type", '') != "snapshot"]
        image_list = [(image.id, "%s" % (image.name)) for image in images]
        image_list[0:0] = [('','')]
    except:
        image_list = [('','')]
    return image_list


def transform_imagename(table, value):
    return {'image': value[0]}


def query_flavor_choices(table):
    try:
        flavors = api.nova.flavor_list(table.request)
        flavor_list = [(flavor.id, "%s(%s)" % (flavor.name, flavor.id)) for flavor in flavors]
        flavor_list[0:0] = [('','')]
    except:
        flavor_list = [('','')]
    return flavor_list


def transform_size(table, value):
    return {'flavor': value[0]}
    

def transform_task_status(table, value):
    return {'task_state':value[0]}


def instance_status(instance):
    return _(instance.status)


class PortTable(tables.DataTable):
    sourceip = tables.Column("sourceip",verbose_name=_("Source IP"))
    sourceport = tables.Column("sourceport", verbose_name=_("Source Port"))
    destinationip = tables.Column("destinationip", verbose_name=_("Destination IP"))
    destinationport = tables.Column("destinationport", verbose_name=_("Destination Port"))

    class Meta:
        name = "port"
        verbose_name = _("Port Table")
        table_actions = (DeletePort,)
        row_actions = (DeletePort,)


class InstancesTable(tables.DataTable):
    TASK_STATUS_CHOICES = (
        (_("-"), True),
        ("-", True),
    )
    STATUS_CHOICES = (
        (_("ACTIVE"), True),
        (_("RESIZE"), True),
        (_("BUILD"), True),
        (_("HARD_REBOOT"), True),
        (_("SHUTOFF"), True),
        (_("SUSPENDED"), True),
        (_("PAUSED"), True),
        (_("VERIFY_RESIZE"), True),
        (_("REVERT_RESIZE"), True),
        (_("ERROR"), False),
    )
    STATUS_QUERY_CHOICES = [
        ("",""),
        ("ACTIVE", _("ACTIVE")),
        ("RESIZE",_("RESIZE")),
        ("BUILD", _("BUILD")),
        ("HARD_REBOOT", _("HARD_REBOOT")),
        ("SHUTOFF", _("SHUTOFF")),
        ("SUSPENDED", _("SUSPENDED")),
        ("PAUSED", _("PAUSED")),
        ("ERROR", _("ERROR")),
    ]
    TASK_DISPLAY_CHOICES = (
        ("","-"),
        ("image_snapshot", _('Snapshotting')),
        ("pausing", _('Pausing')),
        ("unpausing", _('Unpausing')),
        ("suspending", _('Suspending')),
        ("resuming", _('Resuming')),
        ("resize_prep", _('Resize Prep')),
        ("resize_migrating", _('Resize Migrating')),
        ("resize_migrated", _('Resize Migrated')),
        ("resize_finish", _('Resize Finish')),
        ("resize_reverting", _('Resize Reverting')),
        ("resize_confirming", _('Resize Confirming')),
        ("rebooting", _('Rebooting')),
        ("rebooting_hard", _('Rebooting Hard')),
        ("deleting", _('Deleting')),
        ("scheduling", _('Scheduling')),
        ("block_device_mapping", _('Block Device Mapping')),
        ("networking", _('Networking')),
        ("spawning", _('Spawning')),
        ("image_backup", _('Image Backup')),
        ("updating_password", _('Updating Password')),
        ("stopping", _('Stopping')),
        ("starting", _('Starting')),
        ("powering-off", _('Powering Off')),
        ("powering-on", _('Powering On')),
        ("rescuing", _('Rescuing')),
        ("unrescuing", _('Unrescuing')),
        ("rebuilding", _('Rebuilding')),
        ("rebuild_block_device_mapping", _('Rebuild Block Device Mapping')),
        ("rebuild_spawning", _('Rebuild Spawning')),
        ("migrating", _('Migrating')),
    )
    TASK_QUERY_CHOICES = [
        ("",""),
        ("image_snapshot", _('Snapshotting')),
        ("pausing", _('Pausing')),
        ("unpausing", _('Unpausing')),
        ("suspending", _('Suspending')),
        ("resuming", _('Resuming')),
        ("resize_prep", _('Resize Prep')),
        ("resize_migrating", _('Resize Migrating')),
        ("resize_migrated", _('Resize Migrated')),
        ("resize_finish", _('Resize Finish')),
        ("resize_reverting", _('Resize Reverting')),
        ("resize_confirming", _('Resize Confirming')),
        ("rebooting", _('Rebooting')),
        ("deleting", _('Deleting')),
        ("networking", _('Networking')),
        ("spawning", _('Spawning')),
        ("updating_password", _('Updating Password')),
        ("stopping", _('Stopping')),
        ("starting", _('Starting')),
        ("migrating", _('Migrating')),
    ]
    name = tables.Column("name",
                         link=("horizon:instances:instances:detail"),
                         verbose_name=_("Name"), 
                         is_query=True)
    host = tables.Column("OS-EXT-SRV-ATTR:host",
                        permissions=('openstack.roles.admin',),
                        verbose_name=_("Host"),
                        classes=('nowrap-col'), 
                        is_query=True)
    ip = tables.Column(get_ips, verbose_name=_("IP Address"), 
                       is_query=True)
    size = tables.Column(get_size,
                         verbose_name=_("Size"),
                         attrs={'data-type': 'size'}, 
                         is_query=True,
                         populate_query_choices=query_flavor_choices,
                         query_transform=transform_size)
#    iname = tables.Column(get_iname,
    image_name = tables.Column("image_name",
                               verbose_name=_("Image Name"), attrs={'width':'14%'}, 
                               is_query=True,
                               populate_query_choices=query_imagename_choices,
                               query_transform=transform_imagename)
    status = tables.Column(instance_status,
                           verbose_name=_("Status"),
                           status=True,
                           status_choices=STATUS_CHOICES, attrs={'width':'5%'}, 
                           is_query=True,
                           query_choices=STATUS_QUERY_CHOICES)
#    status = tables.Column("status",
#                           filters=(title, replace_underscores),
#                           verbose_name=_("Status"),
#                           status=True,
#                           status_choices=STATUS_CHOICES, attrs={'width':'5%'})
    task = tables.Column("OS-EXT-STS:task_state",
                         hidden=False,
                         verbose_name=_("Task"),
                         filters=(title, replace_underscores),
                         status=True,
                         status_choices=TASK_STATUS_CHOICES,
                         display_choices=TASK_DISPLAY_CHOICES, 
                         is_query=True,
                         query_transform=transform_task_status,
                         query_choices=TASK_QUERY_CHOICES)
    usage = tables.Column(get_usage,
                          verbose_name=_("Usage"), attrs={'width':'190px', 'style':'min-width:190px; border-top-left-radius:0px'})
    user = tables.Column("user_name",
                         verbose_name=_("User Name"),
                         permissions=('openstack.roles.admin',), 
                         is_query=True,
                         query_transform=transform_username)

    class Meta:
        name = "instances"
        verbose_name = _("Instances")
        status_columns = ["status","task"]
        pagination_param = "page_index"
        row_class = UpdateRow
        table_actions = (InstanceFilterAction, LaunchLink, TerminateInstance)
        #row_actions = (ConsoleLink, CreateSnapshot, Resize, ConfirmResize, RevertResize,
        row_actions = (ConsoleLink, CreateSnapshot, 
                       #AssociateIP, EditInstance, EditIns_Port, LogLink, ToggleSuspend, 
                       AssociateIP, EditInstance, EditIns_Port, LogLink, 
                       RebootInstance, TerminateInstance)

