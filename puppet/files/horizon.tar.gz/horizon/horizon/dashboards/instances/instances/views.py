# vim: tabstop=4 shiftwidth=4 softtabstop=4

# Copyright 2012 United States Government as represented by the
# Administrator of the National Aeronautics and Space Administration.
# All Rights Reserved.
#
# Copyright 2012 Nebula, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

"""
Views for managing Nova instances.
"""
import logging
import json
import ConfigParser
import requests
#import random
#import math

from django import http
from django import shortcuts
from django.core.urlresolvers import reverse, reverse_lazy
from django.utils.datastructures import SortedDict
from django.utils.translation import ugettext_lazy as _
from django.conf import settings
from django import shortcuts

from horizon import api
from horizon import exceptions
from horizon import forms
from horizon import tabs
from horizon import tables
from horizon import workflows
from .forms import UpdateInstance, MappingPort
from .tabs import InstanceDetailTabs
from .tables import InstancesTable, PortTable
from .workflows import LaunchInstance
from .workflows import InstanceResize
from .workflows import ConfirmInstanceResize, RevertInstanceResize


LOG = logging.getLogger(__name__)

class IndexView(tables.DataTableView):
    table_class = InstancesTable
    template_name = 'instances/instances/index.html'

    def porttable(self, request, instances):
        try:
            cf = ConfigParser.ConfigParser()
            cf.read('../iptables-add-select-delete/ipportanddatabase.conf')
            ip= cf.get("item", "ip")
            port= cf.get("item", "port")
            url='http://'+ip+':'+port+'/'+'selectall'
            response = requests.get(url)
            ip_port = response.content
            for ip_dic in eval('('+ ip_port +')'):
                for ins in instances:
                    if 'destinationip' in ip_dic:
                        if 'private' in ins.addresses and len(ins.addresses['private']) > 1 and ins.addresses['private'][1]['addr'] == ip_dic['destinationip']:
                            if 'portmap' not in ins.addresses['private'][1]: ins.addresses['private'][1]['portmap'] = []
                            ins.addresses['private'][1].get('portmap').append(ip_dic)
        except:
            pass

    #modified by weiyuanke@cnic.cn
    def get_data(self):

        # Gather our instances
        page_index = self.request.GET.get(InstancesTable._meta.pagination_param, "1")
        try:
            user_name_dic = {tenant.id:tenant.name for tenant in api.keystone.user_list(self.request, tenant_id=None if self.request.user.is_superuser else self.request.user.tenant_id)}
            self._more = True
            condition = self.table.query_condition
            
            self.table.total_items = api.server_list_count(self.request, all_tenants=True, search_opts=condition)

            instances, self._more = api.server_list_paginate(self.request, all_tenants=True, search_opts=condition, page_index=int(page_index)-1)
            #if not condition:
            #    instances, self._more = api.server_list_paginate(self.request, all_tenants=True, page_index=int(page_index)-1)
            #else:
            #    instances = api.server_list(self.request, all_tenants=True, search_opts=condition)
        except:
            user_name_dic = {}
            instances = []
            self._more = False
            exceptions.handle(self.request, _('Unable to retrieve instances.'))
        if instances:
            # Gather our flavors and correlate our instances to them
            try:
                flavors = api.flavor_list(self.request)
            except:
                flavors = []
                exceptions.handle(self.request, ignore=True)

#            # Gather our tenants to correlate against IDs
#            try:
#                tenants = api.keystone.tenant_list(self.request, admin=False)
#            except:
#                tenants = []
#                msg = _('Unable to retrieve instance tenant information.')
#                exceptions.handle(self.request, msg)
#
#            tenant_dict = SortedDict([(t.id, t) for t in tenants])
            full_flavors = SortedDict([(str(flavor.id), flavor) for flavor in flavors])
            # Loop through instances to get flavor info.
            for instance in instances:
                instance.user_name = user_name_dic.get(instance.user_id, '')
                try:
                    flavor_id = instance.flavor["id"]
                    if flavor_id in full_flavors:
                        instance.full_flavor = full_flavors[flavor_id]
                    else:
                        # If the flavor_id is not in full_flavors list,
                        # get it via nova api.
                        instance.full_flavor = api.flavor_get(self.request,
                                                              flavor_id)
                        # add by zhuxg The name wouble be show deleted if the flavor had deleted 
                        if instance.full_flavor.id == "-1":
                            instance.full_flavor.name  = _('%s (Deleted)') % instance.full_flavor.name
                except:
                    msg = _('Unable to retrieve instance size information.')
                    exceptions.handle(self.request, msg)
#                tenant = tenant_dict.get(instance.tenant_id, None)
#                instance.tenant_name = getattr(tenant, "name", None)
        self.porttable(self.request, instances)
        return instances


class LaunchInstanceView(workflows.WorkflowView):
    workflow_class = LaunchInstance
    template_name = "instances/instances/launch.html"

    def get_initial(self):
        initial = super(LaunchInstanceView, self).get_initial()
        initial['project_id'] = self.request.user.tenant_id
        initial['user_id'] = self.request.user.id
        return initial


def console(request, instance_id):
    try:
        # TODO(jakedahn): clean this up once the api supports tailing.
        tail = request.GET.get('length', None)
        data = api.server_console_output(request,
                                        instance_id,
                                        tail_length=tail)
    except:
        data = _('Unable to get log for instance "%s".') % instance_id
        exceptions.handle(request, ignore=True)
    response = http.HttpResponse(mimetype='text/plain')
    response.write(data)
    response.flush()
    return response


def vnc(request, instance_id):
    try:
        console = api.server_vnc_console(request, instance_id)
        instance = api.server_get(request, instance_id)
        return shortcuts.redirect(console.url +
                ("&title=%s(%s)" % (instance.name, instance_id)))
    except:
        redirect = reverse("horizon:instances:instances:index")
        msg = _('Unable to get VNC console for instance "%s".') % instance_id
        exceptions.handle(request, msg, redirect=redirect)


class UpdateView(forms.ModalFormView):
    form_class = UpdateInstance
    template_name = 'instances/instances/update.html'
    context_object_name = 'instance'
    success_url = reverse_lazy("horizon:instances:instances:index")

    def get_context_data(self, **kwargs):
        context = super(UpdateView, self).get_context_data(**kwargs)
        context["instance_id"] = self.kwargs['instance_id']
        return context

    def get_object(self, *args, **kwargs):
        if not hasattr(self, "_object"):
            instance_id = self.kwargs['instance_id']
            try:
                self._object = api.server_get(self.request, instance_id)
            except:
                redirect = reverse("horizon:instances:instances:index")
                msg = _('Unable to retrieve instance details.')
                exceptions.handle(self.request, msg, redirect=redirect)
        return self._object

    def get_initial(self):
        return {'instance': self.kwargs['instance_id'],
                'tenant_id': self.request.user.tenant_id,
                'name': getattr(self.get_object(), 'name', '')}


class PortMapping() :
    def __init__(self, sourceip, sourceport, destinationip, destinationport):
        self.name = destinationip+':'+destinationport
        self.id= destinationip+'_'+destinationport
        self.sourceip = sourceip
        self.sourceport = sourceport
        self.destinationip = destinationip
        self.destinationport = destinationport
 
#added by haochennan
class EditPortView(tables.DataTableView, forms.ModalFormView):
    table_class = PortTable    
    form_class = MappingPort
    template_name = 'instances/instances/edit_port.html'
    success_url = reverse_lazy("horizon:instances:instances:index")
     
    def get_context_data(self, **kwargs):
        context = super(EditPortView, self).get_context_data(**kwargs)
        context["instance_id"] = self.kwargs['instance_id']
        context["form"] = self.get_form()
        if self.request.is_ajax():
            context['hide'] = True
        return context

    def get_fips(self, *args, **kwargs):
        if not hasattr(self, "_fips"):
            instance_id = self.kwargs['instance_id']
            try:
                instance = api.server_get(self.request, instance_id)
                self._fips = instance.addresses['private'][1]['addr']
            except:
                redirect = reverse("horizon:instances:instances:index")
                msg = _('Unable to retrieve instance details.')
                exceptions.handle(self.request, msg, redirect=redirect)
        return self._fips

    def get_data(self, *args, **kwargs):
        try:
            instance_id = self.kwargs['instance_id']
            instance = api.server_get(self.request, instance_id)
            cf = ConfigParser.ConfigParser()
            cf.read('../iptables-add-select-delete/ipportanddatabase.conf')
            ip= cf.get("item", "ip")
            port= cf.get("item", "port")
            url='http://'+ip+':'+port+'/'+'selectall'
            response = requests.get(url)
            ip_port = response.content
            ports = []
            for ip_dic in eval('('+ ip_port +')'):
                if 'private' in instance.addresses and instance.addresses['private'][1]['addr'] == ip_dic['destinationip']:
                    ports.append(PortMapping(ip_dic['sourceip'], ip_dic['sourceport'], ip_dic['destinationip'], ip_dic['destinationport']))
        except:
            ports = []
        self.table.total_items = len(ports)
        if self.table.total_items > 0:
            self.table.page_size = len(ports)
        return ports

    def get_initial(self):
        return {'instance': self.kwargs['instance_id'],
                'tenant_id': self.request.user.tenant_id,
                'destinationip': self.get_fips()}

    def get_form(self):
        if not hasattr(self, "_form"):
            form_class = self.get_form_class()
            self._form = super(EditPortView, self).get_form(form_class)
        return self._form

    def get(self, request, *args, **kwargs):
        handled = self.construct_tables()
        if handled:
            return handled
        return self.render_to_response(self.get_context_data(**kwargs))

    def post(self, request, *args, **kwargs):
        form = self.get_form()
        if form.is_valid():
            return self.form_valid(form)
        else:
            return self.get(request, *args, **kwargs)

class ConfirmResizeView(workflows.WorkflowView):
    workflow_class = ConfirmInstanceResize
    template_name = 'instances/instances/confirmresize.html'

#add by shengeng
class RevertResizeView(workflows.WorkflowView):
    workflow_class = RevertInstanceResize
    template_name = 'instances/instances/revertresize.html'


class ResizeView(workflows.WorkflowView):
    workflow_class = InstanceResize
    template_name = 'instances/instances/resize.html'
    #context_object_name = 'instance'
    #success_url = reverse_lazy("horizon:instances:instances:index")

#    def get_context_data(self, **kwargs):
#        context = super(ResizeView, self).get_context_data(**kwargs)
#        context["instance_id"] = self.kwargs['instance_id']
#        return context
#
#    def get_object(self, *args, **kwargs):
#        if not hasattr(self, "_object"):
#            instance_id = self.kwargs['instance_id']
#            try:
#                self._object = api.server_get(self.request, instance_id)
#            except:
#                redirect = reverse("horizon:nova:instances:index")
#                msg = _('Unable to retrieve instance details.')
#                exceptions.handle(self.request, msg, redirect=redirect)
#        return self._object
#
#    def get_initial(self):
#        return {'instance': self.kwargs['instance_id'],
#                'tenant_id': self.request.user.tenant_id,
#                'name': getattr(self.get_object(), 'name', '')}

class DetailView(tabs.TabView):
    tab_group_class = InstanceDetailTabs
    template_name = 'instances/instances/detail.html'

    def get_context_data(self, **kwargs):
        context = super(DetailView, self).get_context_data(**kwargs)
        context["instance"] = self.get_data()
        return context

    def get_data(self):
        if not hasattr(self, "_instance"):
            try:
                instance_id = self.kwargs['instance_id']
                instance = api.server_get(self.request, instance_id)
                instance.volumes = api.volume_instance_list(self.request,
                                                            instance_id)
                # Sort by device name
                instance.volumes.sort(key=lambda vol: vol.device)
                instance.full_flavor = api.flavor_get(self.request,
                                                      instance.flavor["id"])
                instance.security_groups = api.server_security_groups(
                                           self.request, instance_id)
            except:
                redirect = reverse('horizon:instances:instances:index')
                exceptions.handle(self.request,
                                  _('Unable to retrieve details for '
                                    'instance "%s".') % instance_id,
                                    redirect=redirect)
            self._instance = instance
        return self._instance

    def get_tabs(self, request, *args, **kwargs):
        instance = self.get_data()
        return self.tab_group_class(request, instance=instance, **kwargs)
