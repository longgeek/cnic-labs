# vim: tabstop=4 shiftwidth=4 softtabstop=4

#from django.views.generic import TemplateView
from horizon import usage
from horizon import api
#import logging
#import math

#from django import shortcuts
from horizon import tables
#from django.conf import settings
from horizon.usage import BaseUsage
from horizon.usage.tables import TenantUsageTable
import datetime

class IndexView(tables.DataTableView):
    show_terminated = False
    table_class = usage.TenantUsageTable
    usage_class = usage.TenantUsage
    template_name = 'instances/overview/usage.html'

    def __init__(self, *args, **kwargs):
        super(IndexView, self).__init__(*args, **kwargs)
        if not issubclass(self.usage_class, BaseUsage):
            raise AttributeError("You must specify a usage_class attribute "
                                 "which is a subclass of BaseUsage.")

    def get_data(self):
        tenant_id = self.kwargs.get('tenant_id', self.request.user.tenant_id)
        self.usage = self.usage_class(self.request, tenant_id)
        page_index = self.request.GET.get(TenantUsageTable._meta.pagination_param, 1)
        self.usage.summarize(*self.usage.get_date_range(), page_index=(int(page_index)-1))
        data = self.usage.get_instances()
        date_time = self.usage.get_date_range()
        self.table.total_items = api.usage_count(self.request, tenant_id,datetime.datetime(date_time[0].year, date_time[0].month,\
                       date_time[0].day, date_time[0].hour, date_time[0].minute), datetime.datetime(date_time[1].year,\
                           date_time[1].month, date_time[1].day, date_time[1].hour, date_time[1].minute))
#        self.table.total_items = api.usage_count(self.request, tenant_id, datetime.datetime(2013, 6, 1), datetime.datetime(2013, 6, 15))
        return data

    def get_context_data(self, **kwargs):
        context = super(IndexView, self).get_context_data(**kwargs)
        all_tenants=True
        quotas = api.nova.tenant_quota_usages(self.request)
        total_count = quotas['instances']['used']
        instances = api.server_list(self.request)
        active_count = len([i for i in instances if i.status == 'ACTIVE'])
        
#        total_count = api.server_list_count(request=self.request, 
#                                            all_tenants=all_tenants)
#        active_count = api.server_list_count(request=self.request, 
#                                             all_tenants=all_tenants, 
#                                             vm_state="active")
        
        context["totalinscount"] = total_count
        context["activeinscount"] = active_count
        context["illinscount"] = total_count - active_count
        context["disk_total_gb"] = quotas['gigabytes']['quota']
        context["disk_used_gb"] = quotas['gigabytes']['used']
        return context
    
