# vim: tabstop=4 shiftwidth=4 softtabstop=4

# Copyright 2012 United States Government as represented by the
# Administrator of the National Aeronautics and Space Administration.
# All Rights Reserved.
#
# Copyright 2012 Nebula, Inc.
# Copyright 2012 OpenStack LLC
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

"""
Views for Instances and Volumes.
"""
import logging
import math
import pdb

from django.conf import settings
from django.utils.translation import ugettext_lazy as _

from horizon import api
from horizon import exceptions
from horizon import tables
#from .keypairs.tables import KeypairsTable
#from .floating_ips.tables import FloatingIPsTable
from .security_groups.tables import SecurityGroupsTable


LOG = logging.getLogger(__name__)


class IndexView(tables.MultiTableView):
    table_classes = (SecurityGroupsTable,)
    template_name = 'instances/security_groups/index.html'
    #modified by fengkai@cnic.cn
    def get_security_groups_data(self):
        page_index = self.request.GET.get(SecurityGroupsTable._meta.pagination_param, "1")
        try:
            self._more = True
            condition = {}
            total_items = api.security_group_count(self.request, all_tenants=True, search_opts=condition)
            self.get_tables()['security_groups'].total_items = total_items[0].count
            security_groups, self._more = api.security_group_paginate(self.request,
                             all_tenants=True, search_opts=condition, page_index=int(page_index)-1)              

            for security in security_groups:
                security.request = self.request
        except:
            security_groups = []
            self._more = False
            exceptions.handle(self.request,
                            _('Unable to retrieve security groups.'))
        return security_groups
