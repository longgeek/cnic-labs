# vim: tabstop=4 shiftwidth=4 softtabstop=4
import json
from django.conf import settings
from django import shortcuts
from django.utils.translation import ugettext_lazy as _

from horizon import api
from horizon import usage
from horizon.dashboards.event.warning.alarminterhandle import useruse, adminuse

#add by weiyuanke@cnic.cn
def overview(request):
    user_roles = [role['name'] for role in request.user.roles]
    if 'admin' in user_roles:
        ram_total = 0
        ram_used = 0
        cpu_total = 0
        cpu_used = 0
        disk_total_gb = 0
        disk_used_gb = 0
        useinfos = api.nova.get_compute_node_resource_stats(request)
        for info in useinfos.keys():
            ram_total = ram_total + useinfos[info][0].memory_mb
            cpu_total = cpu_total + useinfos[info][0].cpu
            disk_total_gb = disk_total_gb + useinfos[info][0].disk_gb
            ram_used = ram_used + useinfos[info][1].memory_mb
            cpu_used = cpu_used + useinfos[info][1].cpu
            disk_used_gb = disk_used_gb + useinfos[info][1].disk_gb
        disk_use_ratio = int(float(disk_used_gb) / disk_total_gb * 100)
        ram_use_ratio = int(float(ram_used) / ram_total * 100)
        cpu_use_ratio = int(float(cpu_used) / cpu_total * 100)
        warningList = json.loads(adminuse(1, 4))

    else:
        ram_total = 0
        ram_used = 0
        cpu_total = 0
        cpu_used = 0
        disk_total_gb = 0
        disk_used_gb = 0

	quotas = api.nova.tenant_quota_usages(request)
        ram_total = quotas['ram']['quota']
        ram_used = quotas['ram']['used']
        cpu_total = quotas['cores']['quota']
        cpu_used = quotas['cores']['used']
        disk_total_gb = quotas['gigabytes']['quota']
        disk_used_gb = quotas['gigabytes']['used']
        vm_quotas_total = quotas['instances']['quota']
        vm_quotas_used = quotas['instances']['used']

        disk_use_ratio = int(float(disk_used_gb) / disk_total_gb * 100)
        ram_use_ratio = int(float(ram_used) / ram_total * 100)
        cpu_use_ratio = int(float(cpu_used) / cpu_total * 100)
        vm_quotas_use_ratio = int(float(vm_quotas_used)/vm_quotas_total * 100)
        warningList = json.loads(useruse(request.user.id, 1, 4))

    server_count = api.nova.server_count(request)
    vm_active = server_count[0].active_instances + server_count[0].rescued_instances + server_count[0].resized_instances
    vm_building = server_count[0].building_instances
    vm_error = server_count[0].error_instances
    vm_paused = server_count[0].paused_instances + server_count[0].suspended_instances
    changeWrnType(warningList)

    return shortcuts.render(request, 'index/overview/usage.html', locals())

def changeWrnType(warningList):
    type_change = {'cpu' : _('CPU'), 'memo' : _('Memory'), 'disk' : _('Hard Disk')}
    for warning in warningList: 
        warning['type'] = type_change[warning['type']]
        warning['ratio'] = str(warning['ratio'] * 100) + '%'
        warning['nowratio'] = str(warning['nowratio'] * 100) + '%'
