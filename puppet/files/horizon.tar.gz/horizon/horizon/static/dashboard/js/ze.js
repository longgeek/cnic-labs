// Call init on DOM ready.
jQuery(document).ready(horizon.init);

var jq = jQuery;
// for table pagination
function changepage(elm){
  var page_index = jq(elm).closest("form").find('input:hidden[name="page_index"]');
  page_index.val(elm.value);

  if (!jq(elm).hasClass("ze-ajax")) {
    horizon.datatables.refresh(elm);
  }
}

function page_next(elm, step){
  event.preventDefault();
  var page_index = jq(elm).closest("form").find('input:hidden[name="page_index"]');
  page_index.val(parseInt(page_index.val()) + step);

  if (!jq(elm).hasClass("ze-ajax")) {
    horizon.datatables.refresh(elm);
  }
  return false;
}
// add style for file input tag.
function changeFileInputStyle(elemid, elemwidth, onchange) {
  jq('#' + elemid).ace_file_input({
      no_file:gettext('No File ...'),
      btn_choose:gettext('Choose'),
      btn_change:gettext('Change'),
      droppable:false,
      onchange:null,
      thumbnail:false //| true | large
      //whitelist:'gif|png|jpg|jpeg'
      //blacklist:'exe|php'
      //onchange:''
    }).on('change', function() {
      if (onchange) {
        onchange($(this));
      }
	});
  jq("#" + elemid).parent(".ace-file-input").css("width", elemwidth);
}

function tooltip_placement(context, source) {
  var $source = jq(source),
      $parent = $source.closest('table'),
      off1 = $parent.offset(),
      w1 = $parent.width(),
	  off2 = $source.offset(),
	  w2 = $source.width();

  if(parseInt(off2.left) < parseInt(off1.left) + parseInt(w1 / 2)) {
	  return 'right';
  }
  return 'left';
}

jQuery(function($) {
  $('#modal_wrapper').on('new_modal', function (evt, modal) {
    $('[data-rel=popover]').popover({container:'.modal'});
    $('[data-rel="tooltip"]').tooltip({placement: tooltip_placement});
  });
  $('[data-rel=popover]').popover({container:'body'});
  $('[data-rel="tooltip"]').tooltip({placement: tooltip_placement});

  // load ajax click action to refresh designated area.
  $(document).on("click", "a.ze-ajax, button.ze-ajax", function(eve) {
    var $this = $(this),
        $form = $this.parents("form"),
        hasForm = $form.size() > 0 ? true : false,
        oncompleted = $this.data("ze-oncompleted");

    $.ajax({
        url: $this.data("ze-ajaxurl") ? $this.data("ze-ajaxurl") : (hasForm ? $form.attr("action") : location.pathname), 
        type: $this.data("ze-ajaxtype") ? "GET" : $this.data("ze-ajaxtype"),
        data: hasForm ? $form.serialize() : "",
        context: document.body, 
        success: function(data, type){
          var $html = $(data);
          $.each($this.data("ze-update").split(","), function(i, n){
            if ($this.data("ze-onstart")) {
              eval($this.data("ze-onstart"));
            }
            var id = "#" + n;
            $(document).find(id).replaceWith($html.find(id));
            if (oncompleted) {
              eval(oncompleted);
            }
          });
        }
    });
    eve.preventDefault();
    eve.stopPropagation();
  });

  // load ajax select's change action to refresh designated area.
  $(document).on("change", "select.ze-ajax", function(eve) {
    var $this = $(this),
        $form = $this.parents("form"),
        hasForm = $form.size() > 0 ? true : false,
        oncompleted = $this.data("ze-oncompleted");

    $.ajax({
        url: $this.data("ze-ajaxurl") ? $this.data("ze-ajaxurl") : (hasForm ? $form.attr("action") : location.pathname), 
        type: $this.data("ze-ajaxtype") ? "GET" : $this.data("ze-ajaxtype"),
        data: hasForm ? $form.serialize() : "",
        context: document.body, 
        success: function(data, type){
          var $html = $(data);
          $.each($this.data("ze-update").split(","), function(i, n){
            if ($this.data("ze-onstart")) {
              eval($this.data("ze-onstart"));
            }
            var id = "#" + n;
            $(document).find(id).replaceWith($html.find(id));
            if (oncompleted) {
              eval(oncompleted);
            }
          });
        }
    });
    eve.preventDefault();
    eve.stopPropagation();
  });
});