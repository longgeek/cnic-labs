var enduser = {modal : {}};

var labels = {'default' : ['', '', '', '', '', '', '', '']};
var values = {'default' : [0, 0, 0, 0, 0, 0, 0, 0]};
var lineBasic2dConfig = {
    align : 'center',
    title : {
        text : 'CPU使用情况',
        font : '微软雅黑',
        fontsize : 24,
        color : '#3e576f'
    },
    footnote : {
        text : '',
        font : '微软雅黑',
        fontsize : 11,
        fontweight : 600,
        padding : '0 28',
        color : '#b4b4b4'
    },
    border : false,
    width : 360,
    height : 260,
    shadow : true,
    shadow_color : '#202020',
    shadow_blur : 6,
    shadow_offsetx : 0,
    shadow_offsety : 0,
    background_color : '#ffffff',
    tip : {
        enable : true,
        shadow : true,
        listeners : {
            //tip:提示框对象、name:数据名称、value:数据值、text:当前文本、i:数据点的索引
            parseText:function(tip,name,value,text,i){
              return "<span style='color:#005268;font-size:12px;'>CPU使用率:<br/>" + 
                  "</span><span style='color:#005268;font-size:20px;'>"+value+"%</span>";
            }
        }
    },
    crosshair : {
        enable : true,
        line_color : '#0d8ecf'
    },
    sub_option : {
        smooth : true,
        label : false,
        hollow : false,
        hollow_inside : false,
        point_size : 8
    },
    coordinate : {
        width : 260,
        height : 130,
        striped_factor : 0.18,
        grid_color : '#99CCFF',
        axis : {
            color : '#99CCFF',
            width : [0,0,4,4]
        },
        scale : [{
            position : 'left',	
            start_scale : 0,
            end_scale : 100,
            scale_space : 10,
            scale_size : 2,
            scale_enable : false,
            label : {color : '#3e576f',font : '微软雅黑', fontsize : 11, fontweight : 600},
            scale_color : '#3e576f'
        }, {
            position : 'bottom',	
            label : {color : '#3e576f', font : '微软雅黑', fontsize : 11, fontweight : 600},
            scale_enable : false,
            labels : labels
        }]
    }
};

var pie3dConfig = {
    title : {
        text : '硬盘使用情况',
        fontsize : 24,
        color : '#3e576f'
    },
    sub_option : {
        mini_label_threshold_angle : 40,//迷你label的阀值,单位:角度
        mini_label : {//迷你label配置项
            fontsize : 20,
            fontweight : 600,
            color : '#ffffff'
        },
        label : {
            background_color : null,
            sign : false,//设置禁用label的小图标
            padding : '0 4',
            border : {
                enable : false,
                color : '#666666'
            },
            fontsize : 11,
            fontweight : 600,
            color : '#4572a7'
        },
        border : {
            width : 2,
            color : '#ffffff'
        },
        listeners : {
            parseText : function(d, t) {
              return d.get('value')+"%";//自定义label文本
            }
		} 
	},
    legend : {
        enable : true,
        padding : 0,
        offsetx : 20,
        offsety : 80,
        color : '#3e576f',
        fontsize : 10,//文本大小
        sign_size : 10,//小图标大小
        line_height : 18,//设置行高
        sign_space : 10,//小图标与文本间距
        border : false,
        align : 'left',
        background_color : null//透明背景
    },
    border : false,
    shadow : true,
    shadow_blur : 6,
    shadow_color : '#aaaaaa',
    shadow_offsetx : 0,
    shadow_offsety : 0,
    background_color : '#ffffff',
    align : 'right',//右对齐
    offsetx : -80,//设置向x轴负方向偏移位置60px
    offset_angle : -90,//逆时针偏移120度
    width : 360,
    height : 260,
    radius : 150
};

var donut2dConfig = {
    title : {
        text : '内存使用率',
        fontsize : 24,
        color : '#3e576f'
    },
    center : {
        text : '',
        color : '#3e576f',
        shadow : true,
        shadow_blur : 0,
        shadow_color : '#557797',
        shadow_offsetx : 0,
        shadow_offsety : 0,
        fontsize : 28
    },
    sub_option : {
        label : {
            background_color : null,
            sign : false,//设置禁用label的小图标
            padding : '0 4',
            border : {
                enable:false,
                color:'#666666'
            },
            fontsize : 11,
            fontweight : 600,
            color : '#4572a7'
        },
        border : {
            width : 2,
            color : '#ffffff'
        }
    },
    border : false,
    shadow : true,
    shadow_blur : 0,
    shadow_color : '#aaaaaa',
    shadow_offsetx : 0,
    shadow_offsety : 0,
    background_color : '#ffffff',
    offset_angle : -120,//逆时针偏移120度
    showpercent : true,
    decimalsnum : 2,
    width : 360,
    height : 260,
    radius:120
};

// 创建折线图
function createLineBasic2d(elemId, config, data) {
  config.id = elemId;
  config.data = data;
  config.render = elemId;
  var chart = new iChart.LineBasic2D(config);
  //利用自定义组件构造左侧说明文本
  chart.plugin(new iChart.Custom({
      drawFn : function() {
	    //计算位置
        var coo = chart.getCoordinate(),
            x = coo.get('originx'),
            y = coo.get('originy'),
            w = coo.width,
            h = coo.height;
            //在左上侧的位置，渲染一个单位的文字
			chart.target.textAlign('start')
					    .textBaseline('bottom')
					    .textFont('600 11px 微软雅黑')
					    .fillText('CPU(%)',x-40,y-12,false,'#3e576f')
					    .textBaseline('top');
      }
  }));
  //开始画图
  chart.draw();
  return chart;
}

// 创建3D饼图
function createPie3d(elemId, config, data) {
  config.id = elemId;
  config.data = data;
  config.render = elemId;
  var chart = new iChart.Pie2D(config);
  chart.draw();
  return chart;
}

// 创建环形图
function createDonut2d(elemId, config, data) {
  config.id = elemId;
  config.center.text = parseInt(data[0].value) + "%";
  config.data = data;
  config.render = elemId;
  var chart = new iChart.Donut2D(config);
  chart.draw();
  return chart;
}

// 将数组当作队列使用，先进先出
function pushArray(list, elem) {
  if (list.length >= 8) {
    list.reverse();
    list.pop();
    list.reverse();
  }
  list.push(elem);
  return list;
}

function _getFlow() {
  var flow=[];
  for(var i=0;i<10;i++) {
    flow.push(Math.floor(Math.random()*(10+((i%16)*5)))+10);
  }
  return flow;
}

function loadChart(chartId, data, configDict) {
  var chart = iChart.get(chartId);
  if (configDict) {
    for (attr in configDict) {
      chart.push(attr, configDict[attr]);
    }
  }
  chart.load(data);
  return chart;
}

// 更新图表
function updateCharts() {
  var ids = []
  $(".grid").each(function() {
    ids.push($(this).data("id"));
  });
	
  var strIds = ids.join(",");
  $.ajax({
      url: "/md",
      data: { query : strIds, stime: "latest" } ,
      //type: "POST",
      dataType: "json",
      success: function(data){
        var myDate = new Date(),
            h = myDate.getHours(),       //获取当前小时数(0-23)
            m = myDate.getMinutes();     //获取当前分钟数(0-59)
        for (key in data) {
          if (null == data[key]) {
            continue;
          }
          var data1 = [{
        	  name : 'CPU使用率',
              value : pushArray(values[key], data[key]['cpu']),
              color : '#0d8ecf',
              line_width : 2
          }];
          loadChart('cpu_' + key, data1, {'coordinate.scale' : [{
              position : 'left',	
              start_scale : 0,
              end_scale : 100,
              scale_space : 10,
              scale_size : 2,
              scale_enable : false,
              label : {color : '#3e576f', font : '微软雅黑', fontsize : 11, fontweight : 600},
              scale_color : '#3e576f'
          }, {
              position : 'bottom',	
              label : {color:'#3e576f',font : '微软雅黑',fontsize:11,fontweight:600},
              scale_enable : false,
              labels:pushArray(labels[key],  h + ':' + (m > 9 ? m : ("0" + m)))
          }]});

          var data2 = [{name : '已用内存', value : data[key]['mem'], color : '#4572a7'},
                       {name : '剩余内存', value : 100-data[key]['mem'], color : '#89a54e'}];
          loadChart('mem_' + key, data2, {'center.text' : parseInt(data[key]['mem']) + "%"});
        }
      },
      error:function(data){
        // alert(data);
      },
  });

  var used = Math.floor(Math.random()*100);
  var data3 = [{name : '已使用', value : used, color : '#aa4643'},
               {name : '剩余', value : 100-used, color:'#4572a7'}];
  $("div[id^='disk_']").each(function() {
    loadChart(this.id, data3);
  });
}

// Grid layout JS
function openBoundUrl(elem, optionsStr) {
  var boundUrl = $(elem).data("boundurl");
  if (boundUrl) {
    if (!optionsStr || optionsStr.length > 0) {
      optionsStr = 'top=0, left=0, toolbar=no，fullscreen=yes, titlebar=no';
    }
    window.open(boundUrl, '_blank', optionsStr);
  }
};

var defaultData = {
    body : gettext("Please confirm your selection. This action cannot be undone."),
    confirm : gettext("Confirm"),
    cancel: gettext("Cancel"),
};

function confirm(action) {
  var $action = $(action),
      $modal_parent = $(action).closest('.modal'),
      action_url = $action.data("action-url"),
      action_method = $action.data("action-method");
  if($action.hasClass("disabled")) {
    return;
  }
  defaultData.title = gettext("Confirm ") + $action.text();
  var modal = create(defaultData);
  modal.modal({backdrop : 'static'});
  if($modal_parent.length) {
    var child_backdrop = modal.next('.modal-backdrop');
    // re-arrange z-index for these stacking modal
    child_backdrop.css('z-index', $modal_parent.css('z-index')+10);
    modal.css('z-index', child_backdrop.css('z-index')+10);
  }
  modal.find('.btn-primary').click(function (evt) {
    var form = $action.closest('form');
    if (action_url) {
      form.attr("action", action_url);
      form.attr("method", action_method);
    }
    form.append("<input type='hidden' name='" + $action.attr('name') + "' value='" + $action.attr('value') + "'/>");
    form.submit();
    modal.modal('hide');
    modal_spinner(gettext("Working"));
      return false;
  });
  return modal;
}

function cleanModal() {
  $("#modal_wrapper").empty();
  $(".modal-backdrop").remove();
}

/* Creates a modal dialog from the client-side template. */
function create(data) {
  cleanModal();
  var template = Hogan.compile($('#modal_template').text());
  var modal = $(template.render(data).trim()).appendTo("#modal_wrapper");
  modal.on('hidden', function() {
    cleanModal();
  });
  return modal;
}

function success(data, textStatus, jqXHR) {
  cleanModal();
  var modal;
  $('#modal_wrapper').append(data);
  $('.modal span.help-block').hide();
  modal = $('.modal:last');
  modal.modal({backdrop : 'static'});
  modal.trigger("new_modal", modal);
  /*modal.on('hidden', function() {
    cleanModal();
  });*/
  return modal;
}

function modal_spinner(text) {
  //Adds a spinner with the desired text in a modal window.
  var template = Hogan.compile($('#spinner-modal').text());
  enduser.modal.spinner = $(template.render({text: text}).trim());
  enduser.modal.spinner.appendTo("#modal_wrapper");
  enduser.modal.spinner.modal({backdrop: 'static'});
  enduser.modal.spinner.spin({
      lines :  10,
      length : 15,
      width:  4,
      radius: 10,
      color:  '#000',
      speed:  0.8,
      trail:  50
  });
}

function bindSubmit(modal) {
  // AJAX form submissions from modals. Makes validation happen in-modal.
  $(modal).find("form").on('submit', function (evt) {
    var $form = $(this),
        $button = $form.find(".modal-footer .btn-primary"),
        update_field_id = $form.attr("data-add-to-field"),
        headers = {};

    if ($form.attr("enctype") === "multipart/form-data") {
      // AJAX-upload for files is not currently supported.
      return;
    }
    evt.preventDefault();

    // Prevent duplicate form POSTs
    $button.prop("disabled", true);

    if (update_field_id) {
      headers["X-Horizon-Add-To-Field"] = update_field_id;
    }
    $.ajax({
        type : "POST",
        url : $form.attr('action'),
        headers : headers,
        data : $form.serialize(),
        beforeSend : function () {
          $("#modal_wrapper .modal").last().modal("hide");
          modal_spinner(gettext("Working"));
        },
        complete : function () {
          enduser.modal.spinner.modal('hide');
          $("#modal_wrapper .modal").last().modal("show");
          $button.prop("disabled", false);
          bindSubmit($("#modal_wrapper .modal"));
        },
        success : function (data, textStatus, jqXHR) {
          var redirect_header = jqXHR.getResponseHeader("X-Horizon-Location"),
              add_to_field_header = jqXHR.getResponseHeader("X-Horizon-Add-To-Field"),
              json_data, field_to_update;

          $form.closest(".modal").modal("hide");
          if (redirect_header) {
            location.href = redirect_header;
          } else if (add_to_field_header) {
            json_data = $.parseJSON(data);
            field_to_update = $("#" + add_to_field_header);
            field_to_update.append("<option value='" + json_data[0] + "'>" + json_data[1] + "</option>");
            field_to_update.change();
            field_to_update.val(json_data[0]);
          } else {
            success(data, textStatus, jqXHR);
          }
        },
        error : function (jqXHR, status, errorThrown) {
          $form.closest(".modal").modal("hide");
          // horizon.alert("error", gettext("There was an error submitting the form. Please try again."));
        }
    });
  });
}

function popModal(pop) {
  var $this = $(pop);
  $.ajax($this.attr('href'), {
      beforeSend : function() {
        modal_spinner(gettext("Loading"));
      },
      complete : function() {
        enduser.modal.spinner.modal('hide');
      },
      error : function(jqXHR, status, errorThrown) {
        if (jqXHR.status === 401){
          var redir_url = jqXHR.getResponseHeader("X-Horizon-Location");
          if (redir_url){
            location.href = redir_url;
          } else {
            location.reload(true);
          }
        }
      },
      success: function (data, textStatus, jqXHR) {
        var update_field_id = $this.attr('data-add-to-field'),
            modal, form;
        modal = success(data, textStatus, jqXHR);
        bindSubmit(modal);
        if (update_field_id) {
          form = modal.find("form");
          if (form.length) {
            form.attr("data-add-to-field", update_field_id);
          }
        }
      }
  });
}

// Handle field toggles for the Launch Instance source type field
function onSourceTypeChanged (field) {
  var $this = $(field),
      base_type = $this.val();
  if(base_type == "snapshot") {
    $("#id_username").closest(".control-group").hide();
    $("#id_password").closest(".control-group").hide();
  } else {
    $("#id_username").closest(".control-group").show();
    $("#id_password").closest(".control-group").show();
  }
  $this.find("option").each(function () {
    if (this.value != base_type) {
      $("#id_" + this.value + "_id").closest(".control-group").hide();
    } else {
      $("#id_" + this.value + "_id").closest(".control-group").show();
    }
  });
}

var status_bgcolor = {
    "ACTIVE" : "#2ECC71",
    "RESIZE" : "#3498DB",
    "BUILD": "#3498DB",
    "HARD_REBOOT": "#F1C40F",
    "SHUTOFF": "#95A5A6",
    "SUSPENDED" : "#95A5A6",
    "PAUSED": "#3498DB",
    "VERIFY_RESIZE" : "#3498DB",
    "REVERT_RESIZE" : "#3498DB",
    "ERROR" : "#E74C3C",
    "Apply" : "#3498DB",
    "Reject" : "#95A5A6",
}

function initStatus(elem) {
  $(elem).css('background-color', status_bgcolor[$(elem).data('status')]);
}

function initAllStatus() {
  $('.status').each(function() {
    initStatus(this);
  });
}

function ajaxUpdate(elem) {
  var jqelem = $(elem),
      id = jqelem.attr("id"),
      interval = jqelem.data('update-interval') ? parseInt(jqelem.data('update-interval')) : 60000,
      renderIds = [];

  if (jqelem.data('render')) {
    renderIds = jqelem.data('render').split(",");
    renderIds[renderIds.indexOf('this')] = jqelem.attr('id');
  }
  $.ajax({
      url : jqelem.data('update-url'),
      success : function(data, textStatus, jqXHR) {
        var jqdata = $(data.trim());
        renderIds.each(function(renderId) {
          if ($("#" + renderId) && jqdata.find("#" + renderId)) {
            $("#" + renderId).replaceWith(jqdata.find("#" + renderId));
          }
        });
        var newElem = $('#' + id);
            initStatus(newElem);
        if (newElem.hasClass('ajax-update')) {
          setTimeout(ajaxUpdate(newElem), interval);
        }
      },
      error : function(jqXHR, textStatus, errorThrown) {
        switch (jqXHR.status) {
          // A 404 indicates the object is gone, and should be removed from the table
          case 404:
            break;
          default:
            break;
        }
        jqelem.removeClass("ajax-update");
      }
  });
}

jQuery(function($) {
  // 初始化各图表
  var ids = []
  $(".grid").each(function(){
    ids.push($(this).data("id"));
  });

  var strIds = ids.join(",");
  $.ajax({
      url : "/md",
      data : { query : strIds, stime: "latest" } ,
      // type: "POST",
      dataType : "json",
      success : function(data){
        var myDate = new Date();
        var h = myDate.getHours();       //获取当前小时数(0-23)
        var m = myDate.getMinutes();     //获取当前分钟数(0-59)
        for (key in data) {
          if (null == data[key]) {
            continue;
          }
          values[key] = pushArray(values[key] ? values[key] : values['default'].slice(0), data[key]['cpu']);
          var data1 = [{
              name : 'CPU使用率',
              value : values[key],
              color : '#0d8ecf',
              line_width : 2
          }];
          labels[key] = pushArray(labels[key] ? labels[key] : labels['default'].slice(0), h+":"+ (m > 9 ? m : ("0" + m)));
          lineBasic2dConfig.coordinate.scale[1].labels = labels[key];
          createLineBasic2d('cpu_' + key, lineBasic2dConfig, data1);

          var data2 = [{name : '已用内存',value : data[key]['mem'],color:'#4572a7'},
                       {name : '剩余内存',value : 100-data[key]['mem'],color:'#89a54e'}];
          createDonut2d('mem_' + key, donut2dConfig, data2);
        }
      },
      error:function(data){
      },
  });

  var data3 = [{name : '已使用',value : 52.5,color:'#aa4643'},
               {name : '剩余',value : 47.5,color:'#4572a7'}];
  $("div[id^='disk_']").each(function() {
    createPie3d(this.id, pie3dConfig, data3);
  });

  // 每分钟更新一次图表
  window.setInterval('updateCharts()', 60000);


  // Bind event handlers to confirm dangerous actions.
  $("body form button.btn-danger, body form button.btn-warning").on("click", function (evt) {
    confirm(this);
    evt.preventDefault();
  });

  // Load modals for ajax-modal links.
  $(document).on('click', '.ajax-modal', function (evt) {
    popModal(this);
    evt.preventDefault();
  });

  // other
  $(".navbar-link").popover({html : true, trigger : 'hover'});
  $(".grid-popover").popover();
  // init source type change action
  $(document).on('show', '.modal', function(){
    // bindSubmit($(this));
    onSourceTypeChanged($('.modal #id_source_type'));
  });
  $(document).on('change', '.modal #id_source_type', function (evt) {
    onSourceTypeChanged(this);
  });


  initAllStatus();
  $(".ajax-update").each(function(){
    setTimeout(ajaxUpdate(this), 30000);
  });
});