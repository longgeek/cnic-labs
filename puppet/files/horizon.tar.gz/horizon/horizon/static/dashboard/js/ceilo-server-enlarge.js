function getCtn(parm) {
	var list = []
	if (parm == 'cpu') {
		list.push('server.cpu.idle');
	} else if (parm == 'memory') {
		list.push('server.mem.free');
	} else if (parm == 'load') {
		list.push('server.load.one');
		list.push('server.load.five');
                list.push('server.load.fifteen');
	} else if (parm == 'network') {
		list.push('server.net.bytes.in');
		list.push('server.net.bytes.out');
	}
	return list;
}

function getRandomC(){
    return '#'+(function(h){
        return new Array(7-h.length).join("0")+h
    })((Math.random()*0x1000000<<0).toString(16))
}

fixed_color = [
    '#63d673',
    '#db170c',
    '#05447c',
    '#18c9cb',
    '#81fd8f',
    '#aa18b1',
    '#63ace3'
]

function enlarge_chart(){
    var strid;
    $("#ins_id").each(function(){
        strid=$(this).data("rel");
    });
    var strctn;
    $("#ctn").each(function(){
        strctn=$(this).data("rel");
    });
    var strin;
    $("#interval").each(function(){
        strin=$(this).data("rel");
    });

    jQuery.ajax({
        url: '/ceilometer/server/large_meter',
        type: "GET",
        data: {ins_id : strid, 
               ctn : strctn, 
               interval: strin},
        dataType: "json",
        success: function(resdata){
                     callback_2(resdata);
                 }
    });
}

function callback_2(resdata){
          var chart_set = {}
          //Get server list
          for (key in resdata){
              if (key == 'each')
                  return;
              //Get counter name list of each server
              var is_right = false;
              var has_data = false;
              data_key_list = Object.keys(resdata[key]["items"]);
              required_key_list = getCtn(linechart_parm);
              data = []

              if((resdata[key].items)[data_key_list[0]].length == 0){
                  has_data = false;
                  is_right = true;
                  ymin = 0;
                  ymax = 1;
                  data = []
                  data.push({name:"nodata",
                             value:[0],
                             color:fixed_color[0],
                             line_width:2})
                  label_set = [etm];
              }else{
                  has_data = true
                  ymin = (resdata[key].items)[data_key_list[0]][0]['counter_volume'];
                  ymax = (resdata[key].items)[data_key_list[0]][0]['counter_volume'];
                  label_set = [];
     
                  //validate key set
                  data = []
                  for(var it=0;it<data_key_list.length;it++){
                      if (required_key_list.indexOf(data_key_list[it]) != -1){
                          is_right = true;
                          // to do
                          tmp_data_set = [];
                          tmp_label_set = [];
                          tmp_counter_unit = null;
                          temp_data = (resdata[key].items)[data_key_list[it]];
                          for(var data_it=0;data_it<temp_data.length;data_it++){
                              if(data_it != "each" && data_it != "eachAll" && data_it != "sor"){
                                  if(temp_data[data_it]['counter_volume'] > ymax){
                                      ymax = temp_data[data_it]['counter_volume'];
                                  }
                                  if(temp_data[data_it]['counter_volume'] < ymin){
                                      ymin = temp_data[data_it]['counter_volume'];
                                  }
                                  tmp_data_set.push(temp_data[data_it]['counter_volume']);
                                  tmp_label_set.push(temp_data[data_it]['timestamp']);
                                  tmp_counter_unit = temp_data[data_it]['counter_unit']
                              }
                          }
                          data.push({name:data_key_list[it]+" ("+tmp_counter_unit+")",
                                     value:tmp_data_set,
                                     color:fixed_color[it],
                                     line_width:2})
                          if(tmp_label_set.length > label_set.length){
                              label_set = tmp_label_set;
                          }
                      }else {
                          is_right = false;
                          continue;
                      }
                  }

              }
              
              if(is_right){
                  //Set scale
                  var yrange = ymax - ymin;

                  if(yrange != 0){
                      end_scl = (ymax + 0.2 * yrange);
                      st_scl = (ymin - 0.2 * yrange) > 0 ? (ymin - 0.2 * yrange) : 0;
                  }else{
                      end_scl = ymax + 0.1 * ymax;
                      st_scl = ymin - 0.1 * ymax;
                  }

                  y_scl = (parseFloat((end_scl - st_scl) / 4).toFixed(1)) == 0 ? (end_scl - st_scl) : (parseFloat((end_scl - st_scl) / 4).toFixed(1));
                  var hrender = null;
                  
                  //Set labels in X axis
                  showlabel_set = []
                  if(label_set.length > 0){
                      //Show three label in X axis
                      showlabel_set.push(label_set[0].split(' ')[1]);
                      if(label_set.length > 2){
                          showlabel_set.push(label_set[Math.floor(label_set.length/2)].split(' ')[1]);
                      }
                      showlabel_set.push(label_set[label_set.length-1].split(' ')[1]);

                      show_title = null;
                      show_subtitle = null;
                      if(has_data){
                          show_title = resdata[key].server_name;
                          show_subtitle = resdata[key].server_ip;
                      }else{
                          show_title = resdata[key].server_name;
                          show_subtitle = "正在等待数据";
                      }
                      hrender = linechart_parm + '_' + resdata[key].server_ip + ':' + resdata[key].server_name;

                      chartIns = drawChart_2(
                                   '#sale_charts',
                                   data,
                                   show_title,
                                   show_subtitle,
                                   st_scl,
                                   end_scl,
                                   y_scl,
                                   label_set,
                                   showlabel_set);

                      //chart_set[resdata[key].server_name+":"+resdata[key].server_ip] = chartIns;

                  }else{
                      
                  }
              }
          }
}

function drawChart_2(
            hrender,
            data,
            title,
            subtitle,
            st_scl,
            end_scl,
            y_scl,
            label_set,
            showlabel_set
            ){
                                 //Set chart
                	 	var chart = new iChart.LineBasic2D({
				render : hrender,
				data : data,
				align : 'center',
                                title : title,
                                subtitle : subtitle,
				width : 1000,
				height : 410,
				background_color : '#FEFEFE',
				tip : {
					enable : true,
					shadow : true,
					move_duration : 300,
					border : {
						enable : true,
						radius : 5,
						width : 2,
						color : '#3f8695'
					},
					listeners : {
						parseText : function(tip, name, value,
								text, i) {
							return name + ": "
									+ parseFloat(value).toFixed(2);
						}
					}
				},
						tipMocker : function(tips, i) {
							return "<div style='font-weight:500'>"
									+ label_set[Math.floor(i)] + "</div>"
									+ tips.join("<br/>");
						},
						legend : {
							enable : true,
							row : 3,// column
							column : 'max',
							valign : 'top',
							sign : 'bar',
							background_color : null,//
							offsetx : -5,// x?
							border : true
						},
						crosshair : {
							enable : true,
							line_color : '#62bce9'//
						},
						sub_option : {
							label : false,
							point_size : 10
						},
						coordinate : {
							width : 900,
							height : 300,
							axis : {
								color : '#dcdcdc',
								width : 1
							},
							scale : [ {
								position : 'left',
								start_scale : st_scl,
                                                                min_scale : st_scl,
								end_scale : end_scl,
								scale_space : y_scl,
								scale_size : 2,
								scale_color : '#9f9f9f'
							}, {
								position : 'bottom',
								labels : showlabel_set
							} ]
						}
					});
                                        chart.draw();
    return chart;
   
}

