/**
 * duyuanyuan
 */
var dnume = 0, nnume = 0;
function getNuListe(parm, len){
	var nlist = [],vunit=1024;
	if (parm == 'cpu') {
		nlist.push(1);
		if(!isOdd(len)) len-=1;
		nlist.push(len);
		nlist.push(false);
	} else if (parm == 'memory') {
		nlist.push(vunit);
		if(!isOdd(len)) len-=1;
		nlist.push(len);
		nlist.push(false);
	} else if (parm == 'disk') {
		nlist.push(vunit);
		if(!isOdd(len)) len-=1;
		nlist.push(len);
		nlist.push(false);
	} else if (parm == 'network') {
		nlist.push(vunit);
		if(isOdd(len)) len-=1;
		nlist.push(len);
		nlist.push(true);
	}
	return nlist;
}

function largechart() {

	var strid;
	$("#ins_id").each(function() {
		strid = $(this).data("rel");
	});
	var strctn;
	$("#ctn").each(function() {
		strctn = $(this).data("rel");
	});
	var strin;
	$("#interval").each(function() {
		strin = $(this).data("rel");
	});

	jQuery
			.ajax({
				url : '/ceilometer/large_meter',
				type : "GET",
				data : {
					ins_id : strid,
					ctn : strctn,
					interval : strin
				},
				dataType : "json",
				success : function(resdata) {
					for (key in resdata) {

						if (key == 'each')
							return;
						

						var is_right = false, pre, cur, num;
		                data_key_list = Object.keys(resdata[key]["items"]);
		                required_key_list = getCtn(linechart_parm);
		                ymin = 0;
		                ymax = 0;
		                label_set = [];
		                meterName = null;
		                nuList = [];
		                data = [];
		                for(var it=0;it<data_key_list.length;it++){
		                    if (required_key_list.indexOf(data_key_list[it]) != -1){
		                        
		                        tmp_data_set = [];
		                        tmp_label_set = [];
		                        tmp_counter_unit = null;
		                        temp_data = (resdata[key].items)[data_key_list[it]];
		                        meterName = getName(data_key_list[it]);
		                        if(it==0){
		                        	meterName =resdata[key].resource_id+"\n" +meterName;
		                        }
		                        nuList = getNuListe(linechart_parm, temp_data.length-1);
		                        num = nuList[1];
		                        if(nuList[2]){
		                        	pre = temp_data[num]['counter_volume'] / nuList[0];
		                        	cur = temp_data[num-1]['counter_volume'] / nuList[0];
		                        	num--;
		                        }
		                        if(!is_right){
		                        	if(nuList[2]){
		                            	ymax = ymin = cur - pre;
		                            }else{
		                            	total = (resdata[key].counter_unit).split('_')[1];
		            					if(total != null){
		                					ymax = total / nuList[0];
		            					}else{
		            						ymax = temp_data[num]['counter_volume']/nuList[0];
		            					}
		                                ymin = temp_data[num]['counter_volume']/nuList[0];
		                            }
		                            
		                        }
		                        for(var data_it=num;data_it>=0;data_it--){
		                            if(data_it != "each" && data_it != "eachAll" && data_it != "sor"){
		                            	var value ;
		                            	if(nuList[2]){
		                            		cur = temp_data[data_it]['counter_volume'] / nuList[0];
		            						value = cur - pre; 
		            						pre = cur;
		                            	}else{
		                            		if(total != null){
		                            			value = (total-temp_data[data_it]['counter_volume'])/nuList[0];
		                            		}else{
		                            			value = temp_data[data_it]['counter_volume']/nuList[0];
		                            		}
		                            		
		                            	}
		                            	
		                                if(value > ymax){
		                                    ymax = value;
		                                }
		                                if(value < ymin){
		                                    ymin = value;
		                                }
		                                tmp_data_set.push(value);
		                                tmp_label_set.push(temp_data[data_it]['timestamp']);
		                                
		                            }
		                        }
		                        data.push({name:meterName,
		                                   value:tmp_data_set,
		                                   color:fixed_color[it],
		                                   line_width:2})
		                        if(tmp_label_set.length > label_set.length){
		                            label_set = tmp_label_set;
		                        }
		                        is_right = true;
		                    }else {
		                        is_right = false;
		                        continue;
		                    }
		                }
		                if(!is_right) return;
		                var yAxis = getY(ymax, ymin, linechart_parm);
		                var labels=getLabels(linechart_parm, label_set, num, 6);
						var tip_label=label_set;

						var chart = new iChart.LineBasic2D({
							render : '#sale_charts',
							data : data,
							align : 'center',
							// title : 'A??2',
							// subtitle : '?-3??',
							// footnote : '?,
							width : 1000,
							height : 360,
							background_color : '#FEFEFE',
							tip : {
								enable : true,
								shadow : true,
								move_duration : 300,
								border : {
									enable : true,
									radius : 5,
									width : 2,
									color : '#3f8695'
								},
								listeners : {
									// tip:?name:value:?text:i:
									parseText : function(tip, name, value,
											text, i) {
										var nlist = name.split("\n");
										return nlist[nlist.length - 1] + ":"
												+ parseFloat(value).toFixed(2);
									}
								}
							},
							tipMocker : function(tips, i) {
								return "<div style='font-weight:500'>"
										+ tip_label[Math.floor(i)] + "</div>"
										+ tips.join("<br/>");
							},
							legend : {
								enable : true,
								row : 2,// column
								column : 'max',
								valign : 'top',
								sign : 'bar',
								background_color : null,//
								offsetx : -100,// x?
								border : true
							},
							crosshair : {
								enable : true,
								line_color : '#62bce9'//
							},
							sub_option : {
								label : false,
								point_size : 10
							},
							coordinate : {
								width : 900,
								height : 310,
								axis : {
									color : '#dcdcdc',
									width : 1
								},
								scale : [ {
									position : 'left',
									start_scale : yAxis[1],
									end_scale : yAxis[0],
									scale_space : yAxis[2],
									scale_size : 2,
									scale_color : '#9f9f9f'
								}, {
									position : 'bottom',
									labels : labels
								} ]
							}
						});

						// ?
						chart.draw();

					}

				}

			});
	// window.setTimeout("line_chart()", 30*1000);
}

jQuery(function() {
	window.setTimeout("largechart()", 10);

});