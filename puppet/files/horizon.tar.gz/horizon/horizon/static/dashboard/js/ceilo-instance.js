/**
 * 
 *//**
 * 
 */

function colorlarge() {
	    
		var colorbox_params = {
                       
			reposition : true,
			scalePhotos : true,
			scrolling : false,
			previous : '<i class="icon-arrow-left"></i>',
			next : '<i class="icon-arrow-right"></i>',
			close : '&times;',
			current : '{current} of {total}',
			maxWidth : '100%',
			maxHeight : '100%',
			onOpen : function() {
				document.body.style.overflow = 'hidden';
			},
			onClosed : function() {
				document.body.style.overflow = 'auto';
                                $.colorbox.remove();
                                window.setTimeout("colorlarge()", 100);
			},
			onComplete : function() {
				$.colorbox.resize();
			}
		};
                var acti;
	        jQuery('#instance_monitor li[class*="active"] ').each(function(){
	        	if(typeof $(this).attr("data-type")!='undefined'){
	        		acti = ($(this).attr("data-type")).toLowerCase();
	    		}
	            
	        });
                var clb = "colorbox_"+acti;
		$('#ul_'+acti + ' [data-rel='+clb+']').colorbox(colorbox_params);
		if($("#cboxLoadingGraphic i").length==0){
			$("#cboxLoadingGraphic").append("<i class='icon-spinner orange'></i>");//let's add a custom loading icon
		}
                
		/**$(window).on('resize.colorbox', function() {
		        try {
		                //this function has been changed in recent versions of colorbox, so it won't work
		                $.fn.colorbox.load();//to redraw the current frame
		        } catch(e){}
		});*/
	}

function delLi(id, user_id) {
        var cookie_id = user_id + ":instances";
	var ids = horizon.cookies.read(cookie_id).split(',');
	for (var i = 0; i < ids.length - 1; i++) {
		if (id == ids[i]) {
			ids.splice(i, 1);
			break;
		}
	}
	horizon.cookies.write(cookie_id, ids.join(','));
	window.location.href = "/ceilometer";

}

function dateFormate(date) {
	var str = date.getUTCFullYear();
	if (date.getUTCMonth() < 9) {
		str += "-0" + (date.getUTCMonth() + 1);
	} else {
		str += "-" + (date.getUTCMonth() + 1);
	}

	if (date.getUTCDate() < 10) {
		str += "-0" + date.getUTCDate();
	} else {
		str += "-" + date.getUTCDate();
	}

	if (date.getUTCHours() < 10) {
		str += " 0" + date.getUTCHours();
	} else {
		str += " " + date.getUTCHours();
	}

	if (date.getUTCMinutes() < 10) {
		str += ":0" + date.getUTCMinutes();
	} else {
		str += ":" + date.getUTCMinutes();
	}

	if (date.getUTCSeconds() < 10) {
		str += ":0" + date.getUTCSeconds();
	} else {
		str += ":" + date.getUTCSeconds();
	}
	return str;
}

function getCtn(parm) {
	var list = []
	if (parm == 'cpu') {
		list.push('cpu_util');
	} else if (parm == 'memory') {
		list.push('mem');
	} else if (parm == 'disk') {
		list.push('disk.read.bytes');
		list.push('disk.write.bytes');
	} else if (parm == 'network') {
		list.push('network.incoming.bytes')
		list.push('network.outgoing.bytes')
	}
	return list;
}
var tip_label = [], labels=[],dnum=0, pre_num=0;
var lineBasic2dConfig ={
			align : 'center',
			// title : 'A??2',
			// subtitle : '?-3??',
			// footnote : '?,
			width : 380,
			height : 200,
			background_color : '#FEFEFE',
			tip : {
				enable : true,
				shadow : true,
				move_duration : 300,
				border : {
					enable : true,
					radius : 5,
					width : 2,
					color : '#3f8695'
				},
				listeners : {
					// tip:?name:value:?text:i:
					parseText : function(tip, name, value,
							text, i) {
						return name + ": "
								+ parseFloat(value).toFixed(2);
					}
				}
			},
			tipMocker : function(tips, i) {
				return "<div style='font-weight:500'>"
						+ tip_label[Math.floor(i)] + "</div>"
						+ tips.join("<br/>");
			},
			legend : {
				enable : true,
				row : 2,// column
				column : 'max',
				valign : 'top',
				sign : 'bar',
				background_color : null,//
				offsetx : -5,// x?
				border : true
			},
			crosshair : {
				enable : true,
				line_color : '#62bce9'//
			},
			sub_option : {
				label : false,
				point_size : 10
			},
			coordinate : {
				width : 290,
				height : 160,
				axis : {
					color : '#dcdcdc',
					width : 1
				},
				scale : [ {
					position : 'left',
					start_scale : 0,
					end_scale : 100,
					scale_space : 20,
					scale_size : 2,
					scale_color : '#9f9f9f'
				}, {
					position : 'bottom',
					labels : labels
				} ]
			}
}

function createLineBasic2d(elemId, config, data) {
	config.id = elemId;
	config.data = data;
	config.render = elemId;
	var chart = iChart.get(elemId);
	if(typeof chart=="undefined"){
		chart = new iChart.LineBasic2D(config);
	}
	//开始画图
	chart.draw();
	return chart;
}

function isOdd(num){
	if(num%2==0)
		return true;
	else
		return false;
}

function getRandomC(){
    return '#'+(function(h){
        return new Array(7-h.length).join("0")+h
    })((Math.random()*0x1000000<<0).toString(16))
}

function getName(parm){
	var name=null;
	if (parm == 'cpu_util') {
		name="cpu_util(%)"
	} else if (parm == 'mem') {
		name="Used Mem (MB)";
	} else if (parm == 'disk.read.bytes') {
		name = "Read(KB)";
	} else if (parm == 'disk.write.bytes') {
		name = "Write(KB)";
	}else if(parm == 'network.incoming.bytes'){
		name = "In   (KB)";
	}else if(parm == 'network.outgoing.bytes'){
		name = "Out (KB)";
	}
	return name;
}

function getNuList(parm, len){
	var nlist = [],vunit=1024;
	if (parm == 'cpu') {
		nlist.push(1);
		if(!isOdd(len)) len-=1;
		nlist.push(len);
		nlist.push(false);
	} else if (parm == 'memory') {
		nlist.push(vunit);
		if(!isOdd(len)) len-=1;
		nlist.push(len);
		nlist.push(false);
	} else if (parm == 'disk') {
		nlist.push(vunit);
		if(!isOdd(len)) len-=1;
		if(dnum == 0) len-=2;
		if(dnum<len&&dnum != 0)
			len=dnum;
		dnum = len;
		nlist.push(len);
		nlist.push(false);
	} else if (parm == 'network') {
		nlist.push(vunit);
		if(isOdd(len)) len-=1;
		if(pre_num == 0) len-=2;
		if(pre_num<len&&pre_num !=0)
			len=pre_num;
		pre_num = len;
		nlist.push(len);
		nlist.push(true);
	}
	return nlist;
}

function getLabels(linechart_parm ,label_set, num, m){
	var tmp_labels=[],  ms, ss, n = 1;
	var tdate = new Date(label_set[0]);
	ms = tdate.getMinutes();
	ss = tdate.getSeconds();
	tmp_labels.push((ms > 9 ? ms : ("0" + ms)) + "'"
			+ (ss > 9 ? ss : ("0" + ss)));
	for (var i = 1; i <= num; i++) {
		if (linechart_parm == 'disk') {
			var tdate = new Date(label_set[i]);
			ms = tdate.getMinutes();
			ss = tdate.getSeconds();
			tmp_labels.push((ms > 9 ? ms : ("0" + ms)) + "'"
					+ (ss > 9 ? ss : ("0" + ss)));
		}else{
			if (n == m) {
				var tdate = new Date(label_set[i]);
				ms = tdate.getMinutes();
				ss = tdate.getSeconds();
				tmp_labels.push((ms > 9 ? ms : ("0" + ms)) + "'"
						+ (ss > 9 ? ss : ("0" + ss)));
				n = 1;
			} else {
				n++;
				continue;
			}
		}
	}
	return tmp_labels;
}

function getY(ymax, ymin,  parm){
	var yscal=0,ydel=0;
	if (parm == 'cpu') {
		ydel = (ymax - ymin) / 10;
		ymax = parseInt(ymax + ydel) + 1;
		ymin = parseInt(ymin - ydel) - 1;
		yscal = (ymax - ymin) / 10;
	} else if (parm == 'memory') {
		ydel = (ymax - ymin) / 100;
		ymin = parseInt(ymin - ydel) - 1;
		ymin = ymin > 0 ? ymin : 0;
		yscal = (ymax - ymin) / 5;
	} else if (parm == 'disk') {
		ydel = (ymax - ymin) / 100;
		ymax = parseInt(ymax + ydel) + 1;
		ymin = parseInt(ymin - ydel) - 1;
		ymin = ymin >= 0 ? ymin : 0;
		yscal = parseInt((ymax - ymin) / 5) - 1;
	} else if (parm == 'network') {
		ydel = (ymax - ymin) / 10;
		ymax = parseInt(ymax + ydel) + 1;
		ymin = parseInt(ymin) - 1;
		ymin = ymin >= 0 ? ymin : 0;
		yscal = parseInt((ymax - ymin) / 5) - 1;
	}
	var list=[];
	list.push(ymax);
	list.push(ymin);
	list.push(yscal);
	return list;
}

fixed_color = [
    '#63d673',
    '#db170c',
    '#05447c',
    '#18c9cb',
    '#81fd8f',
    '#aa18b1',
    '#63ace3'
]

var linechart_parm, distance = 130;

function initChart() {
	
	jQuery('#instance_monitor li[class*="active"] ').each(function() {
		if (typeof $(this).attr("data-type") != 'undefined') {
			linechart_parm = ($(this).attr("data-type")).toLowerCase();
		}

	});
	ctn = getCtn(linechart_parm);
	strctn = ctn.join(",");
	var ids = [];
	$('#instance_monitor__' + linechart_parm + ' a[class*="cboxElement"] ')
			.each(function() {
				ids.push($(this).data("id"));
			});
	if (ids.length <= 0)
		return;
	var strIds = ids.join(",");
	if (linechart_parm == "disk") {
		distance = 320;
	}else{
		distance=130;
	}
	var date = new Date();
	var sdate = new Date(date.getTime() - distance * 1000);
	etm = dateFormate(date);
	stm = dateFormate(sdate);
	
	jQuery.ajax({
		url : '/ceilometer/meter',
		type : "GET",
		data : {
			query : strIds,
			counter_name : strctn,
			stime : stm,
			etime : etm
		},
		dataType : "json",
		success : function(resdata) {
			for (key in resdata) {				

				if (key == 'each')
					return;
								
				var is_right = false, pre, cur, num;
                data_key_list = Object.keys(resdata[key]["items"]);
                required_key_list = getCtn(linechart_parm);
                ymin = 0;
                ymax = 0;
                label_set = [];
                meterName = null;
                nuList = [];
                data = [];
                for(var it=0;it<data_key_list.length;it++){
                    if (required_key_list.indexOf(data_key_list[it]) != -1){
                        
                        tmp_data_set = [];
                        tmp_label_set = [];
                        tmp_counter_unit = null;
                        temp_data = (resdata[key].items)[data_key_list[it]];
                        meterName = getName(data_key_list[it]);
                        nuList = getNuList(linechart_parm, temp_data.length-1);
                        num = nuList[1];
                        if(nuList[2]){
                        	pre = temp_data[num]['counter_volume'] / nuList[0];
                        	cur = temp_data[num-1]['counter_volume'] / nuList[0];
                        	num--;
                        }
                        if(!is_right){
                        	if(nuList[2]){
                            	ymax = ymin = cur - pre;
                            }else{
                            	total = (resdata[key].counter_unit).split('_')[1];
            					if(total != null){
                					ymax = total / nuList[0];
            					}else{
            						ymax = temp_data[num]['counter_volume']/nuList[0];
            					}
                                ymin = temp_data[num]['counter_volume']/nuList[0];
                            }
                            
                        }
                        for(var data_it=num;data_it>=0;data_it--){
                            if(data_it != "each" && data_it != "eachAll" && data_it != "sor"){
                            	var value ;
                            	if(nuList[2]){
                            		cur = temp_data[data_it]['counter_volume'] / nuList[0];
            						value = cur - pre; 
            						pre = cur;
                            	}else{
                            		if(total != null){
                            			value = (total-temp_data[data_it]['counter_volume'])/nuList[0];
                            		}else{
                            			value = temp_data[data_it]['counter_volume']/nuList[0];
                            		}
                            		
                            	}
                            	
                                if(value > ymax){
                                    ymax = value;
                                }
                                if(value < ymin){
                                    ymin = value;
                                }
                                tmp_data_set.push(value);
                                tmp_label_set.push(temp_data[data_it]['timestamp']);
                                
                            }
                        }
                        data.push({name:meterName,
                                   value:tmp_data_set,
                                   color:fixed_color[it],
                                   line_width:2})
                        if(tmp_label_set.length > label_set.length){
                            label_set = tmp_label_set;
                        }
                        is_right = true;
                    }else {
                        is_right = false;
                        continue;
                    }
                }
                if(!is_right) return;
                var yAxis = getY(ymax, ymin, linechart_parm);
                var labels=getLabels(linechart_parm, label_set, num, 2);
				var tip_label=label_set;
				var hrender = linechart_parm + '_' + resdata[key].resource_id;
				lineBasic2dConfig.coordinate.scale[1].labels = labels;
				lineBasic2dConfig.coordinate.scale[0].min_scale = yAxis[1];
				lineBasic2dConfig.coordinate.scale[0].start_scale = yAxis[1];
				lineBasic2dConfig.coordinate.scale[0].end_scale = yAxis[0];
				lineBasic2dConfig.coordinate.scale[0].scale_space = yAxis[2];
				lineBasic2dConfig.tipMocker = function(tips, i) {
					return "<div style='font-weight:500'>"
					+ tip_label[Math.floor(i)] + "</div>"
					+ tips.join("<br/>");
		         };
				createLineBasic2d(hrender, lineBasic2dConfig, data);
			}
		}
	});
	
  }


function loadChart(chartId, data, configDict) {
	  var chart = iChart.get(chartId);
	  if (configDict) {
		  for (attr in configDict) {
			  chart.push(attr, configDict[attr]);
		  }
	  }
	  chart.load(data);
	  return chart;
}

function line_chart() {
	jQuery('#instance_monitor li[class*="active"] ').each(function() {
		if (typeof $(this).attr("data-type") != 'undefined') {
			linechart_parm = ($(this).attr("data-type")).toLowerCase();
		}

	});
	ctn = getCtn(linechart_parm);
	strctn = ctn.join(",");
	var ids = [];
	$('#instance_monitor__' + linechart_parm + ' a[class*="cboxElement"] ')
			.each(function() {
				ids.push($(this).data("id"));
			});
	if (ids.length <= 0)
		return;
	var strIds = ids.join(",");
	if (linechart_parm == "disk") {
		distance = 320;
	}else{
		distance = 130;
	}
	var date = new Date();
	var sdate = new Date(date.getTime() - distance * 1000);
	etm = dateFormate(date);
	stm = dateFormate(sdate);
	
	jQuery.ajax({
		url : '/ceilometer/meter',
		type : "GET",
		data : {
			query : strIds,
			counter_name : strctn,
			stime : stm,
			etime : etm
		},
		dataType : "json",
		success : function(resdata) {
			for (key in resdata) {
				if (key == 'each')
					return;
				var hrender = linechart_parm + '_' + resdata[key].resource_id;
				if(typeof iChart.get(hrender)=="undefined"){
					initChart();
					return;
				}
				var is_right = false, pre, cur, num;
                data_key_list = Object.keys(resdata[key]["items"]);
                required_key_list = getCtn(linechart_parm);
                ymin = 0;
                ymax = 0;
                label_set = [];
                meterName = null;
                nuList = [];
                data = [];
                for(var it=0;it<data_key_list.length;it++){
                    if (required_key_list.indexOf(data_key_list[it]) != -1){
                        
                        tmp_data_set = [];
                        tmp_label_set = [];
                        tmp_counter_unit = null;
                        temp_data = (resdata[key].items)[data_key_list[it]];
                        meterName = getName(data_key_list[it]);
                        nuList = getNuList(linechart_parm, temp_data.length-1);
                        num = nuList[1];
                        if(nuList[2]){
                        	pre = temp_data[num]['counter_volume'] / nuList[0];
                        	cur = temp_data[num-1]['counter_volume'] / nuList[0];
                        	num--;
                        }
                        if(!is_right){
                        	if(nuList[2]){
                            	ymax = ymin = cur - pre;
                            }else{
                            	total = (resdata[key].counter_unit).split('_')[1];
            					if(total != null){
                					ymax = total / nuList[0];
            					}else{
            						ymax = temp_data[num]['counter_volume']/nuList[0];
            					}
                                ymin = temp_data[num]['counter_volume']/nuList[0];
                            }
                            
                        }
                        for(var data_it=num;data_it>=0;data_it--){
                            if(data_it != "each" && data_it != "eachAll" && data_it != "sor"){
                            	var value ;
                            	if(nuList[2]){
                            		cur = temp_data[data_it]['counter_volume'] / nuList[0];
            						value = cur - pre; 
            						pre = cur;
                            	}else{
                            		if(total != null){
                            			value = (total-temp_data[data_it]['counter_volume'])/nuList[0];
                            		}else{
                            			value = temp_data[data_it]['counter_volume']/nuList[0];
                            		}
                            		
                            	}
                            	
                                if(value > ymax){
                                    ymax = value;
                                }
                                if(value < ymin){
                                    ymin = value;
                                }
                                tmp_data_set.push(value);
                                tmp_label_set.push(temp_data[data_it]['timestamp']);
                                
                            }
                        }
                        data.push({name:meterName,
                                   value:tmp_data_set,
                                   color:fixed_color[it],
                                   line_width:2})
                        if(tmp_label_set.length > label_set.length){
                            label_set = tmp_label_set;
                        }
                        is_right = true;
                    }else {
                        is_right = false;
                        continue;
                    }
                }
                if(!is_right) return;
                var yAxis = getY(ymax, ymin, linechart_parm);
                var labels=getLabels(linechart_parm, label_set, num, 2);
				var tip_label=label_set;
				//var hrender = linechart_parm + '_' + resdata[key].resource_id;
				loadChart(hrender, data, {'coordinate.scale' : 
					[{
						 position:'left',	
						 start_scale:yAxis[1],
						 end_scale:yAxis[0],
						 scale_space:yAxis[2],
						 scale_size : 2,
					     scale_color : '#9f9f9f'
					},{
						 position:'bottom',	
						 labels:labels
					}],
					'tipMocker':
						 function(tips, i) {
							return "<div style='font-weight:500'>"
									+ tip_label[Math.floor(i)] + "</div>"
									+ tips.join("<br/>");
						}
				});
			}
		}
	});
	
  }
var rateId;
	function update_refresh() {
		
		horizon.cookies.write("refresh_rate",
				$(".ins_sel option:selected")[0].value);
		if(rateId){
			window.clearInterval(rateId);
		}
		rateId=window.setInterval("line_chart()", parseInt(horizon.cookies
				.read("refresh_rate")) * 1000);
	}

	$(document).on("shown", ".nav-tabs li a[data-toggle='tab']", function() {
		line_chart();
		colorlarge();
	});
	jQuery(function() {
		$(".ins_sel").click(function(event) {
			event.stopPropagation();
		});
		initChart();
		if (typeof horizon.cookies.read("refresh_rate") == "object") {
			horizon.cookies.write("refresh_rate", 60);
		}
		rateId=window.setInterval("line_chart()", parseInt(horizon.cookies
				.read("refresh_rate")) * 1000);
		
	});
	
