/**
 * 
 */
/**
 * 
 */

function colorlarge() {

	var colorbox_params = {

		reposition : true,
		scalePhotos : true,
		scrolling : false,
		previous : '<i class="icon-arrow-left"></i>',
		next : '<i class="icon-arrow-right"></i>',
		close : '&times;',
		current : '{current} of {total}',
		maxWidth : '100%',
		maxHeight : '100%',
		onOpen : function() {
			document.body.style.overflow = 'hidden';
		},
		onClosed : function() {
			document.body.style.overflow = 'auto';
			$.colorbox.remove();
			window.setTimeout("colorlarge()", 100);
		},
		onComplete : function() {
			$.colorbox.resize();
		}
	};
	var acti;
	jQuery('#instance_monitor li[class*="active"] ').each(function() {
		if (typeof $(this).attr("data-type") != 'undefined') {
			acti = ($(this).attr("data-type")).toLowerCase();
		}

	});
	var clb = "colorbox_" + acti;
	$('#ul_' + acti + ' [data-rel=' + clb + ']').colorbox(colorbox_params);
	if ($("#cboxLoadingGraphic i").length == 0) {
		$("#cboxLoadingGraphic").append("<i class='icon-spinner orange'></i>");// let's
		// add
		// a
		// custom
		// loading
		// icon
	}

	/**
	 * $(window).on('resize.colorbox', function() { try { //this function has
	 * been changed in recent versions of colorbox, so it won't work
	 * $.fn.colorbox.load();//to redraw the current frame } catch(e){} });
	 */
}

function delLi(id, user_id) {
	var cookie_id = user_id + ":instances";
	var ids = horizon.cookies.read(cookie_id).split(',');
	for (var i = 0; i < ids.length - 1; i++) {
		if (id == ids[i]) {
			ids.splice(i, 1);
			break;
		}
	}
	horizon.cookies.write(cookie_id, ids.join(','));
	window.location.href = "/ceilometer";

}

function dateFormate(date) {
	var str = date.getUTCFullYear();
	str += (date.getUTCMonth() < 9 ? "-0" : "-") + (date.getUTCMonth() + 1);
	str += (date.getUTCDate() < 10 ? "-0" : "-") + date.getUTCDate();
	str += (date.getUTCHours() < 10 ? " 0" : " ") + date.getUTCHours();
	str += (date.getUTCMinutes() < 10 ? ":0" : ":") + date.getUTCMinutes();
	str += (date.getUTCSeconds() < 10 ? ":0" : ":") + date.getUTCSeconds();
	return str;
}

function getCtn(parm) {
	var list = []
	if (parm == 'cpu') {
		list.push('cpu_util');
	} else if (parm == 'memory') {
		list.push('mem');
	} else if (parm == 'disk') {
		list.push('disk.read.bytes');
		list.push('disk.write.bytes');
	} else if (parm == 'network') {
		list.push('network.incoming.bytes')
		list.push('network.outgoing.bytes')
	}
	return list;
}
var tip_label = [], labels = [], pre_num = 0;
var lineBasic2dConfig = {
	align : 'center',
	title : '虚拟机',
	// subtitle : '?-3??',
	// footnote : '?,
	width : 380,
	height : 230,
	background_color : '#FEFEFE',
	tip : {
		enable : true,
		shadow : true,
		move_duration : 300,
		border : {
			enable : true,
			radius : 5,
			width : 2,
			color : '#3f8695'
		},
		listeners : {
			// tip:?name:value:?text:i:
			parseText : function(tip, name, value, text, i) {
				return name + ": " + parseFloat(value).toFixed(2);
			}
		}
	},
	tipMocker : function(tips, i) {
		return "<div style='font-weight:500'>" + tip_label[Math.floor(i)]
				+ "</div>" + tips.join("<br/>");
	},
	legend : {
		enable : true,
		row : 2,// column
		column : 'max',
		valign : 'top',
		sign : 'bar',
		background_color : null,//
		offsetx : -5,// x?
		border : true
	},
	crosshair : {
		enable : true,
		line_color : '#62bce9'//
	},
	sub_option : {
		label : false,
		point_size : 10
	},
	coordinate : {
		width : 290,
		height : 160,
		axis : {
			color : '#dcdcdc',
			width : 1
		},
		scale : [ {
			position : 'left',
			start_scale : 0,
			end_scale : 100,
			scale_space : 20,
			scale_size : 2,
			scale_color : '#9f9f9f'
		}, {
			position : 'bottom',
			labels : labels
		} ]
	}
}

function createLineBasic2d(elemId, config, data) {
	config.id = elemId;
	config.data = data;
	config.render = elemId;
	var chart = iChart.get(elemId);
	if (typeof chart == "undefined") {
		chart = new iChart.LineBasic2D(config);
	}
	// 开始画图
	chart.draw();
	return chart;
}

function isOdd(num) {
	return num % 2 == 0 ? true : false;
}

function getRandomC() {
	return '#' + (function(h) {
		return new Array(7 - h.length).join("0") + h
	})((Math.random() * 0x1000000 << 0).toString(16))
}

function getName(parm, unit) {
	var name = null;
	if (parm == 'cpu_util') {
		name = "cpu_util(" + unit + ")"
	} else if (parm == 'mem') {
		name = "Used Mem (" + unit + ")";
	} else if (parm == 'disk.read.bytes') {
		name = "Read(" + unit + ")";
	} else if (parm == 'disk.write.bytes') {
		name = "Write(" + unit +")";
	} else if (parm == 'network.incoming.bytes') {
		name = "In   (" + unit + ")";
	} else if (parm == 'network.outgoing.bytes') {
		name = "Out (" + unit + ")";
	}
	return name;
}

function getNuList(parm, len) {
	var nlist = [],  m = 3;
	if (parm == 'cpu') {
		if (!isOdd(len) && len >= 1)
			len -= 1;
		nlist.push(len);
		nlist.push(false);
	} else if (parm == 'memory') {
		if (!isOdd(len) && len >= 1)
			len -= 1;
		nlist.push(len);
		nlist.push(false);
	} else if (parm == 'disk') {
		if (!isOdd(len) && len >= 1)
			len -= 1;
		nlist.push(len);
		nlist.push(false);
	} else if (parm == 'network') {
		m = 5;
		if (isOdd(len) && len >= 1)
			len -= 1;
		if (pre_num < len && pre_num != 0 && len < 5)
			len = pre_num;
		pre_num = len;
		nlist.push(len);
		nlist.push(true);
	}
	nlist.push(m);
	return nlist;
}

function getLabels(label_set, num, m) {
	if (label_set.length <= 1)
		return [];
	if (num <= m)
		m = 1;
	var tmp_labels = [], n = 1;
	tmp_labels.push((label_set[0].split(" "))[1]);
	for (var i = 1; i <= num; i++) {
		if (n == m) {
			tmp_labels.push((label_set[i].split(" "))[1]);
			n = 1;
		} else {
			n++;
			continue;
		}
	}
	if (tmp_labels.length == 1)
		tmp_labels.push((label_set[num].split(" "))[1]);
	return tmp_labels;
}

function getY(ymax, ymin, parm) {
	var yscal = 0, ydel = 0;
	if (parm == 'cpu') {
		ydel = (ymax - ymin) / 10;
		ymax = parseInt(ymax + ydel) + 1;
		ymin = parseInt(ymin - ydel) - 1;
		ymin = ymin >= 0 ? ymin : 0;
		yscal = (ymax - ymin) / 5;
	} else if (parm == 'memory') {
		ydel = (ymax - ymin) / 100;
		ymin = parseInt(ymin - ydel) - 1;
		ymin = ymin > 0 ? ymin : 0;
		yscal = (ymax - ymin) / 5;
	} else if (parm == 'disk') {
		ydel = (ymax - ymin) / 100;
		ymax = parseInt(ymax + ydel) + 1;
		ymin = parseInt(ymin - ydel) - 1;
		ymin = ymin >= 0 ? ymin : 0;
		yscal = parseInt((ymax - ymin) / 5) - 1;
	} else if (parm == 'network') {
		ydel = (ymax - ymin) / 10;
		ymax = parseInt(ymax + ydel) + 1;
		ymin = parseInt(ymin) - 1;
		ymin = ymin >= 0 ? ymin : 0;
		yscal = parseInt((ymax - ymin) / 5) - 1;
	}
	var list = [];
	list.push(ymax);
	list.push(ymin);
	list.push(yscal);
	return list;
}

function get_unit(basic_u, ymax){
	var new_u = basic_u;
	var u_id = 0;
	var is_match = false;
	var ch_unit = 1;
	// find basic unit
	var result = [];
	if(basic_u == "B") basic_u = "bytes";
	for (; u_id < units.length; u_id++) {
		if (basic_u.indexOf(units[u_id]) != -1) {
			is_match = true;
			break;
		}
	}

	if (is_match) {
		// find change unit
		d_range = ymax;
		tmp_u = units[u_id];
		for (; u_id < units.length; u_id++) {
			if (d_range < 1000) {
				new_u = basic_u.replace(tmp_u,
						units[u_id]);
				break;
			} else {
				ch_unit = ch_unit * 1024;
				d_range = d_range / ch_unit;
			}
		}
		if (u_id == units.length) {
			new_u = basic_u.replace(tmp_u,
					units[u_id]);
		}
	} else {
		ch_unit = 1;
	}
	result.push(ch_unit);
	result.push(new_u);
	return result;
}

fixed_color = [ '#63d673', '#db170c', '#05447c', '#18c9cb', '#81fd8f',
		'#aa18b1', '#63ace3' ]

var linechart_parm, distance = 300;
var names = new Array();
units = ['bytes', 'KB', 'MB', 'GB'];
function initChart() {

	jQuery('#instance_monitor li[class*="active"] ').each(function() {
		if (typeof $(this).attr("data-type") != 'undefined') {
			linechart_parm = ($(this).attr("data-type")).toLowerCase();
		}

	});
	ctn = getCtn(linechart_parm);
	strctn = ctn.join(",");
	var ids = [];

	$('#instance_monitor__' + linechart_parm + ' a[class*="cboxElement"] ')
			.each(function() {
				ids.push($(this).data("id"));
				names[$(this).data("id")] = $(this).data("name");
			});
	if (ids.length <= 0)
		return;
	var strIds = ids.join(",");
	distance = linechart_parm == "disk" ? 900 : 300;
	var date = new Date();
	var sdate = new Date(date.getTime() - distance * 1000);
	etm = dateFormate(date);
	stm = dateFormate(sdate);

	jQuery
			.ajax({
				url : '/ceilometer/meter',
				type : "GET",
				data : {
					query : strIds,
					counter_name : strctn,
					stime : stm,
					etime : etm,
					limit : 13
				},
				dataType : "json",
				success : function(resdata) {
					for (key in resdata) {

						if (key == 'each')
							return;

						var is_right = false, pre, cur, num, ch_unit=[];
						data_key_list = Object.keys(resdata[key]["items"]);
						required_key_list = getCtn(linechart_parm);
						ymin = 0;
						ymax = 0;
						label_set = [];
						meterName = null;
						nuList = [];
						data = [];
						if ((resdata[key].items)[data_key_list[0]].length <= 4) {
							is_right = true;
							ymin = 0;
							ymax = 100;
							data = []
							data.push({
								name : "等待数据中......",
								value : [ 0 ],
								color : fixed_color[0],
								line_width : 2
							});
							num = 3;
							label_set = [ "0", "0", "0", "0" ];
						} else {
							for (var it = 0; it < data_key_list.length; it++) {
								if (required_key_list
										.indexOf(data_key_list[it]) != -1) {

									tmp_data_set = [];
									tmp_label_set = [];
									temp_data = (resdata[key].items)[data_key_list[it]];
									nuList = getNuList(linechart_parm,
											temp_data.length - 1);
									num = nuList[0];
									if (nuList[1]) {
										pre = temp_data[num]['counter_volume'];
										cur = temp_data[num - 1]['counter_volume'];
										num--;
									}
									if (!is_right) {
										if (nuList[1]) {
											ymax = ymin = cur - pre;
										} else {
											total = (resdata[key].counter_unit)
													.split('_')[1];
											ymax = total ? total : temp_data[num]['counter_volume'];
											ymin = temp_data[num]['counter_volume'];
										}
										var basic_u = (resdata[key].counter_unit).split('_')[0];
										ch_unit = get_unit(basic_u, ymax);
										ymax = ymax / ch_unit[0];
										ymin = ymin / ch_unit[0];
										
									}
									pre = pre / ch_unit[0];
									meterName = getName(data_key_list[it], ch_unit[1]);
									for (var data_it = num; data_it >= 0; data_it--) {
										if (data_it != "each"
												&& data_it != "eachAll"
												&& data_it != "sor") {
											var value;
											if (nuList[1]) {
												cur = temp_data[data_it]['counter_volume']
														/ ch_unit[0];
												value = cur - pre;
												pre = cur;
											} else {
												if (total != null) {
													value = (total - temp_data[data_it]['counter_volume'])
															/ ch_unit[0];
												} else {
													value = temp_data[data_it]['counter_volume']
															/ ch_unit[0];
												}

											}
											ymax = value > ymax ? value : ymax;
											ymin = value < ymin ? value : ymin;
											tmp_data_set.push(value);
											tmp_label_set
													.push(temp_data[data_it]['timestamp']);

										}
									}
									data.push({
										name : meterName,
										value : tmp_data_set,
										color : fixed_color[it],
										line_width : 2
									})
									if (tmp_label_set.length > label_set.length) {
										label_set = tmp_label_set;
									}
									is_right = true;
								} else {
									is_right = false;
									continue;
								}
							}
						}
						if (!is_right)
							return;
						var yAxis = getY(ymax, ymin, linechart_parm);
						var labels = getLabels(label_set, num, nuList[2]);
						var tip_label = label_set;
						var hrender = linechart_parm + '_'
								+ resdata[key].resource_id;
						lineBasic2dConfig.title = names[resdata[key].resource_id];
						lineBasic2dConfig.coordinate.scale[1].labels = labels;
						lineBasic2dConfig.coordinate.scale[0].min_scale = yAxis[1];
						lineBasic2dConfig.coordinate.scale[0].start_scale = yAxis[1];
						lineBasic2dConfig.coordinate.scale[0].end_scale = yAxis[0];
						lineBasic2dConfig.coordinate.scale[0].scale_space = yAxis[2];
						lineBasic2dConfig.tipMocker = function(tips, i) {
							return "<div style='font-weight:500'>"
									+ tip_label[Math.floor(i)] + "</div>"
									+ tips.join("<br/>");
						};
						createLineBasic2d(hrender, lineBasic2dConfig, data);
					}
				}
			});

}

function loadChart(chartId, data, configDict) {
	var chart = iChart.get(chartId);
	if (configDict) {
		for (attr in configDict) {
			chart.push(attr, configDict[attr]);
		}
	}
	chart.load(data);
	return chart;
}

function line_chart() {
	jQuery('#instance_monitor li[class*="active"] ').each(function() {
		if (typeof $(this).attr("data-type") != 'undefined') {
			linechart_parm = ($(this).attr("data-type")).toLowerCase();
		}

	});
	ctn = getCtn(linechart_parm);
	strctn = ctn.join(",");
	var ids = [];
	$('#instance_monitor__' + linechart_parm + ' a[class*="cboxElement"] ')
			.each(function() {
				ids.push($(this).data("id"));
				names[$(this).data("id")] = $(this).data("name");
			});
	if (ids.length <= 0)
		return;
	var strIds = ids.join(",");
	distance = linechart_parm == "disk" ? 900 : 300;
	var date = new Date();
	var sdate = new Date(date.getTime() - distance * 1000);
	etm = dateFormate(date);
	stm = dateFormate(sdate);

	jQuery
			.ajax({
				url : '/ceilometer/meter',
				type : "GET",
				data : {
					query : strIds,
					counter_name : strctn,
					stime : stm,
					etime : etm,
					limit : 13
				},
				dataType : "json",
				success : function(resdata) {
					for (key in resdata) {
						if (key == 'each')
							return;
						var hrender = linechart_parm + '_'
								+ resdata[key].resource_id;
						if (typeof iChart.get(hrender) == "undefined") {
							initChart();
							return;
						}
						var is_right = false, pre, cur, num;
						data_key_list = Object.keys(resdata[key]["items"]);
						required_key_list = getCtn(linechart_parm);
						ymin = 0;
						ymax = 0;
						label_set = [];
						meterName = null;
						nuList = [];
						data = [];
						if ((resdata[key].items)[data_key_list[0]].length <= 4) {
							is_right = true;
							ymin = 0;
							ymax = 100;
							data = []
							data.push({
								name : "等待数据中......",
								value : [ 0 ],
								color : fixed_color[0],
								line_width : 2
							});
							num = 3;
							label_set = [ "0", "0", "0", "0" ];
						} else {
							for (var it = 0; it < data_key_list.length; it++) {
								if (required_key_list
										.indexOf(data_key_list[it]) != -1) {

									tmp_data_set = [];
									tmp_label_set = [];
									temp_data = (resdata[key].items)[data_key_list[it]];
									nuList = getNuList(linechart_parm,
											temp_data.length - 1);
									num = nuList[0];
									if (nuList[1]) {
										pre = temp_data[num]['counter_volume'];
										cur = temp_data[num - 1]['counter_volume'];
										num--;
									}
									if (!is_right) {
										if (nuList[1]) {
											ymax = ymin = cur - pre;
										} else {
											total = (resdata[key].counter_unit)
													.split('_')[1];
											ymax = total ? total : temp_data[num]['counter_volume'];
											ymin = temp_data[num]['counter_volume'];
										}
										var basic_u = (resdata[key].counter_unit).split('_')[0];
										ch_unit = get_unit(basic_u, ymax);
										ymax = ymax / ch_unit[0];
										ymin = ymin / ch_unit[0];
										
									}
									pre = pre / ch_unit[0];
									meterName = getName(data_key_list[it], ch_unit[1]);
									for (var data_it = num; data_it >= 0; data_it--) {
										if (data_it != "each"
												&& data_it != "eachAll"
												&& data_it != "sor") {
											var value;
											if (nuList[1]) {
												cur = temp_data[data_it]['counter_volume']
														/ ch_unit[0];
												value = cur - pre;
												pre = cur;
											} else {
												if (total != null) {
													value = (total - temp_data[data_it]['counter_volume'])
															/ ch_unit[0];
												} else {
													value = temp_data[data_it]['counter_volume']
															/ ch_unit[0];
												}

											}
											ymax = value > ymax ? value : ymax;
											ymin = value < ymin ? value : ymin;
											tmp_data_set.push(value);
											tmp_label_set
													.push(temp_data[data_it]['timestamp']);

										}
									}
									data.push({
										name : meterName,
										value : tmp_data_set,
										color : fixed_color[it],
										line_width : 2
									})
									if (tmp_label_set.length > label_set.length) {
										label_set = tmp_label_set;
									}
									is_right = true;
								} else {
									is_right = false;
									continue;
								}
							}
						}
						if (!is_right)
							return;
						var yAxis = getY(ymax, ymin, linechart_parm);
						var labels = getLabels(label_set, num, nuList[2]);
						var tip_label = label_set;
						// var hrender = linechart_parm + '_' +
						// resdata[key].resource_id;
						loadChart(hrender, data, {
							'coordinate.scale' : [ {
								position : 'left',
								start_scale : yAxis[1],
								end_scale : yAxis[0],
								scale_space : yAxis[2],
								scale_size : 2,
								scale_color : '#9f9f9f'
							}, {
								position : 'bottom',
								labels : labels
							} ],
							'tipMocker' : function(tips, i) {
								return "<div style='font-weight:500'>"
										+ tip_label[Math.floor(i)] + "</div>"
										+ tips.join("<br/>");
							}
						});
					}
				}
			});

}
var rateId;
function update_refresh() {

	horizon.cookies.write("refresh_rate",
			$(".ins_sel option:selected")[0].value);
	if (rateId) {
		window.clearInterval(rateId);
	}
	rateId = window.setInterval("line_chart()", parseInt(horizon.cookies
			.read("refresh_rate")) * 1000);
}

$(document).on("shown", ".nav-tabs li a[data-toggle='tab']", function() {
	line_chart();
	colorlarge();
});
jQuery(function() {
	$(".ins_sel").click(function(event) {
		event.stopPropagation();
	});
	initChart();
	if (typeof horizon.cookies.read("refresh_rate") == "object") {
		horizon.cookies.write("refresh_rate", 60);
	}
	rateId = window.setInterval("line_chart()", parseInt(horizon.cookies
			.read("refresh_rate")) * 1000);

});
