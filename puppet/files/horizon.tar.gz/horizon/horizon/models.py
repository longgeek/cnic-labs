# vim: tabstop=4 shiftwidth=4 softtabstop=4

# Copyright 2012 United States Government as represented by the
# Administrator of the National Aeronautics and Space Administration.
# All Rights Reserved.
#
# Copyright 2012 Nebula, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

"""
Stub file to work around django bug: https://code.djangoproject.com/ticket/7198
"""
from django.db import models

#table used to log operations
class Operations(models.Model):
    client_ip = models.CharField(max_length=100)
    role = models.CharField(max_length=100)
    tenant = models.CharField(max_length=100)
    user = models.CharField(max_length=100)
    time = models.CharField(max_length=100)
    operation = models.CharField(max_length=100)
    result = models.BooleanField()
    detail = models.CharField(max_length=512)
    note = models.CharField(max_length=100)
    user_id = models.CharField(max_length=100)
    tenant_id = models.CharField(max_length=100)


class PreInstance(models.Model):
    APPLY = "Apply"
    REJECT = "Reject"
    user_id = models.CharField(max_length=100)
    tenant_id = models.CharField(max_length=100)
    source_type = models.CharField(max_length=100)
    image_id = models.CharField(max_length=100)
    instance_snapshot_id = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    flavor = models.CharField(max_length=100)
    status = models.CharField(max_length=100)
    detail = models.CharField(max_length=256)
    insert_time = models.CharField(max_length=100)
