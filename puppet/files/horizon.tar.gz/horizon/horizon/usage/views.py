import logging
import math

from horizon import tables
from django.conf import settings
from .base import BaseUsage
from .tables import *


LOG = logging.getLogger(__name__)


class UsageView(tables.DataTableView):
    usage_class = None
    show_terminated = True

    def __init__(self, *args, **kwargs):
        super(UsageView, self).__init__(*args, **kwargs)
        if not issubclass(self.usage_class, BaseUsage):
            raise AttributeError("You must specify a usage_class attribute "
                                 "which is a subclass of BaseUsage.")

    def get_template_names(self):
        if self.request.GET.get('format', 'html') == 'txt':
            return ".".join((self.template_name.rsplit('.', 1)[0], 'csv'))
        return self.template_name

    def get_content_type(self):
        if self.request.GET.get('format', 'html') == 'csv':
            return "text/csv"
        return "text/html"
    
    def current_page(self):
        return int(self.page_index)

    def get_data(self):
        tenant_id = self.kwargs.get('tenant_id', self.request.user.tenant_id)
        self.usage = self.usage_class(self.request, tenant_id)
        self.page_index = self.request.GET.get(TenantUsageTable._meta.pagination_param, 0)
        self.usage.summarize(*self.usage.get_date_range(), page_index=self.page_index)
        self.usage.get_quotas()
        self.kwargs['usage'] = self.usage
	self.total_items = self.usage.count(*self.usage.get_date_range())
        return self.usage.usage_list

    def get_context_data(self, **kwargs):
        context = super(UsageView, self).get_context_data(**kwargs)
        context['table'].kwargs['usage'] = self.usage
        context['form'] = self.usage.form
        context['usage'] = self.usage
	context['total_items'] = self.total_items
        ramm_temp = float(self.usage.quotas['ram']['used']) /self.usage.quotas['ram']['quota']*100
        context['ramm'] = ramm_temp
        cpu_temp = float(self.usage.quotas['cores']['used']) /self.usage.quotas['cores']['quota']*100
        context['cpu'] = cpu_temp
        disk_temp = float(self.usage.quotas['gigabytes']['used']) /self.usage.quotas['gigabytes']['quota']*100
        context['disk'] = disk_temp
        inst_temp = float(self.usage.quotas['instances']['used']) /self.usage.quotas['instances']['quota']*100
        context['inst'] = inst_temp
        return context

    def render_to_response(self, context, **response_kwargs):
        resp = self.response_class(request=self.request,
                                   template=self.get_template_names(),
                                   context=context,
                                   content_type=self.get_content_type(),
                                   **response_kwargs)
        if self.request.GET.get('format', 'html') == 'txt':
            resp['Content-Disposition'] = 'attachment; filename=usage.txt'
            resp['Content-Type'] = 'text/csv'
        return resp
