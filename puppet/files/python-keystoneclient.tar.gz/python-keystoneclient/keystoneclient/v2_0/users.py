# Copyright 2011 OpenStack LLC.
# Copyright 2011 Nebula, Inc.
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import urllib

from keystoneclient import base


class User(base.Resource):
    """Represents a Keystone user"""
    def __repr__(self):
        return "<User %s>" % self._info

    def delete(self):
        return self.manager.delete(self)

    def list_roles(self, tenant=None):
        return self.manager.list_roles(self.id, base.getid(tenant))


class UserManager(base.ManagerWithFind):
    """Manager class for manipulating Keystone users"""
    resource_class = User

    def get(self, user):
        return self._get("/users/%s" % base.getid(user), "user")

    def update(self, user, **kwargs):
        """
        Update user data.

        Supported arguments include ``name``, ``email``, and ``enabled``.
        """
        # FIXME(gabriel): "tenantId" seems to be accepted by the API but
        #                 fails to actually update the default tenant.
        params = {"user": kwargs}
        params['user']['id'] = base.getid(user)
        url = "/users/%s" % base.getid(user)
        return self._update(url, params, "user")

    #added by xjzhu@cnic.cn
    def update_approved(self, user, approved):
        """
        Update approved-ness
        """
        params = {"user": {"id": base.getid(user),
                           "approved": approved}}

        self._update("/users/%s/OS-KSADM/approved" % base.getid(user), params,
                     "user")

    def update_enabled(self, user, enabled):
        """
        Update enabled-ness
        """
        params = {"user": {"id": base.getid(user),
                           "enabled": enabled}}

        self._update("/users/%s/OS-KSADM/enabled" % base.getid(user), params,
                     "user")

    def update_password(self, user, password):
        """
        Update password
        """
        params = {"user": {"id": base.getid(user),
                           "password": password}}

        return self._update("/users/%s/OS-KSADM/password" % base.getid(user),
                            params, "user")

    def update_own_password(self, origpasswd, passwd):
        """
        Update password
        """
        params = {"user": {"password": passwd,
                           "original_password": origpasswd}}

        return self._update("/OS-KSCRUD/users/%s" % self.api.user_id, params,
                            response_key="access",
                            method="PATCH",
                            management=False)

    def update_tenant(self, user, tenant):
        """
        Update default tenant.
        """
        params = {"user": {"id": base.getid(user),
                           "tenantId": base.getid(tenant)}}

        # FIXME(ja): seems like a bad url - default tenant is an attribute
        #            not a subresource!???
        return self._update("/users/%s/OS-KSADM/tenant" % base.getid(user),
                            params, "user")

    def create(self, name, password, email, tenant_id=None, enabled=True, approved=True):
        """
        Create a user.
        """
        # FIXME(ja): email should be optional, keystone currently requires it
        params = {"user": {"name": name,
                           "password": password,
                           "tenantId": tenant_id,
                           "email": email,
                           "enabled": enabled,
                           "approved": approved}}
        return self._create('/users', params, "user")

    def delete(self, user):
        """
        Delete a user.
        """
        return self._delete("/users/%s" % base.getid(user))

    def list(self, tenant_id=None, limit=None, marker=None):
        """
        Get a list of users (optionally limited to a tenant)

        :rtype: list of :class:`User`
        """

        params = {}
        if limit:
            params['limit'] = int(limit)
        if marker:
            params['marker'] = int(marker)

        query = ""
        if params:
            query = "?" + urllib.urlencode(params)

        if not tenant_id:
            return self._list("/users%s" % query, "users")
        else:
            return self._list("/tenants/%s/users%s" % (tenant_id, query),
                              "users")

    #added by duyuanyuan
    def list_by_page(self, **kwargs):
        """
        Get a page list of users
        """

        qparams = {'limit': kwargs.get('page_size', 10)}
        page_index = kwargs.get('page_index', 0)
        if int(page_index) != 0:
            page_index = int(page_index)-1
        qparams['page_index'] = page_index
        del kwargs['page_size']
        del kwargs['page_index']
        #check whether it is a conditional search
        search_opts = kwargs.get('search_opts', None)

        if search_opts is None:
            search_opts = {}

        #get other args in kwargs except search_opts
        for opt, val in kwargs.iteritems():
            if cmp(opt,'search_opts') != 0:
                qparams[opt] = val


        #get search_opts args
        for opt, val in search_opts.iteritems():
            
            qparams[opt] = val


        query = "?%s" % urllib.urlencode(qparams) if qparams else ""

        tenant_id = kwargs.get('tenant_id', None)

        if not tenant_id:
            return self._list("/users/page%s" % query, "users")
        else:
            return self._list("/tenants/%s/users/page%s" % (tenant_id, query),
                              "users")

    def get_user_count(self, **kwargs):

         #check whether it is a conditional search
        search_opts = kwargs.get('search_opts', None)


        if search_opts is None:
            search_opts = {}


        qparams = {}


        #get other args in kwargs except search_opts
        for opt, val in kwargs.iteritems():
            if cmp(opt,'search_opts') != 0:
                qparams[opt] = val


        #get search_opts args
        for opt, val in search_opts.iteritems():
            qparams[opt] = val


        query = "?%s" % urllib.urlencode(qparams) if qparams else ""

        tenant_id = kwargs.get('tenant_id', None)
        if not tenant_id:
            return self._get_count("/users/count%s" % query, "users")
        else:
            return self._get_count("/tenants/%s/users/count%s" % (tenant_id, query), "users")
    #added by duyuanyuan

    def list_roles(self, user, tenant=None):
        return self.api.roles.roles_for_user(base.getid(user),
                                             base.getid(tenant))
