#!/bin/bash


#step 1
#set -o xtrace
host_ip=$1
admin_pwd=$2

controller_ip=192.168.75.17
keystone_ip=192.168.75.17
rabbit_ip=192.168.75.17
server_ip=192.168.75.17

ganglia_port=8653

role=controller
ceilo_conf_file=/etc/ceilometer/ceilometer.conf
nova_conf_file=/etc/nova/nova.conf
gmond_conf_file=/etc/ganglia/gmond.conf
gmetad_conf_file=/etc/ganglia/gmetad.conf

admin_tenant_id=`keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 tenant-list | grep admin | awk '{print $2}'`
#echo 'admin tenant:'${admin_tenant_id}

admin_role_id=`keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 role-list | grep admin | awk '{print $2}'`
#echo 'admin role:'${admin_role_id}

reselleradmin_role_id=`keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 role-list | grep ResellerAdmin | awk '{print $2}'`
#echo 'reseller role:'${reselleradmin_role_id}

member_role_id=`keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 role-list | grep Member | awk '{print $2}'`
#echo 'member role:'${member_role_id}

new_user_id=`keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 user-create --name ceilometer --pass ${admin_pwd} --tenant-id ${admin_tenant_id} --email test@test.cn --enabled true | grep id | awk '{print $4}'`

if [ -z "${new_user_id}" ]
then
    echo "Create user error!!!"
else
    echo "Create user:"${new_user_id}
    keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 user-role-add --user-id ${new_user_id} --tenant-id ${admin_tenant_id} --role-id ${admin_role_id}
    keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 user-role-add --user-id ${new_user_id} --tenant-id ${admin_tenant_id} --role-id ${reselleradmin_role_id}
    keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 user-role-add --user-id ${new_user_id} --tenant-id ${admin_tenant_id} --role-id ${member_role_id}
fi

check_role=`keystone --os-username ceilometer --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 user-role-list | wc -l`

echo 'check role:'${check_role}

service_id=`keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 service-create --name ceilometer --type metering --description 'ceilometer service' | grep id | awk '{print $4}'`
#echo 'service id: '${service_id}''

if [ -z "${service_id}" ]
then
    echo "Create service error!!!"
else
    echo "Create service:"${service_id}
    keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 endpoint-create --region RegionOne  --service_id ${service_id} --publicurl http://${host_ip}:8777   --adminurl http://${host_ip}:8777   --internalurl http://${host_ip}:8777
fi


#step 2

# Modify /etc/ceilometer/ceilometer.conf
ceiloPath="/etc/ceilometer/"
if [ ! -d "${ceiloPath}" ]
then
    mkdir "${ceiloPath}"
    cp -rf /opt/stack/install_scripts/files/ceilometer/ /etc/ 
    rm "${ceiloPath}hosts"
    rm "${ceiloPath}nova.conf"
fi
 
sed -i "/^\[DEFAULT\]/,/^\[.*\]/ s|^\(os_auth_url[ \t]*=.*$\)|os_auth_url=http://${keystone_ip}:35357/v2.0|" ${ceilo_conf_file}
#sed -i "/os_auth_url=/c\os_auth_url=http://${keystone_ip}:35357/v2.0" ${ceilo_conf_file}
sed -i "/^\[DEFAULT\]/,/^\[.*\]/ s|^\(os_password[ \t]*=.*$\)|os_password=${admin_pwd}|" ${ceilo_conf_file}
sed -i "/^\[DEFAULT\]/,/^\[.*\]/ s|^\(rabbit_password[ \t]*=.*$\)|rabbit_password=${admin_pwd}|" ${ceilo_conf_file}
sed -i "/^\[DEFAULT\]/,/^\[.*\]/ s|^\(rabbit_host[ \t]*=.*$\)|rabbit_host=${rabbit_ip}|" ${ceilo_conf_file}
sed -i "/^\[DEFAULT\]/,/^\[.*\]/ s|^\(server_telnet_port[ \t]*=.*$\)|server_telnet_port=${ganglia_port}|" ${ceilo_conf_file}
sed -i "/^\[keystone_authtoken\]/,/^\[.*\]/ s|^\(auth_host[ \t]*=.*$\)|auth_host=${keystone_ip}|" ${ceilo_conf_file}
sed -i "/^\[keystone_authtoken\]/,/^\[.*\]/ s|^\(admin_password[ \t]*=.*$\)|admin_password=${admin_pwd}|" ${ceilo_conf_file}
sed -i "/^\[keystone_authtoken\]/,/^\[.*\]/ s|^\(auth_uri[ \t]*=.*$\)|auth_uri=http://${keystone_ip}:5000/v2.0|" ${ceilo_conf_file}
sed -i "/^\[service_credentials\]/,/^\[.*\]/ s|^\(os_auth_url[ \t]*=.*$\)|os_auth_url=http://${keystone_ip}:5000/v2.0|" ${ceilo_conf_file}
sed -i "/^\[service_credentials\]/,/^\[.*\]/ s|^\(os_password[ \t]*=.*$\)|os_password=${admin_pwd}|" ${ceilo_conf_file}

# Modify /etc/nova/nova.conf
exist_flag1=`cat ${nova_conf_file} | grep notification_topics | wc -l`
if [ ${exist_flag1} != "1" ]
then
    echo "notification_topics=notifications" >> ${nova_conf_file}
else
    sed -i "/notification_topics/c\notification_topics=notifications" ${nova_conf_file}
fi

#exist_flag1=`cat ${nova_conf_file} | grep notification_driver | wc -l`
if [ ${exist_flag1} != "1" ]
then
    echo "notification_driver=nova.openstack.common.notifier.rabbit_notifier" >> ${nova_conf_file}
else
    sed -i "/notification_driver/c\notification_driver=nova.openstack.common.notifier.rabbit_notifier" ${nova_conf_file}
fi

# Modify /etc/ganglia/gmond.conf
if [ ${role} == "controller" ]
then
    sed -i "/^cluster {/,/^}/ s|[^ \t]*[ \t]*\(name[ \t]*=.*$\)|name=\"ECCP\"|" ${gmond_conf_file}
    sed -i "/^udp_send_channel {/,/^}/ s|[^ \t]*[ \t]*\(host[ \t]*=.*$\)|host=${controller_ip}|" ${gmond_conf_file}
    sed -i "/^udp_send_channel {/,/^}/ s|[^ \t]*[ \t]*\(port[ \t]*=.*$\)|port=${ganglia_port}|" ${gmond_conf_file}
    sed -i "/^udp_send_channel {/,/^}/ s|[^ \t]*[ \t]*\(ttl[ \t]*=.*$\)||" ${gmond_conf_file}
    sed -i "/^udp_recv_channel {/,/^}/ s|[^ \t]*[ \t]*\(bind[ \t]*=.*$\)||" ${gmond_conf_file}
    sed -i "/^udp_recv_channel {/,/^}/ s|[^ \t]*[ \t]*\(port[ \t]*=.*$\)|port=${ganglia_port}|" ${gmond_conf_file}
    sed -i "/^tcp_accept_channel {/,/^}/ s|[^ \t]*[ \t]*\(port[ \t]*=.*$\)|port=${ganglia_port}|" ${gmond_conf_file}
    sed -i "/^data_source.*$/c\data_source ECCP ${controller_ip}:${ganglia_port}" ${gmetad_conf_file}
elif [ ${role} == "compute" ]
then
    sed -i "/^udp_send_channel {/,/^}/ s|[^ \t]*[ \t]*\(host[ \t]*=.*$\)|host=${controller_ip}|" ${gmond_conf_file}
    sed -i "/^udp_send_channel {/,/^}/ s|[^ \t]*[ \t]*\(port[ \t]*=.*$\)|port=${ganglia_port}|" ${gmond_conf_file}
    sed -i "/^udp_send_channel {/,/^}/ s|[^ \t]*[ \t]*\(ttl[ \t]*=.*$\)||" ${gmond_conf_file}
    sed -i "/^udp_recv_channel {/,/^}/ s|[^ \t]*[ \t]*\(bind[ \t]*=.*$\)||" ${gmond_conf_file}
    sed -i "/^udp_recv_channel {/,/^}/ s|[^ \t]*[ \t]*\(port[ \t]*=.*$\)|port=${ganglia_port}|" ${gmond_conf_file}

    echo "udp_send_channel {" >> ${gmond_conf_file}
    echo "host=${server_ip}" >> ${gmond_conf_file}
    echo "port=${ganglia_port}" >> ${gmond_conf_file}
    echo "}" >> ${gmond_conf_file}
fi


#step 3

apt-get install mongodb -y

cd /opt/stack/python-ceilometerclient/
python setup.py develop

source /opt/stack/grizzlyenv/bin/activate
cd /opt/stack/ceilometer
python setup.py develop
cp /usr/lib/python2.7/dist-packages/libvirt* /opt/stack/grizzlyenv/lib/python2.7/site-packages/
chown stack:stack /opt/stack/grizzlyenv/lib/python2.7/site-packages/libvirt*
deactivate
