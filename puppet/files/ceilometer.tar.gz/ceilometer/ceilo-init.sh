#!/bin/bash
set -o xtrace
host_ip=$1
admin_pwd=$2

admin_tenant_id=`keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 tenant-list | grep admin | awk '{print $2}'`
#echo 'admin tenant:'${admin_tenant_id}

admin_role_id=`keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 role-list | grep admin | awk '{print $2}'`
#echo 'admin role:'${admin_role_id}

reselleradmin_role_id=`keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 role-list | grep ResellerAdmin | awk '{print $2}'`
#echo 'reseller role:'${reselleradmin_role_id}

member_role_id=`keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 role-list | grep Member | awk '{print $2}'`
#echo 'member role:'${member_role_id}

new_user_id=`keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 user-create --name ceilometer --pass ${admin_pwd} --tenant-id ${admin_tenant_id} --email test@test.cn --enabled true | grep id | awk '{print $4}'`

if [ -z "${new_user_id}" ]
then
    echo "Create user error!!!"
else
    echo "Create user:"${new_user_id}
    keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 user-role-add --user-id ${new_user_id} --tenant-id ${admin_tenant_id} --role-id ${admin_role_id}
    keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 user-role-add --user-id ${new_user_id} --tenant-id ${admin_tenant_id} --role-id ${reselleradmin_role_id}
    keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 user-role-add --user-id ${new_user_id} --tenant-id ${admin_tenant_id} --role-id ${member_role_id}
fi

check_role=`keystone --os-username ceilometer --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 user-role-list | wc -l`

echo 'check role:'${check_role}

service_id=`keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 service-create --name ceilometer --type metering --description 'ceilometer service' | grep id | awk '{print $4}'`
#echo 'service id: '${service_id}''

if [ -z "${service_id}" ]
then
    echo "Create service error!!!"
else
    echo "Create service:"${service_id}
    keystone --os-username admin --os_password ${admin_pwd} --os_tenant_name admin --os_auth_url http://${host_ip}:5000/v2.0 endpoint-create --region RegionOne  --service_id ${service_id} --publicurl http://${host_ip}:8777   --adminurl http://${host_ip}:8777   --internalurl http://${host_ip}:8777
fi
